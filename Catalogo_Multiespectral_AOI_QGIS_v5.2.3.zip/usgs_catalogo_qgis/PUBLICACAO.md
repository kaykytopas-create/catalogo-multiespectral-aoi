# Publicação 5.2.3

Pacote com uma pasta raiz usgs_catalogo_qgis, metadata.txt validado, descrição atualizada,
version=5.2.3, experimental=False e deprecated=False. Licença GPL-2.0-or-later.
Valide com python -m usgs_catalogo_qgis.tools.prepare_release --check no ambiente adequado.
Consulte VALIDACAO_5.2.3.md e GUIA_5.2.3.md. O ZIP foi preparado e verificado localmente;
nenhum envio ou aprovação no repositório oficial do QGIS foi realizado nesta entrega.
Antes de publicar, o mantenedor deve conferir os links públicos e realizar a revisão exigida
pelo repositório. Documentos de versões antigas não descrevem a interface atual.
