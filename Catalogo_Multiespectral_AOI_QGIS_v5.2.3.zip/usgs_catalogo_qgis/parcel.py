# SPDX-License-Identifier: GPL-2.0-or-later
"""Freeze a parcel from the QGIS edit buffer, including temporary feature IDs."""
import hashlib
import json
from dataclasses import dataclass
from qgis.core import (QgsCoordinateReferenceSystem,QgsCoordinateTransform,QgsFeature,
    QgsFeatureRequest,QgsGeometry,QgsProject,QgsVectorLayer,QgsWkbTypes)
from .stac import CatalogError,bbox


def polygon_layer(layer):
    return isinstance(layer,QgsVectorLayer) and layer.isValid() and not layer.customProperty('catalogo_layout_aux',False) and layer.geometryType()==QgsWkbTypes.GeometryType.PolygonGeometry


@dataclass(frozen=True)
class ParcelSnapshot:
    layer_id: str
    layer_name: str
    target_crs: str
    geometry_wkt: str
    rect: tuple
    feature_ids: tuple
    fingerprint: str
    selection_note: str

    def outline_layer(self):
        layer=QgsVectorLayer('MultiPolygon?crs=EPSG:4326',self.layer_name,'memory')
        feature=QgsFeature();geometry=QgsGeometry.fromWkt(self.geometry_wkt)
        geometry.convertToMultiType();feature.setGeometry(geometry)
        layer.dataProvider().addFeatures([feature]);layer.updateExtents()
        return layer

    def matches_current(self):
        layer=QgsProject.instance().mapLayer(self.layer_id)
        if not polygon_layer(layer):return False
        return feature_fingerprint(layer,self.feature_ids)==self.fingerprint


def feature_fingerprint(layer,ids):
    features=[layer.getFeature(fid) for fid in ids]
    if any(not feature.isValid() for feature in features):return ''
    raw={'crs':layer.crs().toWkt(),'features':sorted((feature.id(),feature.geometry().asWkt()) for feature in features)}
    return hashlib.sha256(json.dumps(raw,sort_keys=True).encode()).hexdigest()


def snapshot(layer):
    if not polygon_layer(layer):
        raise CatalogError('Escolha a camada poligonal do imóvel no campo Imóvel desta aba.')
    if not layer.crs().isValid():
        raise CatalogError('A camada '+layer.name()+' não tem SRC definido.')
    selected=list(layer.getSelectedFeatures()) if layer.selectedFeatureCount() else []
    if selected:
        features=selected
        note='{} feição(ões) selecionada(s) em {}'.format(len(features),layer.name())
    else:
        # Iterate the layer, not its provider: this includes unsaved drawing edits.
        features=list(layer.getFeatures(QgsFeatureRequest().setLimit(2)))
        if len(features)>1:
            raise CatalogError('A camada “{}” contém vários polígonos. Selecione o(s) polígono(s) do imóvel nessa camada. Marcar a caixa de visibilidade ou destacar o nome da camada não seleciona suas feições.'.format(layer.name()))
        note='Único polígono da camada '+layer.name()+'; não exige seleção manual'
    if not features:
        raise CatalogError('Nenhum polígono encontrado em “{}”. Finalize o desenho com o botão direito antes de consultar; não é necessário salvar a camada em arquivo.'.format(layer.name()))
    if len(features)>1000:
        raise CatalogError('Selecione até 1.000 partes do mesmo imóvel por tarefa.')
    geometries=[QgsGeometry(feature.geometry()) for feature in features]
    if any(geometry.isEmpty() or not geometry.isGeosValid() for geometry in geometries):
        raise CatalogError('O limite em “{}” tem geometria vazia ou inválida. Corrija a geometria antes de consultar.'.format(layer.name()))
    geometry=QgsGeometry.unaryUnion(geometries)
    geometry.transform(QgsCoordinateTransform(layer.crs(),QgsCoordinateReferenceSystem('EPSG:4326'),QgsProject.instance()))
    bounds=geometry.boundingBox()
    rect=tuple(bbox((bounds.xMinimum(),bounds.yMinimum(),bounds.xMaximum(),bounds.yMaximum())))
    ids=tuple(sorted(feature.id() for feature in features))
    return ParcelSnapshot(layer.id(),layer.name(),layer.crs().authid() or layer.crs().toWkt(),
                          geometry.asWkt(),rect,ids,feature_fingerprint(layer,ids),note)


from qgis.PyQt.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QComboBox,QPushButton


class ParcelPicker(QWidget):
    """Explicit parcel selector for a tab, independent from hidden imagery fields."""
    def __init__(self,iface=None,preferred_box=None,parent=None):
        super().__init__(parent)
        self.iface,self.preferred_box=iface,preferred_box
        self._refreshing,self._explicit=False,False
        layout=QVBoxLayout(self);layout.setContentsMargins(0,0,0,0)
        row=QHBoxLayout();row.addWidget(QLabel('Imóvel · camada poligonal:'))
        self.combo=QComboBox();self.combo.setMinimumContentsLength(20)
        refresh=QPushButton('Atualizar camadas');row.addWidget(self.combo,1);row.addWidget(refresh)
        layout.addLayout(row)
        self.note=QLabel('');self.note.setWordWrap(True);layout.addWidget(self.note)
        self.combo.currentIndexChanged.connect(self.changed)
        refresh.clicked.connect(self.refresh)
        self.refresh()

    def changed(self,index):
        if not self._refreshing:
            self._explicit=True
            self.describe()

    def refresh(self):
        current=self.combo.currentData()
        layers=sorted((layer for layer in QgsProject.instance().mapLayers().values() if polygon_layer(layer)),key=lambda layer:layer.name().lower())
        ids={layer.id() for layer in layers}
        if not self._explicit or current not in ids:
            self._explicit=False
            selected=[layer for layer in layers if layer.selectedFeatureCount()]
            active=self.iface.activeLayer() if self.iface and hasattr(self.iface,'activeLayer') else None
            preferred=self.preferred_box.currentData() if self.preferred_box else None
            if len(selected)==1:current=selected[0].id()
            elif polygon_layer(active):current=active.id()
            elif preferred in ids:current=preferred
            elif len(layers)==1:current=layers[0].id()
            elif current not in ids:current=None
        self._refreshing=True
        self.combo.clear();self.combo.addItem('Escolha o imóvel…',None)
        for layer in layers:self.combo.addItem(layer.name(),layer.id())
        self.combo.setCurrentIndex(max(0,self.combo.findData(current)))
        self._refreshing=False
        self.describe()

    def describe(self):
        layer=QgsProject.instance().mapLayer(self.combo.currentData())
        if not polygon_layer(layer):
            self.note.setText('Escolha o limite nesta aba. Um único polígono funciona sem seleção manual.')
            return
        if layer.selectedFeatureCount():
            self.note.setText('{} · {} feição(ões) selecionada(s).'.format(layer.name(),layer.selectedFeatureCount()))
        else:
            self.note.setText('{} · usando o único polígono, se houver. Para camadas com vários polígonos, selecione as partes do imóvel.'.format(layer.name()))

    def resolve(self):
        self.refresh()
        value=snapshot(QgsProject.instance().mapLayer(self.combo.currentData()))
        self.note.setText(value.selection_note)
        return value
