from .spectral import INDEX_PRODUCTS
# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 Kayky Pessoa de Araujo
"""Anonymous STAC search and raster download via Microsoft Planetary Computer.

The Landsat collection contains USGS Collection 2 Level-2 imagery. Microsoft's
read-only SAS signing service is public and requires no account from the user.
"""
import json
import logging
import hashlib
import math
import threading
from concurrent.futures import ThreadPoolExecutor
import os
import urllib.parse
from pathlib import Path
from datetime import datetime, timedelta, timezone

STAC_URL = "https://planetarycomputer.microsoft.com/api/stac/v1/search"
SIGN_URL = "https://planetarycomputer.microsoft.com/api/sas/v1/sign"
SAS_ENDPOINT = "https://planetarycomputer.microsoft.com/api/sas/v1/token/"
COLLECTIONS = {
    "landsat-c2-l2": "Landsat 4–9 | USGS Collection 2, nível 2",
    "sentinel-2-l2a": "Sentinel-2 | nível 2A",
    "sentinel-2-l2a-aws": "Sentinel-2 | AWS C1 nível 2A",
    "hls2-l30": "NASA HLS L30 | Landsat harmonizado, 30 m",
    "hls2-s30": "NASA HLS S30 | Sentinel-2 harmonizado, 30 m",
    "modis-09A1-061": "MODIS Terra/Aqua | superfície, 8 dias, 500 m",
}
MAX_CLOUD = 20
RASTER_SUFFIXES = {".tif", ".tiff", ".jp2"}
CROP_PROFILE = {"width": 4.0, "height": 2.4, "min_aspect": 1.6}
RGB_DEFAULTS = ("swir16", "nir08", "red")
NDVI_BANDS = {"landsat-c2-l2": ("nir08", "red"),
              "sentinel-2-l2a": ("B08", "B04"),
              "sentinel-2-l2a-aws": ("B08", "B04"),
              "hls2-l30": ("nir08", "red"),
              "hls2-s30": ("nir08", "red"),
              "modis-09A1-061": ("nir08", "red")}


class CatalogError(Exception):
    pass


def bbox(rect):
    west, south, east, north = rect
    if not (-180 <= west < east <= 180 and -90 <= south < north <= 90):
        raise CatalogError("O limite do imóvel está fora das coordenadas válidas.")
    return [west, south, east, north]


def context_bbox(rect):
    """Keep the full parcel and surroundings in a landscape crop (at least 1.6:1).

    Longitude distance varies with latitude; compensate using the parcel center.
    """
    west, south, east, north = bbox(rect)
    center_x, center_y = (west + east) / 2, (south + north) / 2
    height = (north - south) * CROP_PROFILE["height"]
    longitude_scale = max(math.cos(math.radians(center_y)), 0.01)
    width = max((east - west) * CROP_PROFILE["width"],
                height * CROP_PROFILE["min_aspect"] / longitude_scale)
    return bbox((center_x - width / 2, center_y - height / 2,
                 center_x + width / 2, center_y + height / 2))


def available_bands(item):
    if item.get("catalog:kind") in ("categorical", "thermal"):
        return []
    return [(key, asset) for key, asset in item.get("assets", {}).items()
            if asset.get("eo:bands") and key != "visual" and
            Path(urllib.parse.urlparse(asset.get("href", "")).path).suffix.lower() in RASTER_SUFFIXES]


def band_label(key, asset):
    info = asset.get("eo:bands") or [{}]
    identifier = info[0].get("name", "")
    return "{}  {}".format(key.upper(), "({})".format(identifier) if identifier else "")


def default_rgb_keys(item):
    available_list = [key for key, _ in available_bands(item)]
    available = set(available_list)
    for preferred in (RGB_DEFAULTS, ("B11", "B08", "B04")):
        if all(key in available for key in preferred):
            return preferred
    natural = natural_rgb_keys(item)
    if natural:
        return natural
    keys = available_list
    return tuple((keys + keys + keys)[:3]) if keys else ()


def prodes_label(item):
    """Main spectral composite documented by INPE for PRODES Amazônia."""
    keys = default_rgb_keys(item)
    if item.get('collection') == 'hls2-s30' and keys == RGB_DEFAULTS:
        return 'PRODES · SWIR1/NIR/vermelho (HLS S30: 11–8A–4)'
    if keys == ("B11", "B08", "B04"):
        return "PRODES — INPE (11–8–4)"
    if keys == RGB_DEFAULTS:
        platform = str(item.get("properties", {}).get("platform", "")).lower()
        band_name = str((item.get("assets", {}).get("swir16", {}).get("eo:bands") or [{}])[0].get("name", "")).upper()
        oli = platform in ("landsat-8", "landsat-9") or str(item.get("id", "")).startswith(("LC08", "LC09")) or band_name.endswith("B6")
        return "PRODES — INPE ({})".format("6–5–4" if oli else "5–4–3")
    return "PRODES — INPE (indisponível)"


def natural_rgb_keys(item):
    available = {key for key, _ in available_bands(item)}
    for preferred in (("red", "green", "blue"), ("B04", "B03", "B02")):
        if all(key in available for key in preferred):
            return preferred
    return ()


def ndvi_keys(item):
    if item.get("catalog:kind") in ("categorical", "thermal"):
        return ()
    keys = NDVI_BANDS.get(item.get("collection"), ())
    available = {key for key, _ in available_bands(item)}
    return keys if all(key in available for key in keys) else ()



PRESETS = (
    ("prodes", "Vegetação e umidade (SWIR1–NIR–vermelho)", ("swir16", "nir08", "red")),
    ("bare", "Solo exposto / supressão (SWIR2–SWIR1–vermelho)", ("swir22", "swir16", "red")),
    ("burn", "Cicatriz / perturbação (SWIR2–NIR–vermelho)", ("swir22", "nir08", "red")),
    ("natural", "Cor natural", ("red", "green", "blue")),
    ("infrared", "Infravermelho — vegetação", ("nir08", "red", "green")),
    ("vegetation", "Análise de vegetação", ("swir16", "nir08", "red")),
    ("swir", "Infravermelho de ondas curtas", ("swir22", "nir08", "red")),
    ("agriculture", "Agricultura", ("swir22", "swir16", "blue")),
    ("water_detail", "Água e margens (SWIR2–NIR–azul)", ("swir22", "nir08", "blue")),
    ("moisture", "Umidade / áreas úmidas (SWIR1–NIR–azul)", ("swir16", "nir08", "blue")),
    ("water", "Terra / água", ("nir08", "swir16", "red")),
)


def preset_keys(item, preset):
    semantic = next((keys for identifier, label, keys in PRESETS if identifier == preset), ())
    sentinel = {"red": "B04", "green": "B03", "blue": "B02", "nir08": "B08",
                "swir16": "B11", "swir22": "B12"}
    keys = tuple(sentinel[key] for key in semantic) if item.get("collection") in ("sentinel-2-l2a", 'sentinel-2-l2a-aws') else semantic
    available = {key for key, _ in available_bands(item)}
    return keys if keys and all(key in available for key in keys) else ()


def index_keys(item, product):
    if item.get("catalog:kind") in ("categorical", "thermal"):
        return ()
    if product not in INDEX_PRODUCTS:return ()
    from .spectral import INDEX_DEFINITIONS,ALIASES
    semantic=INDEX_DEFINITIONS[product][1:3]
    available={key for key,_ in available_bands(item)}
    keys=tuple(k if k in available else ALIASES[k] for k in semantic)
    return keys if all(k in available for k in keys) else ()


def slc_gap_scene(item):
    props = item.get("properties", {})
    landsat7 = props.get("platform") == "landsat-7" or str(item.get("id", "")).startswith("LE07")
    return landsat7 and str(props.get("datetime", ""))[:10] >= "2003-05-31"


def validate_raster(path, gdal, cancelled=lambda: False):
    """Read every raster block so truncated tiles cannot be accepted as cached data."""
    dataset = gdal.Open(path)
    if dataset is None or dataset.RasterXSize <= 0 or dataset.RasterYSize <= 0:
        raise CatalogError("Raster vazio ou ilegível; baixe novamente a banda.")
    for index in range(1, dataset.RasterCount + 1):
        band = dataset.GetRasterBand(index)
        width, height = band.GetBlockSize()
        for y in range(0, dataset.RasterYSize, max(1, height)):
            for x in range(0, dataset.RasterXSize, max(1, width)):
                if cancelled():
                    raise CatalogError("Operação cancelada.")
                data = band.ReadRaster(x, y, min(max(1, width), dataset.RasterXSize-x),
                                       min(max(1, height), dataset.RasterYSize-y))
                if not data:
                    raise CatalogError("Bloco raster incompleto; baixe novamente a banda.")
    dataset = None


def validate_cached_raster(path, gdal, cancelled=lambda: False):
    from .storage import receipt
    stat = os.stat(path)
    try:
        with open(path + '.validated.json', encoding='utf8') as stream:
            previous = json.load(stream)
        if isinstance(previous,dict) and previous.get('invalid'):
            raise CatalogError('Arquivo reprovado na auditoria; recupere a banda antes de reutilizar.')
        if isinstance(previous, dict) and previous.get('stat') == [stat.st_size, stat.st_mtime_ns] and previous.get('sha256'):
            return
    except (OSError, ValueError):
        pass
    validate_raster(path, gdal, cancelled)
    receipt(path, cancelled, deep=True)


def reflectance_coefficients(item, key):
    """Apply the product's radiometric scaling before computing an index."""
    if item.get("catalog:correction") == "DOS1":
        return 1.0, 0.0
    if item.get("collection") == "landsat-c2-l2":
        return 0.0000275, -0.2
    asset = item.get("assets", {}).get(key, {})
    metadata = (asset.get("raster:bands") or [{}])[0]
    if item.get("collection") == "sentinel-2-l2a" and not metadata:
        # Planetary Computer raw Sentinel DNs retain the ESA baseline offset.
        # Use the processing baseline, never the acquisition date.
        baseline = item.get("properties", {}).get("s2:processing_baseline")
        if baseline is None:
            raise CatalogError("Baseline radiométrica Sentinel ausente nos metadados.")
        return 0.0001, -0.1 if float(baseline) >= 4.0 else 0.0
    return float(metadata.get("scale", 0.0001)), float(metadata.get("offset", 0))


def write_index(item, files_by_key, destination, gdal, product="ndvi", cancelled=lambda: False):
    """Calculate reflectance NDVI in row blocks, preserving NoData as -9999."""
    import numpy as np

    nir_key, red_key = index_keys(item, product)
    red = gdal.Open(files_by_key[red_key])
    nir = gdal.Open(files_by_key[nir_key])
    if red is None or nir is None:
        raise CatalogError("Não foi possível abrir as bandas para calcular o NDVI.")
    aligned = None
    if (red.RasterXSize != nir.RasterXSize or red.RasterYSize != nir.RasterYSize or
            red.GetGeoTransform() != nir.GetGeoTransform() or
            red.GetProjection() != nir.GetProjection()):
        gt = red.GetGeoTransform()
        bounds = (gt[0], gt[3] + red.RasterYSize * gt[5],
                  gt[0] + red.RasterXSize * gt[1], gt[3])
        aligned = gdal.Warp("", nir, format="MEM", outputBounds=bounds,
                            width=red.RasterXSize, height=red.RasterYSize,
                            dstSRS=red.GetProjection(), resampleAlg="near")
        if aligned is None:
            raise CatalogError("Não foi possível alinhar as bandas do NDVI.")
        nir = aligned
    qa_mask=None
    qa_key=next((k for k in ('Fmask','SCL','qa_pixel') if k in files_by_key),None)
    if product in ('ndwi','mndwi','ndmi','ndti') and not qa_key:
        raise CatalogError('Máscara de qualidade ausente. Baixe o Band Set completo e tente novamente.')
    if qa_key:
        from .prodes_auto import qa_valid
        gt=red.GetGeoTransform()
        qa=gdal.Warp('',files_by_key[qa_key],format='MEM',dstSRS=red.GetProjection(),outputBounds=(gt[0],gt[3]+red.RasterYSize*gt[5],gt[0]+red.RasterXSize*gt[1],gt[3]),width=red.RasterXSize,height=red.RasterYSize,resampleAlg='near',dstNodata=255)
        if qa is None:raise CatalogError('Falha ao alinhar a máscara de qualidade.')
        qa_mask=qa_valid(qa.ReadAsArray(),{'Fmask':'hls','SCL':'sentinel','qa_pixel':'landsat'}[qa_key]);qa=None
    output = gdal.GetDriverByName("GTiff").Create(destination, red.RasterXSize,
        red.RasterYSize, 1, gdal.GDT_Float32, options=["TILED=YES"])
    if output is None:
        raise CatalogError("Não foi possível criar o raster NDVI.")
    output.SetGeoTransform(red.GetGeoTransform())
    output.SetProjection(red.GetProjection())
    out_band = output.GetRasterBand(1)
    out_band.SetNoDataValue(-9999)
    red_band, nir_band = red.GetRasterBand(1), nir.GetRasterBand(1)
    red_scale, red_offset = reflectance_coefficients(item, red_key)
    nir_scale, nir_offset = reflectance_coefficients(item, nir_key)
    for y in range(0, red.RasterYSize, 256):
        if cancelled():
            raise CatalogError("Operação cancelada.")
        count = min(256, red.RasterYSize - y)
        raw_red = red_band.ReadAsArray(0, y, red.RasterXSize, count)
        raw_nir = nir_band.ReadAsArray(0, y, red.RasterXSize, count)
        valid = np.isfinite(raw_red) & np.isfinite(raw_nir)
        for raw, band in ((raw_red, red_band), (raw_nir, nir_band)):
            nodata = band.GetNoDataValue()
            if nodata is not None:
                valid &= raw != nodata
        if item.get("collection") == "landsat-c2-l2":
            valid &= (raw_red != 0) & (raw_nir != 0)
        red_value = raw_red.astype("float32") * red_scale + red_offset
        nir_value = raw_nir.astype("float32") * nir_scale + nir_offset
        denominator = nir_value + red_value
        valid &= (denominator > 1e-6)&(red_value>=0)&(nir_value>=0)&(red_value<=1.5)&(nir_value<=1.5)
        if qa_mask is not None:valid &= qa_mask[y:y+count]
        values = np.full(raw_red.shape, -9999, dtype="float32")
        np.divide(nir_value - red_value, denominator, out=values, where=valid)
        values[(values < -1) | (values > 1)] = -9999
        out_band.WriteArray(values, 0, y)
    output.SetMetadata({"INDEX":product.upper(),"FORMULA":"(A-B)/(A+B)","BAND_A":nir_key,"BAND_B":red_key,"QA_APPLIED":str(bool(qa_key))})
    output.FlushCache()
    out_band = red_band = nir_band = None
    output = None
    aligned = None
    red = nir = None
    return destination



def write_ndvi(item, files_by_key, destination, gdal, cancelled=lambda: False):
    return write_index(item, files_by_key, destination, gdal, "ndvi", cancelled)

def search_payload(collections, rect, start, end, cloud=MAX_CLOUD):
    if not collections or not set(collections).issubset(COLLECTIONS):
        raise CatalogError("Selecione uma coleção disponível.")
    return {"collections": list(collections), "bbox": bbox(rect),
            "datetime": start + "T00:00:00Z/" + end + "T23:59:59Z",
            "query": {"eo:cloud_cover": {"lt": cloud}},
            "sortby": [{"field": "datetime", "direction": "desc"}],
            "limit": 100}


def visible_scenes(items, cloud=MAX_CLOUD):
    result = []
    for item in items:
        if item.get('collection') == 'modis-09A1-061':
            result.append(item)  # 8-day composite: scene cloud percent is not available.
            continue
        cover = item.get("properties", {}).get("eo:cloud_cover")
        try:
            if cover is not None and float(cover) < cloud:
                result.append(item)
        except (ValueError, TypeError):
            logging.getLogger(__name__).warning("Cena ignorada: metadado de nuvens inválido.")
    return result


def raster_assets(item, include_auxiliary=False):
    """Spectral bands by default; optionally add QA/auxiliary rasters."""
    assets = []
    for key, value in item.get("assets", {}).items():
        href = value.get("href", "")
        parsed = urllib.parse.urlparse(href)
        if parsed.scheme != "https" or Path(parsed.path).suffix.lower() not in RASTER_SUFFIXES:
            continue
        if "thumbnail" in value.get("roles", []) or "overview" in value.get("roles", []):
            continue
        if not include_auxiliary and not value.get("eo:bands"):
            continue
        if not include_auxiliary and key == "visual":
            continue
        assets.append((key, href))
    return assets


def safe_name(scene_id, key, href):
    """Use only sanitized catalog identifiers as local file names."""
    def clean(value):
        return "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in value)[:140]
    suffix = Path(urllib.parse.urlparse(href).path).suffix.lower()
    return clean(scene_id) + "_" + clean(key) + suffix


def preview_url(item, size=180):
    if item.get('collection') == 'sentinel-2-l2a-aws':
        from .earth_search import public_asset
        thumbnail = item.get('assets', {}).get('thumbnail', {}).get('href', '')
        if public_asset(thumbnail): return thumbnail
    if 'INPE/Brazil Data Cube' in item.get('catalog:sources',[]):
        name='thumb_large.jpeg' if size>180 else 'thumb_small.jpeg'
        thumbnail=item.get('assets',{}).get(name,{}).get('href','')
        p=urllib.parse.urlparse(thumbnail)
        try:
            if p.scheme=='https' and p.hostname=='data.inpe.br' and p.port in (None,443) and not p.username and not p.password and p.path.startswith('/bdc/data/landsat/v2/'):return thumbnail
        except ValueError:pass
    asset = item.get("assets", {}).get("rendered_preview", {})
    url = asset.get("href", "")
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https" or parsed.hostname != "planetarycomputer.microsoft.com":
        return None
    query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    query.append(("max_size", str(size)))
    return urllib.parse.urlunparse(parsed._replace(query=urllib.parse.urlencode(query)))


class PublicCatalog:
    def __init__(self, cancelled=lambda: False):
        self.cancelled = cancelled
        self._tokens = {}
        self._token_lock = threading.Lock()

    def json_request(self, url, payload=None):
        if self.cancelled():
            raise CatalogError("Operação cancelada.")
        parsed = urllib.parse.urlparse(url)
        try:
            allowed = (parsed.scheme == "https" and parsed.hostname == "planetarycomputer.microsoft.com"
                       and parsed.port in (None, 443) and not parsed.username and not parsed.password
                       and parsed.path.startswith(("/api/stac/v1/", "/api/sas/v1/")))
            allowed = allowed or (parsed.scheme == "https" and parsed.hostname == "data.inpe.br" and parsed.port in (None, 443) and not parsed.username and not parsed.password and parsed.path.startswith("/bdc/stac/v1/"))
            allowed = allowed or (parsed.scheme == 'https' and parsed.hostname == 'earth-search.aws.element84.com' and parsed.port in (None,443) and not parsed.username and not parsed.password and parsed.path.startswith('/v1/'))
        except ValueError as exc:
            raise CatalogError("Endereço inválido do catálogo público.") from exc
        if not allowed:
            raise CatalogError("A consulta exige HTTPS no servidor autorizado do catálogo.")
        from .public_http import request
        try:
            return json.loads(request(url, payload, self.cancelled).decode('utf-8'))
        except (ValueError, UnicodeError) as exc:
            raise CatalogError('Resposta inválida do catálogo público.') from exc

    def search(self, collections, rect, start, end, next_link=None):
        if next_link:
            url = next_link.get("href", "")
            if not url.startswith("https://planetarycomputer.microsoft.com/api/stac/v1/"):
                raise CatalogError("Endereço de paginação inválido.")
            method = next_link.get("method", "GET").upper()
            if method not in ("POST", "GET"):
                raise CatalogError("Método de paginação inválido.")
            if method == "POST":
                payload = next_link.get("body") or {}
                if next_link.get("merge"):
                    payload = {**search_payload(collections, rect, start, end), **payload}
            else:
                payload = None
        else:
            url = STAC_URL
            payload = search_payload(collections, rect, start, end)
        if payload is not None and set(collections) == {'modis-09A1-061'}:
            payload.pop('query', None)
            payload['sortby'] = [{'field': 'start_datetime', 'direction': 'desc'}]
        response = self.json_request(url, payload)
        if response.get("type") != "FeatureCollection":
            raise CatalogError("O catálogo não retornou uma lista de cenas.")
        next_page = next((link for link in response.get("links", [])
                          if link.get("rel") == "next"), None)
        features = response.get("features", [])
        if 'modis-09A1-061' in collections:
            from .extended_sources import normalize_modis
            features = [normalize_modis(item) if item.get('collection') == 'modis-09A1-061' else item for item in features]
        from .hls import HLS_COLLECTIONS, normalize_hls
        features = [normalize_hls(item) if item.get('collection') in HLS_COLLECTIONS else item for item in features]
        return visible_scenes(features), next_page

    def signed_url(self, href):
        with self._token_lock:
            return self._signed_url(href)

    def _signed_url(self, href):
        parsed = urllib.parse.urlparse(href)
        try:
            if parsed.username or parsed.password or parsed.port not in (None,443):
                raise CatalogError('Acesso raster público não aceita credenciais ou portas alternativas.')
        except ValueError as exc:
            raise CatalogError('Endereço raster inválido.') from exc
        host = parsed.hostname or ""
        from .earth_search import ASSET_HOST, public_asset
        if host == ASSET_HOST:
            if public_asset(href): return href
            raise CatalogError('Endereço raster Sentinel-2 AWS inválido.')
        if host == 'data.inpe.br':
            try:
                if parsed.scheme=='https' and parsed.port in (None,443) and not parsed.username and not parsed.password and parsed.path.startswith('/bdc/data/landsat/v2/') and not parsed.query:
                    return href
            except ValueError:pass
            raise CatalogError('Endereço raster INPE inválido.')
        if parsed.scheme != "https" or not host.endswith(".blob.core.windows.net"):
            raise CatalogError("O servidor não forneceu endereço raster válido.")
        container = parsed.path.strip("/").split("/", 1)[0]
        account = host.split(".", 1)[0]
        key = (account, container)
        cached = self._tokens.get(key)
        if cached:
            expires = dict(urllib.parse.parse_qsl(cached.lstrip("?"))).get("se")
            if expires:
                try:
                    expiry = datetime.fromisoformat(expires.replace("Z", "+00:00"))
                    if expiry <= datetime.now(timezone.utc) + timedelta(minutes=5):
                        self._tokens.pop(key, None)
                except (ValueError, TypeError):
                    self._tokens.pop(key, None)
        if key not in self._tokens:
            data = self.json_request(SAS_ENDPOINT + account + "/" + container)
            token = data.get("token", "")
            if not token or "sig=" not in token:
                raise CatalogError("Não foi possível autorizar o acesso público à banda.")
            self._tokens[key] = token.lstrip("?")
        separator = "&" if parsed.query else "?"
        return href + separator + self._tokens[key]

    @staticmethod
    def cached_band_path(item, folder, key, href):
        return os.path.join(folder, safe_name(item.get("id", "cena"), key, href).rsplit(".", 1)[0] + ".tif")

    def cache_bands(self, item, folder, rect, target_crs, progress, keys, offline=False, force_download=False, include_auxiliary=False):
        selected = set(keys)
        assets = [(key, href) for key, href in raster_assets(item, include_auxiliary) if key in selected]
        if not selected or not selected.issubset({key for key, _ in assets}):
            raise CatalogError("Uma das bandas selecionadas não está disponível na cena.")
        os.makedirs(folder, exist_ok=True)
        try:
            from osgeo import gdal
        except ImportError as exc:
            raise CatalogError("O QGIS precisa disponibilizar o GDAL Python para recortar bandas.") from exc
        errors, by_key = [], {}
        config = {"GDAL_DISABLE_READDIR_ON_OPEN": "EMPTY_DIR",
                  "GDAL_HTTP_MULTIRANGE": "YES", "GDAL_HTTP_MULTIPLEX": "YES",
                  "GDAL_HTTP_VERSION": "2TLS", "GDAL_HTTP_CONNECTTIMEOUT": "15",
                  "GDAL_HTTP_TIMEOUT": "45", "GDAL_HTTP_MAX_RETRY": "1",
                  "GDAL_HTTP_RETRY_DELAY": "1"}
        thread_config = getattr(gdal, "SetThreadLocalConfigOption", None)
        set_config = thread_config or gdal.SetConfigOption
        get_config = getattr(gdal, "GetThreadLocalConfigOption", None) if thread_config else None
        get_config = get_config or getattr(gdal, "GetConfigOption", lambda name: None)

        def prepare_unlocked(index_asset):
            index, (key, href) = index_asset
            if self.cancelled():
                raise CatalogError("Operação cancelada.")
            gdal.UseExceptions()
            previous = {name: get_config(name) for name in config}
            for name, value in config.items():
                set_config(name, value)
            target = self.cached_band_path(item, folder, key, href)
            partial = target + ".part.tif"
            try:
                if not force_download and os.path.isfile(target) and os.path.getsize(target) > 0:
                    try:
                        check = gdal.Open(target) if hasattr(gdal, "Open") else True
                        if check is not None:
                            check = None
                            if hasattr(gdal, "Open"):
                                validate_cached_raster(target, gdal, self.cancelled)
                            by_key[key] = target
                            progress("Reutilizando banda local {} ({}/{})".format(key, index, len(assets)))
                            return
                    except Exception:
                        logging.getLogger(__name__).warning("Banda local inválida; será recuperada se houver rede.")
                if offline:
                    errors.append("{}: banda não disponível no acervo local".format(key))
                    return
                progress("Baixando recorte {} ({}/{})".format(key, index, len(assets)))
                attempts=[]
                urls=[href]+item.get('assets',{}).get(key,{}).get('catalog:alternate_hrefs',[])
                for candidate in dict.fromkeys(urls):
                    if self.cancelled():raise CatalogError('Operação cancelada.')
                    try:
                        signed = self.signed_url(candidate)
                        options = gdal.WarpOptions(format="GTiff", outputBounds=context_bbox(rect),
                            outputBoundsSRS="EPSG:4326", dstSRS=target_crs,
                            resampleAlg="near", multithread=True, warpMemoryLimit=32,
                            errorThreshold=0, dstNodata=(255 if key == 'Fmask' else -9999) if item.get('collection') in ('hls2-l30', 'hls2-s30') else (65535 if key == "qa_radsat" else (-28672 if item.get("collection") == "modis-09A1-061" else 0)),
                            srcNodata="None" if key == "qa_radsat" else None,
                            warpOptions=["INIT_DEST=NO_DATA"],
                            creationOptions=["TILED=YES", "COMPRESS=DEFLATE", "PREDICTOR=2"],
                            callback=lambda fraction, message, user_data: 0 if self.cancelled() else 1)
                        result = gdal.Warp(partial, "/vsicurl/" + signed, options=options)
                        if result is None:
                            raise CatalogError("GDAL não conseguiu abrir a banda remota.")
                        result = None
                        if self.cancelled():
                            raise CatalogError("Operação cancelada.")
                        if hasattr(gdal, "Open"):
                            validate_raster(partial, gdal, self.cancelled)
                        os.replace(partial, target)
                        if hasattr(gdal, "Open"):
                            from .storage import receipt
                            receipt(target, self.cancelled)
                        by_key[key] = target
                        item.setdefault('catalog:download_sources',{})[key]=urllib.parse.urlparse(candidate).hostname
                        break
                    except Exception as exc:
                        attempts.append(str(exc))
                        if os.path.exists(partial):os.remove(partial)
                        progress('Tentando outra fonte pública para '+key+'…')
                else:raise CatalogError('; '.join(attempts))
            except Exception as exc:
                if self.cancelled():
                    raise CatalogError("Operação cancelada.") from exc
                errors.append("{}: {}".format(key, exc))
            finally:
                if os.path.exists(partial):
                    os.remove(partial)
                for name, value in previous.items():
                    set_config(name, value)

        def prepare(index_asset):
            from .storage import path_lock
            _, (key, href) = index_asset
            target = self.cached_band_path(item, folder, key, href)
            with path_lock(target, self.cancelled):
                return prepare_unlocked(index_asset)

        indexed = list(enumerate(assets, 1))
        # Each worker owns its GDAL dataset. Older bindings use serial fallback.
        workers = min(3, len(assets)) if thread_config and not offline else 1
        if workers == 1:
            for index_asset in indexed:
                prepare(index_asset)
        else:
            # Resolve shared SAS once in the task thread before GDAL band workers.
            # QGIS proxy configuration and cancellation remain in that thread.
            if not offline:
                for key, href in assets:
                    target = self.cached_band_path(item, folder, key, href)
                    if force_download or not os.path.isfile(target):
                        try:
                            self.signed_url(href)
                        except CatalogError:
                            progress('Acesso primário indisponível; verificando alternativas para ' + key)
            with ThreadPoolExecutor(max_workers=workers) as pool:
                for _ in pool.map(prepare, indexed):
                    pass
        return by_key, errors

    def assess_scene_quality(self, item, folder, rect, target_crs, progress, geometry_wkt, offline=False):
        from .catalog_quality import inspect_qa
        hls = item.get('collection') in ('hls2-l30', 'hls2-s30')
        key = 'Fmask' if hls else ('SCL' if item.get('collection') in ('sentinel-2-l2a','sentinel-2-l2a-aws') else 'qa_pixel')
        paths, errors = self.cache_bands(item, folder, rect, target_crs, progress,
            [key], offline, False, include_auxiliary=True)
        if key not in paths:raise CatalogError('Não foi possível conferir QA no imóvel: '+ '; '.join(errors))
        return inspect_qa(paths[key], 'hls' if hls else ('sentinel' if key == 'SCL' else 'landsat'), geometry_wkt)

    def download_scene(self, item, folder, rect, target_crs, progress, rgb_keys,
                       product="rgb", offline=False, force_download=False):
        from .radiometry import band_set, correction_policy, dos1_file
        from .storage import atomic_json
        policy = correction_policy(item)
        if policy['action'] == 'blocked':
            raise CatalogError(policy['reason'])
        if product == 'bandset':
            rgb_keys = tuple(band_set(item))
            if not rgb_keys:
                raise CatalogError('Não há bandas espectrais neste produto.')
        elif product in INDEX_PRODUCTS:
            rgb_keys = index_keys(item, product)
            if not rgb_keys:
                raise CatalogError("Esta cena não contém as bandas necessárias ao índice selecionado.")
        elif product != "rgb" or len(rgb_keys) != 3:
            raise CatalogError("Escolha as bandas vermelha, verde e azul da composição.")
        by_key, errors = self.cache_bands(item, folder, rect, target_crs, progress,
                                         rgb_keys, offline, force_download)
        if not all(key in by_key for key in rgb_keys):
            raise CatalogError("Não foi possível preparar as bandas: " + "; ".join(errors[:3]))
        # Best-effort local quality masks for automatic temporal screening.
        # Never add QA rasters as visible map layers or abort RGB on QA failure.
        if product in ("rgb", "bandset", *INDEX_PRODUCTS):
            auxiliary = dict(raster_assets(item, include_auxiliary=True))
            qa_keys = [key for key in ("qa_pixel", "qa_radsat", "SCL", "Fmask") if key in auxiliary]
            if qa_keys:
                qa_paths, qa_errors = self.cache_bands(item, folder, rect, target_crs, progress,
                    qa_keys, offline, force_download, include_auxiliary=True)
                errors.extend(qa_errors)
                by_key.update(qa_paths)
        from osgeo import gdal
        if policy['action'] == 'dos1':
            for key in rgb_keys:
                corrected = os.path.join(folder, 'DOS1_' + key + '.tif')
                if force_download or not os.path.isfile(corrected):
                    dos1_file(by_key[key], corrected, item, key, self.cancelled)
                by_key[key] = corrected
            item = dict(item, **{'catalog:correction': 'DOS1'})
        atomic_json(os.path.join(folder, 'band_set.json'),
                    {'collection': item.get('collection'), 'scene': item.get('id'),
                     'spectral_order': band_set(item), 'selected': list(rgb_keys),
                     'correction': policy, 'product': product})
        files = [by_key[key] for key in rgb_keys]
        if product in INDEX_PRODUCTS:
            # Calibration changes must invalidate older derived indices.
            calibration = hashlib.sha256(json.dumps({"keys": list(rgb_keys),
                "coefficients": [reflectance_coefficients(item, key) for key in rgb_keys],
                "profile": 3, "qa": [(k,os.stat(v).st_mtime_ns) for k,v in by_key.items() if k in ("SCL","Fmask","qa_pixel","qa_radsat")]}).encode()).hexdigest()[:12]
            composite = os.path.join(folder, product.upper() + "_" + calibration + ".tif")
            if not os.path.isfile(composite) or any(os.stat(path).st_mtime_ns > os.stat(composite).st_mtime_ns for path in files):
                progress("Calculando {} a partir das reflectâncias…".format(product.upper()))
                partial = composite + ".part.tif"
                try:
                    write_index(item, by_key, partial, gdal, product, self.cancelled)
                    os.replace(partial, composite)
                finally:
                    if os.path.exists(partial):
                        os.remove(partial)
            return files, errors, composite
        nodata = -9999 if item.get('collection') in ('hls2-l30', 'hls2-s30') else (-28672 if item.get('collection') == 'modis-09A1-061' else 0)
        fingerprint = hashlib.sha256(json.dumps({"bands": list(rgb_keys), "resolution": "highest", "nodata": nodata, "profile": 2, "sources": [(key, os.stat(by_key[key]).st_size, os.stat(by_key[key]).st_mtime_ns) for key in rgb_keys]}).encode()).hexdigest()[:12]
        composite = os.path.join(folder, ("BANDSET_" if product == "bandset" else "RGB_") + fingerprint + ".vrt")
        if os.path.isfile(composite) and os.path.getsize(composite) > 0:
            return files, errors, composite
        result = gdal.BuildVRT(composite, [by_key[key] for key in rgb_keys],
                               options=gdal.BuildVRTOptions(separate=True, resolution="highest", resampleAlg="nearest", VRTNodata=nodata))
        if result is None:
            raise CatalogError("Não foi possível montar a composição RGB.")
        result = None
        return files, errors, composite
