# SPDX-License-Identifier: GPL-2.0-or-later
"""Resolve unavailable archive preferences without losing the original location."""
import os
import tempfile

from .stac import CatalogError


def writable_directory(path):
    """Check actual create/write access; os.access is insufficient on Windows."""
    if not path or not str(path).strip():
        raise CatalogError('Escolha uma pasta para o acervo.')
    root = os.path.abspath(os.path.expanduser(path))
    try:
        os.makedirs(root, exist_ok=True)
        with tempfile.TemporaryFile(prefix='.catalogo_write_', dir=root) as probe:
            probe.write(b'catalogo')
            probe.flush()
            os.fsync(probe.fileno())
    except (OSError, ValueError) as exc:
        raise CatalogError('Acervo indisponível ou sem permissão de gravação: {}. '
                           'Conecte a unidade ou use Imagens → Escolher pasta. {}'.format(root, exc)) from exc
    return root


def resolve_archive(preferred, candidates):
    """Use a writable session fallback; never overwrite the saved preference."""
    failures = []
    seen = set()
    for path in [preferred, *candidates]:
        if not path or path in seen:
            continue
        seen.add(path)
        try:
            root = writable_directory(path)
        except CatalogError as exc:
            failures.append(str(exc))
            continue
        if failures:
            original = preferred or 'Pasta padrão'
            return root, ('Acervo anterior indisponível: {}. Usando nesta sessão: {}. '
                          'A preferência anterior foi preservada; os arquivos antigos não foram movidos. '
                          'Para fixar outra pasta ou reconectar o acervo, use Escolher pasta.').format(original, root)
        return root, ''
    # Let the interface open even on a fully read-only profile. Save operations
    # will report the storage error instead of hiding it or discarding tasks.
    return preferred or next((path for path in candidates if path), ''), (
        'Nenhuma pasta de acervo está disponível para gravação. Use Escolher pasta. '
        + ' '.join(failures))
