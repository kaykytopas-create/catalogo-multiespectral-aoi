# SPDX-License-Identifier: GPL-2.0-or-later
"""Real-date common-grid NDVI/NBR differences; no synthetic cloud reconstruction."""
import os
from datetime import date
import numpy as np
from .classification import prepare_raster, mask_geometry, check
from .stac import CatalogError
from .storage import atomic_json
from .reporting_analysis import write_analysis_report


def run_temporal(payload, folder, cancelled=lambda:False, progress=lambda x:None):
    from osgeo import gdal
    from .prodes_auto import qa_valid
    images=payload['images']
    from .preflight import validate_dates
    validate_dates(images)
    dates=[date.fromisoformat(image['date']) for image in images]
    if not 2<=len(images)<=60 or dates!=sorted(set(dates)):raise CatalogError('Escolha de duas a 60 datas distintas, em ordem crescente.')
    if any(not image.get('qa_path') or not os.path.isfile(image['qa_path']) for image in images):raise CatalogError('Cada imagem precisa de sua máscara QA local.')
    os.makedirs(folder,exist_ok=True)
    prepared=dict(payload,**images[0]);prepared['resolution']=max(image.get('resolution',0) for image in images);reference=prepare_raster(prepared,folder,cancelled);grid=gdal.Open(reference)
    gt=grid.GetGeoTransform();bounds=(gt[0],gt[3]+grid.RasterYSize*gt[5],gt[0]+grid.RasterXSize*gt[1],gt[3])
    inside=mask_geometry(grid,[payload['geometry']])!=0;common=inside.copy();indices=[]
    for image in images:
        check(cancelled);progress('Lendo e alinhando '+image['date'])
        ds=gdal.Warp('',image['path'],format='MEM',dstSRS=grid.GetProjection(),outputBounds=bounds,width=grid.RasterXSize,height=grid.RasterYSize,resampleAlg='near',dstNodata=-9999,outputType=gdal.GDT_Float32)
        channels=[];valid=inside.copy()
        for key in ('nir','red','swir'):
            number=image['index_bands'][key];raw=ds.GetRasterBand(number).ReadAsArray();scale,offset=image['coefficients'][number-1]
            valid &= np.isfinite(raw)&(raw!=-9999)
            values=raw*scale+offset;valid&=(values>=0)&(values<=1.5);channels.append(values)
        nir,red,swir=channels;valid&=(nir+red>1e-6)&(nir+swir>1e-6)
        if image.get('qa_path'):
            qa=gdal.Warp('',image['qa_path'],format='MEM',dstSRS=grid.GetProjection(),outputBounds=bounds,width=grid.RasterXSize,height=grid.RasterYSize,resampleAlg='near',dstNodata=255)
            valid&=qa_valid(qa.ReadAsArray(),image['qa_kind'])
        if image.get('saturation_path'):
            saturation=gdal.Warp('',image['saturation_path'],format='MEM',dstSRS=grid.GetProjection(),outputBounds=bounds,width=grid.RasterXSize,height=grid.RasterYSize,resampleAlg='near',dstNodata=65535)
            valid &= saturation.ReadAsArray()==0
        ndvi=np.divide(nir-red,nir+red,out=np.full(nir.shape,np.nan),where=valid)
        nbr=np.divide(nir-swir,nir+swir,out=np.full(nir.shape,np.nan),where=valid)
        indices.append((ndvi,nbr));common&=valid
    if common.sum()<9:raise CatalogError('Menos de nove pixels comuns válidos; escolha outras imagens.')
    differences=[indices[-1][0]-indices[0][0],indices[-1][1]-indices[0][1]];paths=[]
    for name,values in zip(('delta_ndvi','delta_nbr'),differences):
        check(cancelled);dest=os.path.join(folder,name+'.tif');partial=dest+'.part.tif'
        try:
            ds=gdal.GetDriverByName('GTiff').Create(partial,grid.RasterXSize,grid.RasterYSize,1,gdal.GDT_Float32,['TILED=YES','COMPRESS=DEFLATE']);ds.SetProjection(grid.GetProjection());ds.SetGeoTransform(gt)
            ds.GetRasterBand(1).SetNoDataValue(-9999);ds.GetRasterBand(1).WriteArray(np.where(common,values,-9999));ds=None;os.replace(partial,dest);paths.append(dest)
        finally:
            if os.path.isfile(partial):os.remove(partial)
    pixel_ha=abs(gt[1]*gt[5])/10000
    result={'type':'temporal','path':paths[0],'nbr_path':paths[1],'dates':[i['date'] for i in images],
            'series':[{'date':image['date'],'ndvi':float(values[0][common].mean()),'nbr':float(values[1][common].mean())} for image,values in zip(images,indices)],
            'valid_ha':int(common.sum())*pixel_ha,'decrease_ha':int((common&(differences[0]<-payload.get('threshold',.2))).sum())*pixel_ha,
            'threshold':payload.get('threshold',.2),'source':[image['source_info'] for image in images],
            'limitations':'Somente pixels válidos comuns nas duas datas. Diferenças de sensor, atmosfera, estação e manejo podem afetar os índices. Limiar exploratório, sem equivalência automática a PRODES. Quedas fora dos pixels comuns não foram estimadas.'}
    result['report']=write_analysis_report(result,folder);atomic_json(os.path.join(folder,'resultado.json'),result);return result
