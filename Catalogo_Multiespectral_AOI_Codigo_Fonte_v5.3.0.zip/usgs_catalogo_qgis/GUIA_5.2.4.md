# Catálogo Multiespectral 5.2.4 — guia rápido

INSTALAÇÃO
No QGIS, abra Complementos > Gerenciar e instalar complementos > Instalar a partir de ZIP.
Selecione Catalogo_Multiespectral_AOI_QGIS_v5.2.4.zip e instale. Reinicie o QGIS para carregar
todos os módulos atualizados. O ZIP Codigo_Fonte é para desenvolvimento, não para instalação.
Esta entrega não substituiu automaticamente seu plugin instalado nem seu projeto aberto.

1. BANDAS E ANÁLISE
Carregue no QGIS o polígono do imóvel/área de interesse.
Em “1. Buscar imagens”, selecione o imóvel, período e satélite; busque e selecione uma cena.
Em “2. Bandas e água”, clique em “Imagem da busca → baixar Band Set completo”.
O Band Set mantém as bandas, calibração e informações de qualidade necessárias às análises.
Depois selecione essa imagem na análise local, escolha o índice e execute. O andamento e
os resultados aparecem dentro de Comparação temporal. Uma imagem RGB comum não substitui
um Band Set: pode não conter infravermelho, SWIR ou a máscara de qualidade.
Para uma composição visual, escolha a opção de bandas e clique em “Prévia e importar a opção
de bandas escolhida”. A prévia abre após preparar a imagem em segundo plano. Confira e clique em Importar esta composição.
Em “3. Acervo local”, consulte os arquivos já baixados. Downloads precisam de internet;
arquivos disponíveis no acervo podem ser usados offline. Nenhuma conta de IA é necessária.

COMO ESCOLHER UM ÍNDICE
NDWI = (verde − infravermelho próximo)/(verde + infravermelho próximo): água superficial.
MNDWI = (verde − SWIR1)/(verde + SWIR1): contraste de água e áreas construídas.
NDMI = (infravermelho próximo − SWIR1)/(infravermelho próximo + SWIR1): umidade da vegetação.
NDTI = (vermelho − verde)/(vermelho + verde): contraste exploratório associado à turbidez.
NDVI: vegetação. NBR: resposta da vegetação/solo no infravermelho e SWIR2.
As opções RGB também incluem margens de água e umidade, além de cor natural e bandas livres.
Nuvens e pixels inválidos são excluídos pela qualidade disponível. SWIR Sentinel-2 é analisado
a pelo menos 20 m; aumentar a quantidade de pixels não cria detalhe espacial verdadeiro.
Índices não medem vazão, profundidade, volume, potabilidade, concentração de sedimentos ou NTU.
NDMI não representa porcentagem de umidade do solo. Confirme a interpretação com dados locais.

NOVA FONTE DE DADOS DE ÁGUA
Em “2. Bandas e água”, escolha a variável JRC e baixe para a área selecionada:
• Ocorrência: frequência histórica de observação de água, em porcentagem.
• Recorrência: recorrência histórica da presença de água, em porcentagem.
• Extensão máxima: presença de água observada no registro, codificada como 0/1.
São produtos JRC Global Surface Water v1.5 do período 1984–2024, não uma imagem da data atual.
O recorte cobre o retângulo da área; bordas externas ao polígono podem continuar visíveis.
Pedidos muito grandes são recusados: reduza a área. Arquivos ficam no acervo local.
Fontes de cenas existentes: Microsoft Planetary Computer, INPE/Brazil Data Cube, AWS Earth
Search e NASA HLS conforme o catálogo disponível. Copernicus Browser e USGS EarthExplorer
são atalhos para portais externos, com eventual cadastro; não são novos conectores automáticos.

2. COMPARAÇÃO TEMPORAL
Prepare Band Sets para duas ou mais datas. Abra Comparação temporal, selecione o imóvel e
marque as imagens usando Ctrl. Confira/edite as datas, escolha o índice e clique em Comparar.
São aceitas 2 a 60 datas distintas. As imagens são alinhadas em uma grade comum e somente
pixels válidos em todas as datas entram nos resultados. Isso evita comparar áreas diferentes.
Para NDWI/MNDWI, o limiar inicial de água é zero (índice maior que o limiar). Ajuste-o conforme
a área e confira visualmente: a área em hectares é exploratória, não uma delimitação oficial.
A saída inclui índices por data, diferença última menos primeira, tabela CSV, relatório HTML
e proveniência. A diferença pode variar de −2 a +2. Os arquivos originais são preservados.

3. CARTA-IMAGEM
Selecione o imóvel, a imagem e as camadas vetoriais desejadas. Escolha o formato, preencha
os textos e gere o layout. Confira título, datas, legenda e escala no QGIS antes de exportar.
O layout é editável e pode gerar PDF/PNG e modelo QPT reutilizável.

O QUE MUDOU
A interface possui cinco abas. Situação fundiária e Analisar PRODES foram restauradas.
Classificação supervisionada continua oculta. As melhorias de água da versão 5.2.0 permanecem.
Os arquivos antigos do acervo não foram apagados. A fila fica dentro da comparação temporal.

FONTES E DOCUMENTAÇÃO
JRC (produtos, versão e limitações): https://global-surface-water.appspot.com/download
JRC (download): https://global-surface-water.appspot.com/gsw/Download_Instructions.html
NDWI: https://custom-scripts.sentinel-hub.com/custom-scripts/sentinel-2/ndwi/
MNDWI: https://science.data.nasa.gov/disasters/data-gallery/landsat-mndwi
NDMI: https://www.usgs.gov/publications/terminology-spectral-vegetation-index-nir-swirnir-swir
Copernicus: https://browser.dataspace.copernicus.eu/
USGS: https://earthexplorer.usgs.gov/

VERSÃO NÃO EXPERIMENTAL
O metadata.txt declara version=5.2.4 e experimental=False. A descrição detalha funções,
fontes e limitações desta versão. A aprovação/publicação no repositório oficial do QGIS
é uma etapa separada; esta entrega não foi enviada nem aprovada pelo repositório.

FUNÇÕES RESTAURADAS NA 5.2.4
Situação fundiária: abra a aba, confira o limite do imóvel, UF e campos disponíveis;
execute a consulta e acompanhe os resultados e o relatório. O módulo inclui a triagem
ambiental/fundiária original. Algumas fontes dependem da internet e da disponibilidade do serviço.
Analisar PRODES: abra a aba, confira o imóvel, escolha a base anual/bioma ou uma camada
local e use os controles de consulta, análise e relatório já existentes. Também há um
atalho Analisar PRODES no menu Raster > Catálogo Multiespectral.
Selecionar o imóvel em Buscar imagens compartilha essa seleção com as abas restauradas;
é possível escolher outro imóvel diretamente nelas. Confira os campos antes de executar.
Resultados de triagem e interpretação assistida precisam de revisão técnica; não determinam
por si só a regularidade fundiária ou a conclusão jurídica de uma situação.

Correção 5.2.4: caminhos temporários do teste de normalização usam TemporaryDirectory.
Situação fundiária, Analisar PRODES e as melhorias hídricas permanecem disponíveis.

Revisão 5.2.4: corrige E731 no relatório hídrico e remove imports não utilizados.

REVISÃO DE RESPONSIVIDADE 5.2.4 — 23/11/2026
Atalhos como Vegetação, Solo exposto e NDVI agora apenas selecionam a opção de bandas.
O download começa ao clicar explicitamente em Prévia e importar. A preparação do contraste
e a inspeção dos pixels dessa prévia passam para uma tarefa em segundo plano.
A janela de prévia usa abertura assíncrona. Aguarde a conclusão ou use Cancelar tarefa.
As cinco abas, o acervo existente e a marcação não experimental foram preservados.
