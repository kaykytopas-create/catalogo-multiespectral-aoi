# Revisão 5.3.0 — 23/11/2026

## Achados e correções

A versão recente construía controles de vários módulos ocultos ao abrir. O novo
fluxo reduz isso e adia situação fundiária, PRODES e carta-imagem até abrir cada aba.
Leituras de todas as feições antes de validar o imóvel foram substituídas por leitura
limitada a duas feições quando só se admite um imóvel; seleções excessivas são rejeitadas cedo.
O cálculo integral de índices tem limite de 4 milhões de pixels antes de alocar arrays.

Foram mantidas as proteções de downloads sequenciais, miniaturas sob demanda com
cache de 16 imagens, preparação de contraste/prévia em segundo plano e cancelamento
sem espera ao fechar. Callbacks descartam resultados cancelados e tratam exceções
sem novo diálogo modal. O resultado retém o contexto da tarefa mesmo se o sinal de
conclusão chegar antes, evitando repetir a persistência do acervo na interface.

Foi observada falha real de leitura/escrita do acervo em D: quando essa unidade
não estava disponível. O plugin agora verifica e grava o catálogo em segundo plano,
preserva a preferência e os arquivos anteriores e comunica a falha. A abertura da
janela compacta não testa nem cria pastas de acervo.

Também há registros de falha nativa do Qt (access violation/stack overflow), sem
pilha suficiente para atribuir a causa exata ao plugin. Essa queda não foi reproduzida
conclusivamente. O aviso de gdalnumeric mostrado anteriormente pertence a outro
complemento. Não se afirma que todo fechamento ou perda de projeto tenha uma só causa.

## Validação

307 testes passaram, sem falhas, erros ou testes ignorados, em processo separado
QGIS 3.44.7/Python 3.12 no Windows, com configurações de teste isoladas. Incluem abas
carregadas sob demanda, bandas de água na primeira página, NASA, seleção sem importar,
limites de leitura/memória, perda de unidade, resultados tardios e cancelamento.
Inspeção visual das quatro abas em processo de teste, sem abrir o projeto do usuário.
Bandit 1.9.4: zero apontamentos e zero erros, regras padrão sem supressões.
Flake8 7.5.0: zero nas regras F,E711,E712,E713,E714,E721,E722,E731,E741,E742,E743,E9.
Sintaxe Python, metadados, CRC dos ZIPs e equivalência dos arquivos validados.

## Comparação de abertura

Três execuções independentes por versão, projeto vazio, QGIS offscreen. Medianas:

- 3.5.3 antiga: 125 controles; 10 módulos; 0.103 s; 5.19 MiB adicionais de memória privada.

- 5.2.6 recente: 617 controles; 34 módulos; 0.297 s; 12.62 MiB adicionais de memória privada.

- 5.3.0 compacta: 137 controles; 10 módulos; 0.056 s; 4.32 MiB adicionais de memória privada.

Essas medições abrangem importação e construção da janela, não a memória total do
QGIS nem o processamento em projetos reais. Cache, disco e ambiente influenciam o
tempo; não representam garantia de velocidade ou ausência de travamentos.

Não houve instalação ou reativação desta versão no perfil do usuário. Nenhum projeto
ou acervo foi movido, apagado ou salvo por esta entrega. A descrição foi atualizada
e experimental=False mantido; isso não equivale a aprovação oficial ou certificação.
