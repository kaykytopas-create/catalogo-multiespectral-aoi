# SPDX-License-Identifier: GPL-2.0-or-later
"""Prepare display data with independent GDAL handles in a background task."""
import math


def prepare_display(path, bands=(1, 2, 3), geometry=None, cancelled=lambda: False):
    from osgeo import gdal
    import numpy as np
    from .stac import CatalogError
    from .raster_quality import inspect_raster
    limits = {}
    dataset = gdal.Open(path)
    if dataset is None:
        raise CatalogError('Não foi possível preparar a prévia local.')
    try:
        factor = max(1, math.ceil(max(dataset.RasterXSize, dataset.RasterYSize) / 512))
        width = max(1, dataset.RasterXSize // factor)
        height = max(1, dataset.RasterYSize // factor)
        for channel, number in enumerate(bands, 1):
            if cancelled():
                raise CatalogError('Operação cancelada.')
            band = dataset.GetRasterBand(number)
            data = band.ReadAsArray(buf_xsize=width, buf_ysize=height)
            if data is None:
                raise CatalogError('Falha ao ler a amostra da prévia.')
            valid = np.isfinite(data)
            nodata = band.GetNoDataValue()
            if nodata is not None:
                valid &= data != nodata
            valid &= band.GetMaskBand().ReadAsArray(buf_xsize=width, buf_ysize=height) != 0
            values = data[valid]
            low, high = np.percentile(values, [2, 98]) if values.size else (0., 1.)
            scale, offset = band.GetScale(), band.GetOffset()
            scale = 1. if scale is None else scale
            offset = 0. if offset is None else offset
            low, high = sorted((float(low) * scale + offset, float(high) * scale + offset))
            if high <= low:
                high = low + 1.
            limits[str(channel)] = [low, high]
            band = None
    finally:
        band = None
        dataset = None
    if cancelled():
        raise CatalogError('Operação cancelada.')
    quality = inspect_raster(path, geometry) if geometry else None
    if cancelled():
        raise CatalogError('Operação cancelada.')
    return {'limits': limits, 'quality': quality}
