# SPDX-License-Identifier: GPL-2.0-or-later
"""Offline inventory, explicit deep verification and legacy index migration."""
import json
import os
from qgis.PyQt.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,
    QTableWidget,QTableWidgetItem,QHeaderView,QAbstractItemView,QMessageBox)
from qgis.core import QgsRasterLayer,QgsProject
from .tasks import TaskWorker
from .storage import AssetIndex


class ArchiveJob(TaskWorker):
    def __init__(self,root,action,path=None):
        super().__init__(description='Catálogo · acervo offline')
        self.root,self.action,self.path=root,action,path

    def work(self):
        index=AssetIndex(self.root)
        if self.action=='audit':
            value=index.audit(lambda:self.stopping,self.status.emit)
        elif self.action=='reindex':
            value=index.reindex(lambda:self.stopping,self.status.emit)
        elif self.action=='open':
            from osgeo import gdal
            from .stac import validate_cached_raster
            path=os.path.join(index.root,self.path);index.relative(path)
            validate_cached_raster(path,gdal,lambda:self.stopping)
            value=path
        else:
            if not os.path.isfile(index.path):
                index.reindex(lambda:self.stopping,self.status.emit)
            value=index.rows()
        self.result.emit(value)


class ArchiveTab(QWidget):
    def __init__(self,owner):
        super().__init__(owner);self.owner,self.job,self.rows=owner,None,[]
        layout=QVBoxLayout(self)
        self.folder=QLabel();self.folder.setWordWrap(True);layout.addWidget(self.folder)
        note=QLabel('Reabrir usa apenas arquivos locais. A verificação completa lê blocos e compara SHA-256. Para acervos antigos, use Indexar pastas existentes uma vez. Nenhum arquivo válido é apagado.');note.setWordWrap(True);layout.addWidget(note)
        row=QHBoxLayout();self.choose=QPushButton('Escolher pasta');self.refresh=QPushButton('Atualizar lista')
        self.reindex=QPushButton('Indexar pastas existentes');self.audit=QPushButton('Verificar integridade completa')
        for button in (self.choose,self.refresh,self.reindex,self.audit):row.addWidget(button)
        layout.addLayout(row)
        self.table=QTableWidget(0,4);self.table.setHorizontalHeaderLabels(['Data','Cena / produto','Tipo','Tamanho (MB)'])
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.table,1)
        row=QHBoxLayout();self.open=QPushButton('Reabrir selecionado no QGIS');self.open.setMinimumHeight(44)
        self.stop=QPushButton('Cancelar');self.stop.setEnabled(False);row.addWidget(self.open);row.addWidget(self.stop);layout.addLayout(row)
        self.info=QLabel('Atualize a lista para consultar o índice local.');self.info.setWordWrap(True);layout.addWidget(self.info)
        self.choose.clicked.connect(self.choose_folder);self.refresh.clicked.connect(lambda:self.launch('list'))
        self.reindex.clicked.connect(lambda:self.launch('reindex'));self.audit.clicked.connect(lambda:self.launch('audit'))
        self.open.clicked.connect(self.reopen);self.stop.clicked.connect(self.cancel)
        self.folder.setText(owner.archive_path)

    def choose_folder(self):
        self.owner.select_archive_folder();self.folder.setText(self.owner.archive_path);self.launch('list')

    def launch(self,action,path=None):
        if self.job:return
        self.folder.setText(self.owner.archive_path)
        self.job=ArchiveJob(self.owner.archive_path,action,path)
        self.job.result.connect(lambda value:self.completed(action,value))
        self.job.failed.connect(self.error);self.job.status.connect(self.info.setText);self.job.done.connect(self.finished)
        for button in (self.choose,self.refresh,self.reindex,self.audit,self.open):button.setEnabled(False)
        self.stop.setEnabled(True);self.job.start()

    def completed(self,action,value):
        if action=='list':
            self.rows=value;self.table.setRowCount(0)
            for row in value:
                metadata=json.loads(row['metadata']);number=self.table.rowCount();self.table.insertRow(number)
                fields=[str(metadata.get('datetime',''))[:10],metadata.get('id') or row['scene'],row['kind'],str(round(row['size']/1024**2,2))]
                for col,text in enumerate(fields):self.table.setItem(number,col,QTableWidgetItem(text))
            self.info.setText('{} arquivos indexados; reabertura sem rede.'.format(len(value)))
        elif action=='audit':
            errors=[row for row in value if row['status']!='ok']
            self.info.setText('{} arquivos verificados; {} divergentes. {}'.format(len(value),len(errors),' · '.join(row['path']+': '+row['error'] for row in errors[:5])))
        elif action=='reindex':
            self.info.setText('{} arquivos indexados; {} não aceitos. Atualize a lista.'.format(value['indexed'],len(value['errors'])))
        else:
            layer=QgsRasterLayer(value,os.path.basename(value),'gdal')
            if not layer.isValid():self.error('O QGIS não reconheceu o arquivo.');return
            if os.path.isfile(value+'.qml'):layer.loadNamedStyle(value+'.qml')
            QgsProject.instance().addMapLayer(layer);self.info.setText('Arquivo reaberto sem download; estilo local aplicado quando disponível.')

    def reopen(self):
        row=self.table.currentRow()
        if row>=0:self.launch('open',self.rows[row]['path'])

    def cancel(self):
        if self.job:self.job.cancel()

    def error(self,message):
        self.info.setText(message);QMessageBox.warning(self,'Acervo offline',message)

    def finished(self):
        self.job=None
        for button in (self.choose,self.refresh,self.reindex,self.audit,self.open):button.setEnabled(True)
        self.stop.setEnabled(False)
