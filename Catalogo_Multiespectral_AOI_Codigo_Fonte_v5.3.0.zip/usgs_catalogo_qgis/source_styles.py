# SPDX-License-Identifier: GPL-2.0-or-later
"""Ready display profiles for complementary sources; original pixels untouched."""
import math
from .stac import CatalogError,reflectance_coefficients,preset_keys,natural_rgb_keys
from .radiometry import band_set

THERMAL_RAMP=((200,'#48186a'),(230,'#355fba'),(260,'#26acd1'),
              (280,'#50bc77'),(295,'#e6d74a'),(310,'#f58c32'),(330,'#b81931'))


def display_profile(path,item,product,cancelled=lambda:False):
    from osgeo import gdal
    import numpy as np
    dataset=gdal.Open(path)
    if dataset is None:raise CatalogError('Raster preparado não pôde ser aberto para visualização.')
    kind=item.get('catalog:kind')
    keys=band_set(item) if product=='bandset' else preset_keys(item,product)
    rgb=natural_rgb_keys(item) if product=='bandset' else keys
    numbers=[keys.index(key)+1 for key in rgb] if product=='bandset' and rgb else list(range(1,min(3,dataset.RasterCount)+1))
    is_rgb=kind not in ('thermal','categorical') and product not in ('ndvi','nbr') and len(rgb)==3
    if not is_rgb:numbers=[1]
    mode='rgb' if is_rgb else ('thermal' if kind=='thermal' else 'original')
    profile={'mode':mode,'bands':numbers,'limits':[],'uniform':False}
    common_valid=None
    all_zero=True
    for number,key in zip(numbers,rgb if is_rgb else ['value']):
        if cancelled():raise CatalogError('Visualização cancelada.')
        band=dataset.GetRasterBand(number)
        array=band.ReadAsArray(buf_xsize=min(512,dataset.RasterXSize),buf_ysize=min(512,dataset.RasterYSize))
        valid=np.isfinite(array)
        nodata=band.GetNoDataValue()
        if nodata is not None:valid &= array!=nodata
        mask=band.GetMaskBand().ReadAsArray(buf_xsize=array.shape[1],buf_ysize=array.shape[0])
        valid &= mask!=0
        common_valid=valid if common_valid is None else common_valid&valid
        values=array[valid]
        if not values.size:raise CatalogError('Produto sem pixels válidos no recorte. Escolha outra cena ou período; uma camada vazia não será importada.')
        all_zero=all_zero and bool(np.all(values==0))
        if is_rgb:
            low,high=map(float,np.percentile(values,(2,98)))
            if not math.isfinite(low) or not math.isfinite(high) or high<=low:
                scale,offset=reflectance_coefficients(item,key)
                low,high=(0-offset)/scale,(.4-offset)/scale
                profile['uniform']=True
            profile['limits'].append([low,high])
    if common_valid is None or not np.any(common_valid):
        raise CatalogError('Não há pixels válidos comuns às bandas selecionadas. Escolha outra cena.')
    if is_rgb and all_zero:
        raise CatalogError('As bandas retornaram apenas zeros no recorte, sem sinal espectral útil. Escolha outra data/cena; a composição preta não será importada.')
    # Natural color uses the same physical interval on each channel.
    if is_rgb and tuple(rgb)==tuple(natural_rgb_keys(item)):
        profile['limits']=[[(0-reflectance_coefficients(item,key)[1])/reflectance_coefficients(item,key)[0],
                            (.3-reflectance_coefficients(item,key)[1])/reflectance_coefficients(item,key)[0]] for key in rgb]
    return profile


def apply_profile(layer,profile):
    from qgis.core import (QgsMultiBandColorRenderer,QgsContrastEnhancement,QgsColorRampShader,
                           QgsRasterShader,QgsSingleBandPseudoColorRenderer)
    from qgis.PyQt.QtGui import QColor
    provider=layer.dataProvider()
    if profile['mode']=='thermal':
        ramp=QgsColorRampShader(200,330)
        ramp.setColorRampType(QgsColorRampShader.Type.Interpolated)
        ramp.setColorRampItemList([QgsColorRampShader.ColorRampItem(value,QColor(color),
            '{} K ({:.1f} °C)'.format(value,value-273.15)) for value,color in THERMAL_RAMP])
        shader=QgsRasterShader(200,330);shader.setRasterShaderFunction(ramp)
        renderer=QgsSingleBandPseudoColorRenderer(provider,1,shader)
        renderer.setClassificationMin(200);renderer.setClassificationMax(330)
        layer.setRenderer(renderer)
        layer.setCustomProperty('catalogo_visualizacao','GOES C13 · temperatura de brilho em Kelvin · escala colorida 200–330 K')
    elif profile['mode']=='rgb':
        renderer=QgsMultiBandColorRenderer(provider,*profile['bands'])
        setters=(renderer.setRedContrastEnhancement,renderer.setGreenContrastEnhancement,renderer.setBlueContrastEnhancement)
        for number,limits,setter in zip(profile['bands'],profile['limits'],setters):
            enhancement=QgsContrastEnhancement(provider.dataType(number))
            enhancement.setContrastEnhancementAlgorithm(QgsContrastEnhancement.ContrastEnhancementAlgorithm.StretchToMinimumMaximum)
            scale,offset=float(provider.bandScale(number)),float(provider.bandOffset(number))
            low,high=sorted((limits[0]*scale+offset,limits[1]*scale+offset))
            if not math.isfinite(low) or not math.isfinite(high) or high<=low:
                raise CatalogError('Escala do provedor raster inválida para configurar o contraste.')
            enhancement.setMinimumValue(low);enhancement.setMaximumValue(high);setter(enhancement)
        layer.setRenderer(renderer)
        layer.setCustomProperty('catalogo_visualizacao','RGB configurado; contraste com pixels válidos e faixa física de segurança para canais constantes')
    layer.triggerRepaint()
