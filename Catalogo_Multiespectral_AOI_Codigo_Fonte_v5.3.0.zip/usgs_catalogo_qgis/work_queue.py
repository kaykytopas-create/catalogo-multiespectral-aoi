# SPDX-License-Identifier: GPL-2.0-or-later
"""Durable local queue: frozen inputs, cooperative cancellation, restart/retry."""
import json
import os
import time
import uuid
from pathlib import Path
from .storage import atomic_json, path_lock, sha256
from .tasks import TaskWorker
from .stac import CatalogError


class QueueStore:
    def __init__(self,root):
        self.root=os.path.abspath(root);self.path=os.path.join(self.root,'fila_tarefas.json')
    def read(self):
        try:
            with open(self.path,encoding='utf8') as stream:return json.load(stream)['jobs']
        except FileNotFoundError:return []
        except (OSError,ValueError,KeyError) as exc:raise CatalogError('Não foi possível ler a fila salva; preserve o arquivo para recuperação: '+self.path) from exc
    def save(self,rows):
        try:atomic_json(self.path,{'version':1,'jobs':rows})
        except OSError as exc:raise CatalogError('Não foi possível salvar a fila no acervo: '+self.root+'. Conecte a unidade ou use Imagens → Escolher pasta. '+str(exc)) from exc
    def add(self,action,payload):
        with path_lock(self.path):
            rows=self.read();row={'id':uuid.uuid4().hex,'action':action,'payload':payload,'state':'pendente','message':'Aguardando execução','created':time.time()}
            rows.append(row);self.save(rows);return row
    def update(self,identity,**changes):
        with path_lock(self.path):
            rows=self.read()
            for row in rows:
                if row['id']==identity:row.update(changes)
            self.save(rows)
    def recover(self):
        with path_lock(self.path):
            rows=self.read();changed=False
            for row in rows:
                if row['state']=='executando':
                    row.update(state='interrompida',message='Execução anterior interrompida; selecione Retomar.');changed=True
            if changed:self.save(rows)


def input_signatures(payload):
    from osgeo import gdal
    paths=[payload.get('path'),payload.get('qa_path'),payload.get('saturation_path')]+[image.get(key) for image in payload.get('images',[]) for key in ('path','qa_path','saturation_path')]
    result={}
    for path in paths:
        if not path:continue
        ds=gdal.Open(path)
        if ds is None:raise CatalogError('Arquivo de entrada indisponível: '+path)
        for file in ds.GetFileList() or [path]:
            if not os.path.isfile(file):raise CatalogError('A análise exige bandas locais no acervo; reabra/baixe o Band Set.')
            result[os.path.abspath(file)]=sha256(file)
    return result


class QueueWorker(TaskWorker):
    def __init__(self,store,allowed_actions=None):
        super().__init__(description='Catálogo · fila de análises');self.store=store;self.allowed_actions=allowed_actions
    def work(self):
        from .classification import run_classification
        from .temporal import run_temporal
        from .storage import AssetIndex
        for job in self.store.read():
            if self.stopping:break
            if job['state']!='pendente':continue
            if self.allowed_actions is not None and job['action'] not in self.allowed_actions:continue
            identity=job['id'];start=time.monotonic();self.store.update(identity,state='executando')
            try:
                fingerprints=input_signatures(job['payload'])
                if job.get('inputs') and fingerprints!=job['inputs']:raise CatalogError('Entradas foram alteradas desde a execução anterior. Crie uma nova tarefa para esses dados.')
                self.store.update(identity,inputs=fingerprints)
                folder=str(Path(self.store.root)/'analises'/identity)
                def progress(message):
                    self.status.emit(message)
                    self.store.update(identity,message=message,elapsed_seconds=round(time.monotonic()-start,1))
                if job['action']=='classification':result=run_classification(job['payload'],folder,lambda:self.stopping,progress)
                elif job['action']=='temporal':result=run_temporal(job['payload'],folder,lambda:self.stopping,progress)
                elif job['action'] in ('spectral','temporal_index'):
                    from .hydrology import run_indices
                    result=run_indices(job['payload'],folder,lambda:self.stopping,progress)
                elif job['action']=='download':
                    from .archive import LocalArchive
                    from .public_sources import MultiCatalog
                    from .commands import download_batch
                    p=job['payload'];archive=LocalArchive(self.store.root,p['rect'],p['crs'])
                    def ready(event):
                        if p['plan'].get('auto_import'):self.result.emit(dict(event,type='queue_image',preset=p['plan']['preset']))
                    result=download_batch(MultiCatalog(lambda:self.stopping),archive,p['plan'],progress,True,on_ready=ready)
                    result['type']='download'
                else:raise CatalogError('Tipo de tarefa desconhecido.')
                result['input_checksums']=fingerprints
                if result.get('report'):
                    from .reporting_analysis import write_analysis_report
                    result['report']=write_analysis_report(result,folder)
                    atomic_json(os.path.join(folder,'resultado.json'),result)
                self.store.update(identity,state='concluida',result=result,message='Concluída',elapsed_seconds=round(time.monotonic()-start,1))
                for path in Path(folder).glob('*.tif'):
                    if path.name=='entrada_alinhada.tif':continue
                    acquired=(result.get('dates') or [''])[-1] if result.get('dates') else result.get('source',{}).get('date','')
                    AssetIndex(self.store.root).register(str(path),'analises',identity,path.stem,{'id':job['action']+' · '+path.stem+' · '+identity[:8],'datetime':acquired},lambda:self.stopping)
                self.result.emit(result)
            except Exception as exc:
                self.store.update(identity,state='interrompida' if self.stopping else 'falha',message=str(exc),elapsed_seconds=round(time.monotonic()-start,1))
                self.status.emit(str(exc))
                if self.stopping:break
