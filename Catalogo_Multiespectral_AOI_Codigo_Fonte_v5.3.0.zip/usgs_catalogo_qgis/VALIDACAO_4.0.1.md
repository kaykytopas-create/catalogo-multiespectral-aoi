# Validação 4.0.1 · correção de fontes e visualização

## Seleção do imóvel

Reproduzido o fluxo da versão 4.0: Fontes complementares dependia da camada indicada no campo da aba Imagens. Quando esse campo apontava para uma camada vazia/diferente, a seleção de um polígono em outra camada não era utilizada e a tarefa era interrompida antes de consultar a fonte.

A aba agora tem seu próprio seletor visível de imóvel. Na escolha inicial, reconhece uma única camada com feições selecionadas; o usuário também pode escolher a camada explicitamente. Um único polígono funciona sem seleção manual. A leitura usa a camada com seu buffer de edição, incluindo IDs temporários negativos de desenhos ainda não salvos. Várias partes explicitamente selecionadas podem formar o mesmo limite; camadas com vários imóveis sem seleção continuam solicitando uma escolha, com o nome da camada na mensagem.

## Aparência dos produtos

GOES C13 recebe uma rampa de pseudocores entre 200 e 330 K, com referências em Celsius na legenda. Os pixels permanecem em Kelvin e na resolução original. A mudança de cor não produz RGB natural nem aumenta o detalhe espacial.

MODIS recebe um perfil de contraste calculado sobre pixels válidos. Os limites são transformados para a escala/offset que o provedor QGIS realmente aplica. Canais constantes recebem uma faixa física segura, evitando limites de contraste degenerados. Cor natural mantém um intervalo físico comum aos três canais. Não foram alteradas as combinações espectrais solicitadas.

Recortes sem pixels válidos comuns ou com bandas RGB somente zeradas são identificados antes da importação. As bandas originais são preservadas. Um estilo QML é salvo após a importação e reaplicado ao reabrir esse produto pela aba Acervo offline.

Foi consultada a mesma cena MODIS mostrada no print: MYD09A1.A2026313.h13v09.061.2026323000310. Em um recorte de teste aproximado na região do imóvel, a combinação SWIR2/NIR/vermelho continha dados válidos. O raster foi renderizado com o perfil novo e verificado visualmente, com cores e sem substituir os valores dos pixels. Isso não é uma reprodução exata do projeto/CRS/instalação Windows do usuário.

## Verificação

**228 testes passaram, sem testes pulados**, em QGIS 3.40.6/GDAL 3.10.3/Qt 5.15.15/Linux, Qt offscreen. Incluem:

- Polígono único, desenho não salvo, seleção em camada diferente daquela indicada em Imagens e escolha explícita de camada.
- Vários polígonos, geometria selecionada e reconhecimento de mudança posterior.
- Consulta MapBiomas/NASA pela interface e distinção de acervo local vazio.
- Contraste de canais MODIS constantes, escala embutida aplicada uma única vez e verificação de imagem renderizada não preta.
- Rejeição de raster RGB vazio/zerado, estilo térmico colorido e reabertura QML.
- Os testes anteriores de aquisição, índices, relatórios PRODES, tarefas e integridade do acervo.

Uma consulta real pela interface, com uma camada vazia escolhida em Imagens e outro limite selecionado, retornou para a área sintética de teste: 41 registros anuais MapBiomas (1985–2025), 8 registros ASTER e 93 registros MODIS em 2024, sem erro de seleção. O proxy do executor de validação não foi incorporado ao plugin.

Flake8 no perfil já documentado, Bandit, detect-secrets, compilação, metadados e integridade ZIP verificados. Não foi executado o projeto do usuário nem uma instalação Windows. Nenhuma publicação externa realizada.

## Disponibilidade das fontes

Listar os 41 anos do MapBiomas não significa que seus GeoTIFFs foram baixados. O bloqueio HTTP 403 do provedor mostrado pelo usuário permanece uma restrição externa; a alternativa de GeoTIFF local/GEE continua disponível. ASTER continua como descoberta pública de metadados com acesso externo Earthdata para os arquivos. MODIS e GOES mantêm os downloads implementados na versão 4.0.
