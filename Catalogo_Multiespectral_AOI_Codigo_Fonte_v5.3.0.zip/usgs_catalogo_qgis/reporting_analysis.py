# SPDX-License-Identifier: GPL-2.0-or-later
"""Escaped human-readable analysis records and spectral curves."""
import html
import os


def write_analysis_report(result, folder):
    if result.get('index'):
        from .hydrology import write_report
        return write_report(result,folder)
    def esc(x): return html.escape(str(x))
    body=['<html><meta charset="utf-8"><style>body{font:15px Arial;margin:35px;color:#223242}table{border-collapse:collapse}td,th{border:1px solid #bbc;padding:8px}th{background:#e9f0f5}</style><h1>Análise do imóvel</h1>']
    if result['type']=='classification':
        body+=['<h2>Classificação supervisionada — Random Forest</h2><p>Resultado de apoio técnico. Conferir amostras, máscaras e interpretação antes de usar no laudo.</p>',
               '<h2>Área observada por classe</h2><table><tr><th>Classe</th><th>Área cartográfica (ha)</th></tr>']
        for c, area in result['areas_ha'].items():body.append('<tr><td>'+esc(result['classes'][c])+'</td><td>'+format(area,'.4f')+'</td></tr>')
        body+=['</table><p>Área sem observação válida: '+format(result['unobserved_ha'],'.4f')+' ha. Não foi atribuída a uma classe.</p>']
        body.append('<p>Área espectral indeterminada (concordância menor que 60%): '+format(result.get('indeterminate_ha',0),'.4f')+' ha. Na matriz, previsões indeterminadas são contadas como falhas de reconhecimento da classe de referência.</p>')
        m=result['metrics'];body+=['<h2>Validação independente do treinamento</h2><p>Acurácia global nas amostras: '+format(100*m['overall_accuracy'],'.1f')+'%. Não é garantia para toda a propriedade.</p>',
            '<table><tr><th>Classe</th><th>Precisão</th><th>Revocação</th><th>F1</th><th>Pixels de validação</th></tr>']
        for row in m['per_class']:body.append('<tr><td>{}</td><td>{:.3f}</td><td>{:.3f}</td><td>{:.3f}</td><td>{}</td></tr>'.format(esc(result['classes'][str(row['class'])]),row['precision'],row['recall'],row['f1'],row['reference_pixels']))
        body+=['</table><h3>Matriz de confusão</h3><p>Linhas: referência; colunas: previsão. Ordem das classes: '+esc(m['classes'])+'</p><table>']
        for row in m['matrix_rows_reference_columns_prediction']:body.append('<tr>'+''.join('<td>'+str(v)+'</td>' for v in row)+'</tr>')
        body+=['</table><p>'+esc(m['limitations'])+'</p><h2>Assinaturas espectrais das amostras de treino</h2>']
        # Coordinates are calculated directly from measured means, no generated imagery.
        body.append('<svg xmlns="http://www.w3.org/2000/svg" width="740" height="320" viewBox="0 0 740 320"><rect width="740" height="320" fill="white"/><path d="M45 15 V265 H720" fill="none" stroke="#555"/>')
        for s in result['signatures']:
            values=s['mean'];points=' '.join('{:.1f},{:.1f}'.format(45+i*665/max(1,len(values)-1),265-200*max(0,min(1,v))) for i,v in enumerate(values))
            from .classification import CLASSES
            body.append('<polyline points="'+points+'" fill="none" stroke="'+CLASSES[s['class']][1]+'" stroke-width="2"/>')
        for i,band in enumerate(result['bands']):body.append('<text x="{}" y="290" font-size="11">{}</text>'.format(45+i*665/max(1,len(result['bands'])-1),esc(band)))
        body+=['</svg><table><tr><th>Classe</th><th>Reflectância média por banda</th></tr>']
        for s in result['signatures']:body.append('<tr><td>'+esc(result['classes'][str(s['class'])])+'</td><td>'+esc([round(v,4) for v in s['mean']])+'</td></tr>')
        body+=['</table><p>'+esc(result['warning'])+'</p>']
    else:
        body+=['<h2>Comparação temporal</h2><p>Datas: '+esc(result['dates'])+'</p><p>Área comum válida: '+format(result['valid_ha'],'.4f')+' ha.</p>',
            '<p>Área com queda de NDVI maior que o limiar informado: '+format(result['decrease_ha'],'.4f')+' ha. Esse indicador não determina causa, data exata, desmatamento ou enquadramento legal.</p>',
            '<table><tr><th>Data</th><th>NDVI médio</th><th>NBR médio</th></tr>']
        for row in result['series']:body.append('<tr><td>{}</td><td>{:.4f}</td><td>{:.4f}</td></tr>'.format(esc(row['date']),row['ndvi'],row['nbr']))
        body+=['</table><p>'+esc(result['limitations'])+'</p><h3>Série dos índices — pixels comuns</h3>']
        series=result['series'];body.append('<svg xmlns="http://www.w3.org/2000/svg" width="740" height="300"><rect width="740" height="300" fill="white"/><path d="M40 10 V250 H720" stroke="#444" fill="none"/>')
        for key,color in [('ndvi','#16804b'),('nbr','#3869be')]:
            points=' '.join('{:.1f},{:.1f}'.format(40+i*660/max(1,len(series)-1),130-110*row[key]) for i,row in enumerate(series))
            body.append('<polyline points="'+points+'" stroke="'+color+'" stroke-width="2" fill="none"/>')
        for i,row in enumerate(series):
            if i%max(1,len(series)//6)==0:body.append('<text x="{}" y="275" font-size="10">{}</text>'.format(40+i*660/max(1,len(series)-1),esc(row['date'])))
        body.append('</svg><p>Verde: NDVI; azul: NBR. Eixo vertical: −1 a +1; as datas e médias completas estão na tabela.</p>')
    if result.get('input_checksums'):body.append('<h2>Integridade das entradas</h2><pre>'+esc(result['input_checksums'])+'</pre>')
    body+=['<h2>Proveniência</h2><pre>'+esc(result.get('source',{}))+'</pre></html>']
    path=os.path.join(folder,'relatorio.html')
    with open(path,'w',encoding='utf8') as stream:stream.write('\n'.join(body))
    return path
