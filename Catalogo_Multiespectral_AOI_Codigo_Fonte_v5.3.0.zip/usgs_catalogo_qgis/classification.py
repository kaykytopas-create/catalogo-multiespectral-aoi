# SPDX-License-Identifier: GPL-2.0-or-later
"""Local random forest, independent validation and block raster inference.

No executable model deserialization, online AI, or thematic accuracy promise.
"""
import math
import os
import numpy as np
from .stac import CatalogError
from .storage import atomic_json, sha256

CLASSES = {1: ('Floresta / cobertura arbórea', '#176b35'),
           2: ('Pastagem', '#e6d06e'), 3: ('Agricultura', '#eaa25a'),
           4: ('Água', '#2678ce'), 5: ('Solo exposto', '#b36f4f')}


def check(cancelled):
    if cancelled(): raise CatalogError('Tarefa cancelada; pode retomar pela fila.')


def train_forest(x, y, trees=48, seed=42, cancelled=lambda: False, progress=lambda x: None):
    x, y = np.asarray(x, dtype='float32'), np.asarray(y, dtype='int32')
    if x.ndim != 2 or len(x) != len(y) or not np.isfinite(x).all():
        raise CatalogError('Amostras inválidas para treinamento.')
    classes = np.unique(y)
    if len(classes) < 2: raise CatalogError('Marque pelo menos duas classes de treinamento.')
    rng = np.random.default_rng(seed)
    def tree(indices, depth):
        check(cancelled)
        labels = y[indices]; counts = np.array([(labels == c).sum() for c in classes])
        majority = int(classes[counts.argmax()])
        if depth >= 12 or len(indices) < 12 or np.count_nonzero(counts) == 1:
            return {'class': majority}
        best, split = float('inf'), None
        for f in rng.choice(x.shape[1], max(1, int(math.sqrt(x.shape[1]))), replace=False):
            values = x[indices, f]
            for threshold in np.unique(np.quantile(values, np.linspace(.1, .9, 9))):
                left = values <= threshold; n = int(left.sum())
                if n < 4 or len(indices)-n < 4: continue
                score = 0.
                for part in (labels[left], labels[~left]):
                    proportions = np.array([(part == c).sum() for c in classes]) / len(part)
                    score += len(part) * (1 - (proportions**2).sum())
                if score < best: best, split = score, (int(f), float(threshold), left)
        if split is None: return {'class': majority}
        feature, threshold, left = split
        return {'feature': feature, 'threshold': threshold,
                'left': tree(indices[left], depth+1), 'right': tree(indices[~left], depth+1)}
    forest = []
    for i in range(trees):
        check(cancelled); progress('Treinando árvore {}/{}'.format(i+1, trees))
        indices = rng.integers(0, len(y), min(len(y), 5000))
        forest.append(tree(indices, 0))
    return {'method': 'Random Forest CART / Gini / bootstrap / random subspace',
            'implementation': 'catalogo-numpy-rf-1', 'classes': classes.tolist(),
            'features': x.shape[1], 'seed': seed, 'trees': forest}


def predict(model, x):
    x = np.asarray(x, dtype='float32')
    if x.ndim != 2 or x.shape[1] != model['features']: raise CatalogError('Bandas diferentes das usadas no treinamento.')
    if not np.isfinite(x).all(): raise CatalogError('Predição exige pixels finitos.')
    votes = np.zeros((len(x), len(model['classes'])), dtype='uint16')
    positions = {c: i for i, c in enumerate(model['classes'])}
    def walk(node, ids):
        if not len(ids): return
        if 'class' in node: votes[ids, positions[node['class']]] += 1; return
        left = x[ids, node['feature']] <= node['threshold']
        walk(node['left'], ids[left]); walk(node['right'], ids[~left])
    for tree in model['trees']: walk(tree, np.arange(len(x)))
    return np.asarray(model['classes'], dtype='uint8')[votes.argmax(axis=1)], votes.max(axis=1)/len(model['trees'])


def accuracy(reference, predicted, classes):
    reference=np.asarray(reference);predicted=np.asarray(predicted)
    if reference.shape!=predicted.shape:raise CatalogError('Referência e previsão devem ter a mesma quantidade de amostras.')
    classes = list(classes) + sorted(set(map(int,np.unique(predicted)))-set(classes))
    matrix = np.array([[int(((reference == a) & (predicted == b)).sum()) for b in classes] for a in classes])
    total = int(matrix.sum()); details = []
    for i, c in enumerate(classes):
        tp = int(matrix[i, i]); row = int(matrix[i].sum()); col = int(matrix[:, i].sum())
        precision = tp/col if col else 0.; recall = tp/row if row else 0.
        details.append({'class': int(c), 'reference_pixels': row, 'precision': precision,
                        'recall': recall, 'f1': 2*precision*recall/(precision+recall) if precision+recall else 0.})
    return {'matrix_rows_reference_columns_prediction': matrix.tolist(), 'classes': list(map(int, classes)),
            'overall_accuracy': float(np.trace(matrix)/total) if total else None,
            'validation_pixels': total, 'per_class': details,
            'limitations': 'Validação em polígonos independentes do treino; pixels dentro de um polígono são correlacionados. Não equivale a amostragem probabilística de todo o imóvel.'}


def mask_geometry(dataset, geometries, values=None):
    from osgeo import gdal, ogr, osr
    mem = gdal.GetDriverByName('MEM').Create('', dataset.RasterXSize, dataset.RasterYSize, 1, gdal.GDT_UInt16)
    mem.SetGeoTransform(dataset.GetGeoTransform()); mem.SetProjection(dataset.GetProjection())
    target = osr.SpatialReference(); target.ImportFromWkt(dataset.GetProjection()); target.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    source = osr.SpatialReference(); source.ImportFromEPSG(4326); source.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    vectors = ogr.GetDriverByName('Memory').CreateDataSource(''); layer = vectors.CreateLayer('regions', target, ogr.wkbUnknown)
    layer.CreateField(ogr.FieldDefn('value', ogr.OFTInteger))
    for i, wkt in enumerate(geometries):
        geom = ogr.CreateGeometryFromWkt(wkt)
        if geom is None or geom.IsEmpty(): raise CatalogError('Geometria de amostra vazia.')
        geom.Transform(osr.CoordinateTransformation(source, target))
        feature = ogr.Feature(layer.GetLayerDefn()); feature.SetGeometry(geom); feature['value'] = int(values[i] if values is not None else 1); layer.CreateFeature(feature)
    if gdal.RasterizeLayer(mem, [1], layer, options=['ATTRIBUTE=value']) != 0: raise CatalogError('Falha ao rasterizar regiões.')
    return mem.ReadAsArray()


def prepare_raster(payload, folder, cancelled):
    from osgeo import gdal
    from .stac import context_bbox
    rect = payload['rect']; lon = (rect[0]+rect[2])/2; lat = (rect[1]+rect[3])/2
    zone = min(60, max(1, int((lon+180)//6)+1)); target = 'EPSG:'+str((32600 if lat >= 0 else 32700)+zone)
    source = gdal.Open(payload['path'])
    if source is None or not source.GetProjection(): raise CatalogError('Raster local sem georreferência válida.')
    if payload.get('band_numbers'): source = gdal.Translate('',source,format='VRT',bandList=payload['band_numbers'])
    estimate = gdal.AutoCreateWarpedVRT(source, None, target)
    resolution = max(abs(estimate.GetGeoTransform()[1]), abs(estimate.GetGeoTransform()[5]), payload.get('resolution', 0))
    from osgeo import osr
    wgs=osr.SpatialReference();wgs.ImportFromEPSG(4326);utm=osr.SpatialReference();utm.SetFromUserInput(target)
    for sr in (wgs,utm):sr.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    crop=context_bbox(rect);transform=osr.CoordinateTransformation(wgs,utm)
    corners=transform.TransformPoints([(crop[0],crop[1]),(crop[0],crop[3]),(crop[2],crop[1]),(crop[2],crop[3])])
    expected=(max(p[0] for p in corners)-min(p[0] for p in corners))/resolution*(max(p[1] for p in corners)-min(p[1] for p in corners))/resolution
    if expected>20000000 or expected*source.RasterCount>60000000:raise CatalogError('Recorte grande para análise local; divida a área antes de executar.')
    path = os.path.join(folder, 'entrada_alinhada.tif'); partial = path+'.part.tif'
    try:
        result = gdal.Warp(partial, source, format='GTiff', dstSRS=target, outputBounds=context_bbox(rect), outputBoundsSRS='EPSG:4326',
            xRes=resolution, yRes=resolution, resampleAlg='near', dstNodata=-9999, outputType=gdal.GDT_Float32,
            creationOptions=['TILED=YES','COMPRESS=DEFLATE'], callback=lambda *args: 0 if cancelled() else 1)
        if result is None: raise CatalogError('Falha na preparação do raster.')
        if result.RasterXSize*result.RasterYSize > 20000000 or result.RasterXSize*result.RasterYSize*result.RasterCount > 60000000: raise CatalogError('Recorte acima de 20 milhões de pixels; divida o imóvel para esta tarefa local.')
        result = None; os.replace(partial, path)
    finally:
        if os.path.isfile(partial): os.remove(partial)
    return path


def run_classification(payload, folder, cancelled=lambda: False, progress=lambda x: None):
    from osgeo import gdal
    from .prodes_auto import qa_valid
    from .reporting_analysis import write_analysis_report
    os.makedirs(folder, exist_ok=True); check(cancelled)
    from .preflight import validate_samples
    validate_samples(payload.get('samples', []))
    if not payload.get('qa_path') or not os.path.isfile(payload['qa_path']):raise CatalogError('Máscara QA local obrigatória; reimporte o Band Set para preservar qualidade.')
    path = prepare_raster(payload, folder, cancelled); ds = gdal.Open(path)
    if ds.RasterCount != len(payload['coefficients']): raise CatalogError('Calibração e quantidade de bandas não correspondem.')
    inside = mask_geometry(ds, [payload['geometry']]) != 0
    regions = payload['samples']
    if not regions: raise CatalogError('Desenhe ou carregue amostras de treino e validação.')
    # Reject overlap in vector space as well as raster cells, before rasterization.
    from osgeo import ogr
    geometries = [ogr.CreateGeometryFromWkt(r['geometry']) for r in regions]
    for i, geom in enumerate(geometries):
        for j in range(i):
            if geom.Intersects(geometries[j]) and geom.Intersection(geometries[j]).GetArea() > 1e-14:
                raise CatalogError('Amostras sobrepostas; separe os polígonos de treino/validação e as classes.')
    train = [r for r in regions if r['role'] == 'treino']; validation = [r for r in regions if r['role'] == 'validacao']
    train_mask = mask_geometry(ds, [r['geometry'] for r in train], [r['class'] for r in train])
    valid_mask = mask_geometry(ds, [r['geometry'] for r in validation], [r['class'] for r in validation])
    if np.any((train_mask > 0) & (valid_mask > 0)): raise CatalogError('Treino e validação compartilham pixels.')
    arrays = []; usable = inside.copy()
    for n, (scale, offset) in enumerate(payload['coefficients'], 1):
        raw = ds.GetRasterBand(n).ReadAsArray(); usable &= np.isfinite(raw) & (raw != -9999)
        arrays.append(raw*scale+offset)
    features = np.stack(arrays, axis=-1); usable &= np.isfinite(features).all(axis=-1) & (features >= -.2).all(axis=-1) & (features <= 1.6).all(axis=-1)
    if payload.get('qa_path'):
        qa = gdal.Warp('', payload['qa_path'], format='MEM', dstSRS=ds.GetProjection(),
            outputBounds=(ds.GetGeoTransform()[0],ds.GetGeoTransform()[3]+ds.RasterYSize*ds.GetGeoTransform()[5],ds.GetGeoTransform()[0]+ds.RasterXSize*ds.GetGeoTransform()[1],ds.GetGeoTransform()[3]),
            width=ds.RasterXSize,height=ds.RasterYSize,resampleAlg='near',dstNodata=255)
        usable &= qa_valid(qa.ReadAsArray(), payload['qa_kind'])
    if payload.get('saturation_path'):
        saturation=gdal.Warp('',payload['saturation_path'],format='MEM',dstSRS=ds.GetProjection(),
            outputBounds=(ds.GetGeoTransform()[0],ds.GetGeoTransform()[3]+ds.RasterYSize*ds.GetGeoTransform()[5],ds.GetGeoTransform()[0]+ds.RasterXSize*ds.GetGeoTransform()[1],ds.GetGeoTransform()[3]),
            width=ds.RasterXSize,height=ds.RasterYSize,resampleAlg='near',dstNodata=65535)
        usable &= saturation.ReadAsArray()==0
    classes = sorted(set(r['class'] for r in train))
    if len(classes) < 2 or set(classes) != set(r['class'] for r in validation): raise CatalogError('Cada classe exige amostras separadas de treino e validação.')
    rng = np.random.default_rng(42); train_x=[]; train_y=[]; test_x=[]; test_y=[]; signatures=[]
    for c in classes:
        for mask, xs, ys, minimum in ((train_mask,train_x,train_y,10),(valid_mask,test_x,test_y,5)):
            ids = np.flatnonzero(usable & (mask == c))
            if len(ids) < minimum: raise CatalogError('{}: {} pixels válidos de {}; mínimo {}. Amplie ou acrescente amostras em áreas sem nuvens.'.format(CLASSES[c][0],len(ids),'treinamento' if mask is train_mask else 'validação',minimum))
            ids = rng.choice(ids, min(len(ids), 2000), replace=False)
            values = features.reshape(-1, features.shape[-1])[ids]
            xs.extend(values); ys.extend([c]*len(ids))
            if mask is train_mask: signatures.append({'class': c,'pixels': len(ids),'mean':values.mean(axis=0).tolist(),'std':values.std(axis=0).tolist()})
    model = train_forest(np.asarray(train_x), np.asarray(train_y), cancelled=cancelled, progress=progress)
    predicted, agreement = predict(model, np.asarray(test_x)); predicted[agreement < .6] = 0; metrics = accuracy(np.asarray(test_y),predicted,classes)
    model['bands'] = payload['bands']; model['coefficients'] = payload['coefficients']; atomic_json(os.path.join(folder,'modelo_rf.json'),model)
    counts = {c:0 for c in classes}; output = os.path.join(folder,'classificacao.tif'); confidence = os.path.join(folder,'concordancia_arvores.tif')
    created=[];indeterminate=0
    try:
        rasters=[]
        for dest, dtype in ((output,gdal.GDT_Byte),(confidence,gdal.GDT_Float32)):
            partial=dest+'.part.tif'; created.append(partial)
            out=gdal.GetDriverByName('GTiff').Create(partial,ds.RasterXSize,ds.RasterYSize,1,dtype,['TILED=YES','COMPRESS=DEFLATE'])
            out.SetGeoTransform(ds.GetGeoTransform()); out.SetProjection(ds.GetProjection()); out.GetRasterBand(1).SetNoDataValue(255 if dtype==gdal.GDT_Byte else -9999); rasters.append(out)
        for y in range(0,ds.RasterYSize,64):
            check(cancelled); valid=usable[y:y+64]; values=features[y:y+64]; a=np.full(valid.shape,255,dtype='uint8'); b=np.full(valid.shape,-9999,dtype='float32')
            if valid.any():
                labels,votes=predict(model,values[valid]); labels[votes < .6]=0; indeterminate+=int((labels==0).sum()); a[valid]=labels; b[valid]=votes
                for c in classes: counts[c] += int((labels==c).sum())
            rasters[0].GetRasterBand(1).WriteArray(a,0,y); rasters[1].GetRasterBand(1).WriteArray(b,0,y)
            progress('Classificando: {}%'.format(min(100,round(100*(y+64)/ds.RasterYSize))))
        for out in rasters: out.FlushCache()
        out=None; rasters=[]
        for partial,dest in zip(created,(output,confidence)): os.replace(partial,dest)
    finally:
        rasters=[]; out=None
        for partial in created:
            if os.path.isfile(partial): os.remove(partial)
    pixel_ha=abs(ds.GetGeoTransform()[1]*ds.GetGeoTransform()[5])/10000
    result={'type':'classification','path':output,'confidence':confidence,'metrics':metrics,'signatures':signatures,
            'areas_ha':{str(c):n*pixel_ha for c,n in counts.items()},'indeterminate_ha':indeterminate*pixel_ha,'unobserved_ha':int((inside & ~usable).sum())*pixel_ha,
            'bands':payload['bands'],'source':payload['source_info'],'classes':dict({'0':'Indeterminado — concordância abaixo de 60 por cento'},**{str(c):CLASSES[c][0] for c in classes}),
            'parameters':{'seed':42,'trees':48,'max_depth':12,'min_leaf':4,'minimum_vote_agreement':.6,'numpy_version':np.__version__},
            'warning':'Concordância das árvores não é probabilidade calibrada nem prova de acurácia. Classes são coberturas espectrais, sem enquadramento legal.'}
    result['report']=write_analysis_report(result,folder)
    atomic_json(os.path.join(folder,'resultado.json'),result); result['sha256']=sha256(output,cancelled)
    return result
