# Validação 5.2.0 — 21/11/2026

Windows; QGIS 3.44.7; Python 3.12; GDAL/NumPy do QGIS.
Suíte completa: 291 testes, zero falhas, zero erros, zero ignorados.
Cobertura inclui metadados, integridade do pacote, concorrência/arquivos Windows, acervo,
calibração, QA, fórmulas hídricas, NoData, comparação temporal, área de água, cancelamento,
execução em QgsTask, três abas e geração de cartas. Módulos antigos seguem testados para
compatibilidade, embora não estejam disponíveis na nova interface.
O teste online baixou e abriu no QGIS um recorte JRC ocorrência v1.5: 36 × 36 pixels;
valores zero nesse recorte (sem água detectada). Não é validação de todas as regiões/produtos.
Interfaces renderizadas com Qt em 1024 × 700 e inspecionadas visualmente.
Execução em processo separado; configurações da suíte isoladas em arquivo de teste.
O projeto aberto e a instalação original não foram substituídos.
Mensagens GDAL de cenários negativos/rasters constantes podem constar no log; a suíte passou.
Faixa declarada QGIS 3.40–3.99; execução efetiva somente em 3.44.7. Sem validação em campo,
certificação científica ou aprovação pelo repositório oficial. experimental=False é a marca
de distribuição do pacote, não uma garantia de ausência absoluta de defeitos.
Reprodução: inicialize QgsApplication no Python do QGIS e execute unittest discover em
usgs_catalogo_qgis/tests, usando configurações/projeto de teste isolados.
