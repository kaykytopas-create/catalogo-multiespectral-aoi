# Validação 4.0.0 · 20/11/2026

## Ambiente e verificações locais

QGIS **3.40.6 Bratislava**, GDAL **3.10.3**, Qt **5.15.15**, Python 3.13, Linux, Qt offscreen. Compatibilidade de distribuição declarada QGIS 3.40–3.99; QGIS 4 e Windows/macOS não foram executados nesta sessão.

**219 testes passaram, sem testes pulados.** Incluem os testes anteriores de aquisição, índices, investigação/argumentação PRODES e relatórios, além de:

- Tipos das novas fontes; 41 anos MapBiomas (1985–2025), período parcial anual e cobertura externa.
- ASTER com consulta CMR paginada e identificação do acesso Earthdata externo.
- GOES com seleção diária às 15 h UTC, troca GOES-16/19, falta de cobertura, fonte indisponível e cancelamento.
- MODIS com nomes espectrais, comprimento de onda, intervalo temporal e coeficientes corretos. Composto sem eo:cloud_cover não é descartado por um filtro de cenas Landsat.
- Band Set espectral e regras DOS1; produtos de superfície não corrigidos novamente, classes/termal protegidos e calibração insuficiente bloqueada.
- DOS1 em raster sintético calibrado, NoData/cancelamento e limpeza de parcial.
- GeoTIFF MapBiomas multibanda com anos explícitos, reprojeção para UTM e preservação de classes inteiras por vizinho mais próximo.
- SHA-256, alteração de arquivo com tamanho/data preservados, arquivo ausente, reindexação sem duplicar e atualizações concorrentes do catálogo.
- Tarefas QgsTask com sucesso, exceção e cancelamento; resultado entregue na thread principal e uma finalização.
- Interface real: seis abas, seleção de imóvel, predefinições e Alt+I. Botão de importação visível em 1180×850, 1024×700 e 900×600, com rolagem no começo/fim.

Perfil Flake8 `F,E711,E712,E713,E714,E721,E722,E731,E741,E742,E743,E9`: nenhum apontamento. Não se declara conformidade com todas as regras opcionais de formatação PEP 8. Bandit e detect-secrets (todos os arquivos): nenhum apontamento. Compilação Python, metadados ConfigParser, campos públicos e integridade ZIP verificados. Nenhuma supressão adicionada para esconder os resultados.

## Verificações reais de provedores

Para uma pequena área sintética em torno de 55°W, 12°S:

- MODIS 01–08/07/2024: quatro registros retornados no catálogo. Uma composição natural foi preparada no CRS EPSG:32721, com 10×6 pixels e três bandas, preservando escala 0,0001. A primeira preparação levou cerca de 18 s neste ambiente; reabertura local cerca de 0,07 s. Não são metas de desempenho para outros imóveis/redes.
- ASTER 2024: oito registros CMR. Não foi realizada autenticação nem download de ASTER HDF.
- GOES 01/07/2024: observação C13 retornada; recorte de temperatura Kelvin gerado com projeção geostacionária CF, escala/offset explícitos e máscara de preenchimento. A rotina final aplica também DQF=0; temperaturas observadas no pequeno recorte foram aproximadamente 232,5–243,6 K. Resolução grosseira e temperatura de topo/superfície aparente não são mapa de uso do solo.
- MODIS e GOES foram reabertos com `offline=True`, sem nova aquisição de bandas. O índice registrou os cinco arquivos resultantes (três bandas MODIS, composição e GOES).
- MapBiomas: o portal oficial informava suspensão temporária dos downloads. As URLs GeoTIFF testadas para 1985, 2000 e 2025 retornaram HTTP 403. Assim, não se afirma que o download público da série nacional esteja funcional hoje. Integração categórica e entrada local foram verificadas com rasters sintéticos; o botão/portal externo e o erro de bloqueio permanecem explícitos.

O proxy necessário neste ambiente de testes foi configurado apenas no executor de validação. Não foi embutido no plugin nem incluído no pacote. Requisições QGIS usam o ambiente do usuário; GDAL/proxy deve ser conferido no destino de produção.

## Publicação e limites

`experimental=False` foi definido conforme solicitado, com versão 4.0.0, autor/contato, changelog e requisitos revisados. Isso não significa aprovação pelo repositório QGIS. O fluxo GitHub Actions foi fornecido como configuração de repositório; não foi executado no GitHub nem ocorreu push/submissão externa. Os links existentes do projeto foram mantidos; o verificador local checa sintaxe, não confirma permissão de escrita no GitHub.

As novas fontes não foram inseridas como substituição silenciosa da evidência Landsat/Sentinel da investigação PRODES. O relatório continua sendo apoio à revisão técnica, sem validação temática independente de uma taxa de acerto ou certificação jurídica. A saída estável é uma decisão sobre o pacote de software, não uma homologação ambiental.
