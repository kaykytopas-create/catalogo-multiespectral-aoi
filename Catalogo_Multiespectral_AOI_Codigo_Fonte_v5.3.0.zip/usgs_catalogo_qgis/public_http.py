# SPDX-License-Identifier: GPL-2.0-or-later
"""Bounded, cancellable public HTTP through QGIS network/proxy settings."""
import json
import os
import time
from urllib.parse import urlparse
from .stac import CatalogError


class PublicHttpError(CatalogError):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def trusted_url(url):
    p = urlparse(url)
    try:
        if p.scheme != 'https' or p.port not in (None, 443) or p.username or p.password:
            return False
    except ValueError:
        return False
    hosts = {
        'planetarycomputer.microsoft.com': ('/api/stac/v1/', '/api/sas/v1/', '/api/data/v1/'),
        'data.inpe.br': ('/bdc/stac/v1/', '/bdc/data/landsat/v2/'),
        'earth-search.aws.element84.com': ('/v1/',),
        'e84-earth-search-sentinel-data.s3.us-west-2.amazonaws.com': ('/sentinel-2-c1-l2a/',),
        'cmr.earthdata.nasa.gov': ('/search/',),
        'brasil.mapbiomas.org': ('/iniciativas-e-produtos/',),
        'storage.googleapis.com': ('/mapbiomas-public/',),
        'terrabrasilis.dpi.inpe.br': ('/geoserver/ows',),
        'noaa-goes16.s3.amazonaws.com': ('/',),
        'noaa-goes19.s3.amazonaws.com': ('/',),
    }
    return p.hostname in hosts and p.path.startswith(hosts[p.hostname])


def request(url, payload=None, cancelled=lambda: False, timeout=45,
            max_bytes=16*1024*1024, target=None):
    if not trusted_url(url):
        raise CatalogError('Endereço não autorizado para consulta pública.')
    if cancelled():
        raise CatalogError('Operação cancelada.')
    from qgis.core import QgsNetworkAccessManager
    from qgis.PyQt.QtCore import QUrl, QByteArray, QEventLoop, QTimer
    from qgis.PyQt.QtNetwork import QNetworkRequest, QNetworkReply
    deadline = time.monotonic() + timeout
    for attempt in range(2):
        if cancelled() or time.monotonic() >= deadline:
            raise CatalogError('Operação cancelada ou tempo limite atingido.')
        # Pool threads need an event dispatcher before creating the manager.
        loop, timer = QEventLoop(), QTimer()
        req = QNetworkRequest(QUrl(url))
        req.setAttribute(QNetworkRequest.Attribute.RedirectPolicyAttribute,
                         QNetworkRequest.RedirectPolicy.ManualRedirectPolicy)
        req.setRawHeader(b'User-Agent', b'QGIS-Multispectral-AOI/4.1')
        req.setRawHeader(b'Accept', b'application/json, application/xml, text/html, */*')
        manager = QgsNetworkAccessManager.instance()
        if payload is None:
            reply = manager.get(req)
        else:
            req.setRawHeader(b'Content-Type', b'application/json')
            reply = manager.post(req, QByteArray(json.dumps(payload).encode()))
        chunks, reasons, received = [], [], [0]
        stream = open(target, 'wb') if target else None

        def read():
            if not reply.isOpen():
                return
            chunk = bytes(reply.readAll())
            received[0] += len(chunk)
            if received[0] > max_bytes:
                reasons.append('Resposta excedeu o limite; reduza o período/área.')
                reply.abort()
            elif stream:
                try:
                    stream.write(chunk)
                except OSError as exc:
                    reasons.append(str(exc))
                    reply.abort()
            else:
                chunks.append(chunk)

        def tick():
            if cancelled() or time.monotonic() >= deadline:
                reasons.append('Operação cancelada.' if cancelled() else 'Tempo limite da fonte atingido.')
                reply.abort()

        reply.readyRead.connect(read)
        reply.finished.connect(loop.quit)
        timer.timeout.connect(tick)
        timer.start(100)
        status, error = None, None
        try:
            if not reply.isFinished():
                loop.exec()
            if not reasons:
                read()
            status = reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
            status = int(status) if status is not None else None
            error = reply.error()
            network_reason = reply.errorString() if hasattr(reply, "errorString") else str(error)
        finally:
            timer.stop()
            reply.readyRead.disconnect(read)
            reply.finished.disconnect(loop.quit)
            reply.deleteLater()
            if stream:
                stream.close()
        if reasons or cancelled():
            if target and os.path.exists(target):
                os.remove(target)
            raise PublicHttpError(reasons[0] if reasons else 'Operação cancelada.', status)
        if error == QNetworkReply.NetworkError.NoError and status is not None and 200 <= status < 300:
            return target if target else b''.join(chunks)
        if target and os.path.exists(target):
            os.remove(target)
        if attempt == 0 and (status is None or status in (429, 500, 502, 503, 504)):
            continue
        hint = ' Autenticação externa exigida; use o portal oficial.' if status in (401,403) else ''
        raise PublicHttpError('Fonte indisponível (HTTP {}; rede {}).{}'.format(status, network_reason if status is None else int(error), hint), status)
