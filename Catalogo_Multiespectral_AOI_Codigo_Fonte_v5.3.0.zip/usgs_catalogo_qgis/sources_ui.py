# SPDX-License-Identifier: GPL-2.0-or-later
"""Optional sources kept out of the high-resolution imagery workflow."""
import json
from qgis.PyQt.QtCore import QDate, QUrl, pyqtSignal
from qgis.PyQt.QtGui import QColor, QDesktopServices
from qgis.PyQt.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QFormLayout,QLabel,
    QComboBox,QDateEdit,QPushButton,QCheckBox,QTableWidget,QTableWidgetItem,QHeaderView,
    QAbstractItemView,QMessageBox,QFileDialog)
from qgis.core import QgsProject,QgsRasterLayer,QgsPalettedRasterRenderer
from .tasks import TaskWorker
from .extended_sources import ExtendedCatalog,SOURCE_INFO
from .stac import PRESETS
from .parcel import ParcelPicker


class SourceJob(TaskWorker):
    prepared = pyqtSignal(object)

    def __init__(self, action, archive, **kwargs):
        super().__init__(description='Catálogo · fontes complementares')
        self.action,self.archive,self.args=action,archive,kwargs

    def work(self):
        client=ExtendedCatalog(lambda:self.stopping)
        if self.action=='ingest':
            from .extended_sources import ingest_mapbiomas
            self.result.emit(ingest_mapbiomas(self.args['paths'],self.archive,lambda:self.stopping,self.status.emit,self.prepared.emit))
            return
        if self.action=='search':
            if self.args['offline']:
                collections={'modis':['modis-09A1-061'],'mapbiomas':['mapbiomas-brasil-col11','mapbiomas-local'],
                             'goes':['goes-east-c13'],'aster':['aster-l1t-004']}
                data={'items':self.archive.search(collections[self.args['source']],self.args['start'][:4]+'-01-01' if self.args['source']=='mapbiomas' else self.args['start'],self.args['end']),
                      'cursor':None,'warnings':['Modo offline: somente registros já consultados neste recorte.']}
            else:
                data=client.search(self.args['source'],self.archive.rect,self.args['start'],self.args['end'],self.args.get('cursor'))
                self.archive.remember_many(data['items'])
            self.result.emit(data)
            return
        errors,completed=[],[]
        for number,item in enumerate(self.args['items'],1):
            self.setProgress(100*(number-1)/max(1,len(self.args['items'])))
            if self.stopping:
                return
            try:
                path=client.download(item,self.archive,self.status.emit,self.args['offline'],self.args['product'])
                from .source_styles import display_profile
                profile=display_profile(path,item,self.args['product'],lambda:self.stopping)
                event={'item':item,'path':path,'product':self.args['product'],'area':self.archive.area_id,'display_profile':profile}
                self.prepared.emit(event);completed.append(item['id'])
            except Exception as exc:
                if self.stopping:
                    return
                errors.append(item['id']+': '+str(exc))
                self.archive.remember(item,[str(exc)])
                from .public_http import PublicHttpError
                if isinstance(exc,PublicHttpError) and exc.status in (401,403):
                    remaining=len(self.args['items'])-number
                    if remaining:errors.append('{} produtos não tentados: a mesma fonte bloqueou o acesso externo.'.format(remaining))
                    break
        self.result.emit({'completed':completed,'errors':errors})


class SourcesTab(QWidget):
    def __init__(self,owner):
        super().__init__(owner)
        self.owner,self.job,self.items,self.cursor=owner,None,[],None
        self.query=None
        layout=QVBoxLayout(self)
        self.parcel_picker=ParcelPicker(owner.iface,owner.layer_box,self)
        layout.addWidget(self.parcel_picker)
        form=QFormLayout();self.source=QComboBox()
        for key,(label,_) in SOURCE_INFO.items():self.source.addItem(label,key)
        form.addRow('Fonte',self.source)
        self.note=QLabel();self.note.setWordWrap(True);form.addRow(self.note)
        row=QHBoxLayout();self.start=QDateEdit();self.end=QDateEdit()
        for field in (self.start,self.end):field.setCalendarPopup(True);field.setDisplayFormat('dd/MM/yyyy')
        self.start.setDate(QDate.currentDate().addDays(-7));self.end.setDate(QDate.currentDate())
        row.addWidget(self.start);row.addWidget(self.end);form.addRow('Período',row)
        hint=QLabel('Usa o imóvel indicado acima, incluindo desenhos ainda não salvos. Um único polígono não exige seleção manual. A série MapBiomas considera os anos que tocam o período.');hint.setWordWrap(True);form.addRow(hint)
        self.product=QComboBox()
        for key,label,_ in PRESETS:self.product.addItem(label,key)
        self.product.addItem('NDVI','ndvi');self.product.addItem('NBR','nbr');self.product.addItem('Band Set espectral completo','bandset')
        self.product.setCurrentIndex(self.product.findData('natural'));form.addRow('MODIS · composição',self.product)
        self.offline=QCheckBox('Consultar/reabrir apenas o acervo offline');form.addRow(self.offline)
        self.import_layers=QCheckBox('Importar no projeto QGIS ao concluir');self.import_layers.setChecked(True);form.addRow(self.import_layers)
        layout.addLayout(form)
        row=QHBoxLayout();self.search=QPushButton('Consultar período');self.more=QPushButton('Próxima página');self.more.setEnabled(False)
        row.addWidget(self.search);row.addWidget(self.more);layout.addLayout(row)
        self.table=QTableWidget(0,3);self.table.setHorizontalHeaderLabels(['Data / ano','Produto','Acesso'])
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.table,1)
        row=QHBoxLayout();self.download=QPushButton('Baixar / importar selecionados');self.download.setMinimumHeight(44)
        self.series=QPushButton('Baixar série anual consultada');self.portal=QPushButton('Abrir portal oficial');self.stop=QPushButton('Cancelar')
        for widget in (self.download,self.series,self.portal,self.stop):row.addWidget(widget)
        layout.addLayout(row)
        self.local_mapbiomas=QPushButton('Adicionar GeoTIFF MapBiomas já exportado (opcional)')
        layout.addWidget(self.local_mapbiomas)
        self.local_mapbiomas.clicked.connect(self.ingest)
        self.info=QLabel('Selecione uma fonte e consulte. Sem configuração de servidor ou credencial obrigatória.');self.info.setWordWrap(True);layout.addWidget(self.info)
        self.source.currentIndexChanged.connect(self.source_changed);self.source_changed()
        self.search.clicked.connect(lambda:self.run_search(False));self.more.clicked.connect(lambda:self.run_search(True))
        self.download.clicked.connect(lambda:self.run_download(False));self.series.clicked.connect(lambda:self.run_download(True))
        self.portal.clicked.connect(self.open_portal);self.stop.clicked.connect(self.cancel)

    def source_changed(self):
        source=self.source.currentData();self.note.setText(SOURCE_INFO[source][1])
        self.product.setEnabled(source=='modis');self.series.setVisible(source=='mapbiomas')
        self.portal.setVisible(source in ('aster','mapbiomas'));self.local_mapbiomas.setVisible(source=='mapbiomas');self.download.setEnabled(source!='aster')
        self.items=[];self.table.setRowCount(0);self.cursor=None;self.more.setEnabled(False)
        if source=='mapbiomas':
            self.start.setDate(QDate(1985,1,1));self.end.setDate(QDate(2025,12,31))
        elif source=='goes':
            self.start.setDate(QDate.currentDate().addDays(-7));self.end.setDate(QDate.currentDate())

    def busy(self,value):
        self.parcel_picker.setEnabled(not value)
        for widget in (self.search,self.source,self.start,self.end,self.product,self.offline,self.import_layers,self.download,self.series,self.local_mapbiomas):widget.setEnabled(not value)
        self.more.setEnabled(not value and bool(self.cursor));self.stop.setEnabled(value)
        if not value:
            self.product.setEnabled(self.source.currentData()=='modis');self.download.setEnabled(self.source.currentData()!='aster')

    def launch(self,job,callback):
        self.job=job;self.busy(True)
        job.result.connect(callback);job.failed.connect(self.error);job.status.connect(self.info.setText)
        job.done.connect(self.finished);job.prepared.connect(self.prepared);job.start()

    def run_search(self,following):
        if self.job:return
        try:
            if not following:
                from .archive import LocalArchive
                self.parcel_snapshot=self.parcel_picker.resolve()
                self.archive=LocalArchive(self.owner.archive_path,self.parcel_snapshot.rect,self.parcel_snapshot.target_crs)
                self.query={'source':self.source.currentData(),'start':self.start.date().toString('yyyy-MM-dd'),
                            'end':self.end.date().toString('yyyy-MM-dd'),'offline':self.offline.isChecked()}
                self.items=[];self.table.setRowCount(0)
            from .extended_sources import validate_dates
            validate_dates(self.query['start'],self.query['end'])
            self.info.setText('Consultando '+self.source.currentText()+' para '+self.parcel_snapshot.layer_name+'…')
            self.launch(SourceJob('search',self.archive,**self.query,cursor=self.cursor if following else None),self.got_search)
        except Exception as exc:self.error(str(exc))

    def got_search(self,data):
        self.cursor=data['cursor']
        seen={(v['collection'],v['id']) for v in self.items}
        for item in data['items']:
            if (item['collection'],item['id']) in seen:continue
            seen.add((item['collection'],item['id']));self.items.append(item)
            row=self.table.rowCount();self.table.insertRow(row)
            fields=[str(item.get('properties',{}).get('datetime',''))[:10],item['id'],
                    'Earthdata externo' if item.get('catalog:requires_auth') else 'Acervo / público']
            for column,value in enumerate(fields):self.table.setItem(row,column,QTableWidgetItem(value))
        message='{} registros para {}. {}'.format(len(self.items),self.parcel_snapshot.layer_name,' · '.join(data['warnings']))
        if not self.items:
            if self.query['offline']:
                message='Nenhum registro no acervo LOCAL deste imóvel/período. Desmarque “Consultar/reabrir apenas o acervo offline” para pesquisar o catálogo público. Isso não indica ausência de imagens na fonte.'
            else:
                message='Consulta concluída sem registros para este imóvel e período. Amplie o período ou escolha outra fonte. '+' · '.join(data['warnings'])
        self.info.setText(message)

    def run_download(self,all_years):
        if self.job:return
        rows=range(len(self.items)) if all_years else sorted({index.row() for index in self.table.selectedIndexes()})
        items=[self.items[row] for row in rows]
        if not items:
            self.info.setText('Selecione uma ou mais linhas da tabela.');return
        if any(item.get('catalog:requires_auth') for item in items):self.open_portal();return
        product=self.product.currentData() if self.source.currentData()=='modis' else 'original'
        self.import_errors=[]
        self.do_import=self.import_layers.isChecked()
        self.launch(SourceJob('download',self.archive,items=items,offline=self.offline.isChecked(),product=product),self.got_download)

    def prepared(self,event):
        if not self.do_import:return
        try:
            item=event['item'];layer=QgsRasterLayer(event['path'],item['id']+' · '+event['product'],'gdal')
            if not layer.isValid():raise ValueError('O QGIS não reconheceu o raster concluído.')
            kind=item.get('catalog:kind')
            acquired=str(item.get('properties',{}).get('datetime',''))[:10]
            if kind=='thermal':layer.setName(item.get('properties',{}).get('platform','GOES')+' · C13 térmico (K) · '+acquired)
            elif item.get('collection')=='modis-09A1-061':
                title=next((label for key,label,_ in PRESETS if key==event['product']),event['product'].upper())
                layer.setName('MODIS · '+title+' · '+acquired+' · 500 m')
            profile=event.get('display_profile')
            if profile and profile['mode'] in ('thermal','rgb'):
                from .source_styles import apply_profile
                apply_profile(layer,profile)
            elif kind=='categorical':
                palette={3:('#1f8d49','Formação florestal'),4:('#7dc975','Formação savânica'),5:('#04381d','Mangue'),
                    6:('#026975','Floresta alagável'),9:('#7a5900','Silvicultura'),11:('#519799','Campo alagado'),
                    12:('#d6bc74','Formação campestre'),15:('#edde8e','Pastagem'),18:('#e974ed','Agricultura'),
                    21:('#ffefc3','Mosaico de usos'),22:('#d4271e','Não vegetado'),24:('#d4271e','Área urbanizada'),
                    25:('#db4d4f','Outras áreas não vegetadas'),26:('#0000ff','Água'),27:('#ffffff','Não observado'),
                    29:('#ffaa5f','Afloramento rochoso'),30:('#9c0027','Mineração'),33:('#2532e4','Rio, lago e oceano')}
                # Keep all integer codes, including classes absent from this parcel.
                classes=[QgsPalettedRasterRenderer.Class(code,QColor(palette.get(code,('#b7b7b7','Classe '+str(code)))[0]),
                         palette.get(code,('', 'Classe '+str(code)))[1]) for code in range(1,76)]
                layer.setRenderer(QgsPalettedRasterRenderer(layer.dataProvider(),1,classes))
            elif kind!='thermal' and event['product'] in ('ndvi','nbr'):
                self.owner.configure_ndvi(layer)
            elif kind!='thermal' and layer.bandCount()==3:
                from .stac import preset_keys
                self.owner.configure_rgb(layer,False,item,preset_keys(item,event['product']))
            elif kind!='thermal' and event['product']=='bandset':
                from .radiometry import band_set
                from .stac import natural_rgb_keys
                keys=band_set(item);rgb=natural_rgb_keys(item)
                if rgb:self.owner.configure_rgb(layer,False,item,rgb,tuple(keys.index(key)+1 for key in rgb))
            signature='|'.join([event['area'],item['collection'],item['id'],event['product']])
            project=QgsProject.instance()
            for old in list(project.mapLayers().values()):
                if old.customProperty('catalogo_fonte_assinatura','')==signature:
                    project.removeMapLayer(old.id())
            layer.setCustomProperty('catalogo_fonte_assinatura',signature)
            layer.setCustomProperty('catalogo_multiespectral_tipo',kind)
            layer.setCustomProperty('catalogo_multiespectral_fontes',json.dumps(item.get('catalog:sources',[])))
            layer.setCustomProperty('catalogo_multiespectral_data',item.get('properties',{}).get('datetime',''))
            project.addMapLayer(layer)
            message,saved=layer.saveNamedStyle(event['path']+'.qml')
            if not saved:self.import_errors.append('Camada importada, mas estilo offline não salvo: '+message)
        except Exception as exc:
            self.import_errors.append(str(exc))

    def got_download(self,data):
        self.info.setText('{} produtos salvos; {} falhas de aquisição; {} falhas de importação. {}'.format(
            len(data['completed']),len(data['errors']),len(self.import_errors),' · '.join((data['errors']+self.import_errors)[:8])))

    def ingest(self):
        if self.job:return
        try:
            from .archive import LocalArchive
            self.parcel_snapshot=self.parcel_picker.resolve()
            self.archive=LocalArchive(self.owner.archive_path,self.parcel_snapshot.rect,self.parcel_snapshot.target_crs)
            paths,_=QFileDialog.getOpenFileNames(self,'GeoTIFF MapBiomas · ano no nome ou classification_AAAA por banda','','GeoTIFF (*.tif *.tiff)')
            if not paths:return
            self.import_errors=[];self.do_import=self.import_layers.isChecked()
            self.launch(SourceJob('ingest',self.archive,paths=paths),self.got_download)
        except Exception as exc:self.error(str(exc))

    def open_portal(self):
        url='https://brasil.mapbiomas.org/downloads/baixe-mapas-recortados-geotiff-via-google-earth-engine/' if self.source.currentData()=='mapbiomas' else 'https://search.earthdata.nasa.gov/search?q=AST_L1T'
        QDesktopServices.openUrl(QUrl(url))

    def cancel(self):
        if self.job:self.job.cancel();self.info.setText('Cancelando; produtos concluídos preservados.')

    def error(self,message):
        self.info.setText(message);QMessageBox.warning(self,'Fontes complementares',message)

    def finished(self):
        self.job=None;self.busy(False)
