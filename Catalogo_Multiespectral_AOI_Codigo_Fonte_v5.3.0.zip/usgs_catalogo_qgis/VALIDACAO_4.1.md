# Validação 4.1.0 · acervos públicos de imagens

## Resultado

**244 testes passaram, sem testes pulados**, em Linux, QGIS 3.40.6, GDAL 3.10.3, Qt 5.15.15 e Python 3.13, com Qt offscreen. A suíte foi executada sobre a implementação final, incluindo interface, importação, comandos, fontes, calibração, índices, tarefas, acervo, investigação e relatórios.

Flake8 no perfil F,E711,E712,E713,E714,E721,E722,E731,E741,E742,E743,E9: sem achados. Bandit: zero achados. Detect-secrets com todos os arquivos: zero achados. Compilação Python e leitura de metadata.txt com ConfigParser padrão aprovadas. ZIP de instalação e ZIP de código-fonte tiveram sua estrutura e integridade verificadas durante o empacotamento.

## Downloads reais sem conta

Consultados pelas APIs usadas pelo plugin, em um recorte de teste no Brasil, e baixados sem credenciais de usuário:

| Fonte | Cena de teste | Operações concluídas |
|---|---|---|
| NASA HLS L30 / Microsoft | HLS.L30.T22MEA.2024238T132926.v2.0 | Fmask, cor natural, composição SWIR1/NIR/vermelho, NDVI, NBR e Band Set de 7 bandas |
| NASA HLS S30 / Microsoft | HLS.S30.T22MEA.2024240T133839.v2.0 | Fmask, cor natural, composição SWIR1/NIR/vermelho, NDVI, NBR e Band Set de 11 bandas |
| Sentinel-2 C1 L2A / AWS | S2B_T22MEA_20240827T134306_L2A | SCL, cor natural, composição SWIR1/NIR/vermelho, NDVI, NBR e Band Set de 12 bandas |

Os três fluxos terminaram sem erros de aquisição. Todas as bandas RGB do recorte tiveram dados válidos; HLS preservou NoData -9999 e grade de 30 m. A máscara de qualidade retornou fração válida 1,0 nos recortes. HLS S30 apresentou menor fração clara, e essa diferença foi mantida: sucesso de download não significa aprovação automática pelos limiares de qualidade de uma tarefa.

Os três produtos foram reabertos pelo fluxo de download offline com requisições de rede bloqueadas no teste, reutilizando os arquivos existentes. Seis renderizações QGIS, cor natural e composição de apoio PRODES em cada fonte, foram produzidas. Três foram inspecionadas visualmente; havia cores e informação espacial, sem importar um raster preto/vazio. A renderização usa a escala/offset reais do provedor, inclusive a escala HLS incorporada ao GeoTIFF/VRT. Não foram produzidos detalhes artificiais acima da resolução original.

O proxy necessário ao executor foi configurado apenas no programa de validação, não incluído no plugin. Nenhuma senha, conta Earthdata, chave AWS ou token particular foi utilizado. A Microsoft fornece automaticamente autorização temporária pública de leitura, como no acesso Landsat existente.

## Regressões e casos de segurança

- HLS S30 usa B8A para NIR espectralmente compatível com L30 B05. Band Set ordena bandas refletivas e exclui Fmask, ângulos, cirrus/temperatura não tratados como superfície.
- Fmask zero é terreno claro válido. Água, nuvem, vizinhança de nuvem, sombra, neve, aerossol alto e preenchimento são tratados separadamente. Zero de reflectância não vira NoData HLS.
- Escala 0,0001, offset zero e NoData -9999 são usados em HLS. Metadados NASA ausentes não acionam a antiga calibração Landsat por engano.
- Sentinel-2 AWS C1 exige metadados explícitos de escala e offset. Composições prontas/miniaturas não substituem as bandas científicas. URLs protegidas/requester-pays são descartadas.
- Representações Microsoft/AWS permanecem separadas. Falha de uma fonte não descarta a outra; paginação e filtros são preservados. URLs e métodos não autorizados são recusados.
- Comandos podem escolher NASA HLS, L30 ou S30; destinos QGIS/acervo e taxas de nuvens continuam explícitos.
- Interface de cinco abas testada em 1180×850, 1024×700 e 900×600; botão azul fixo e Alt+I continuam acessíveis. A consulta NASA usa o limite indicado na aba Imagens, inclusive feição selecionada/desenho em edição.
- Os testes de fontes retiradas permanecem como regressões dos módulos legados, sem exposição dessas consultas na interface atual. Reabertura de arquivos locais antigos e seus estilos foi preservada.

## Distribuição e limites

Metadata: versão 4.1.0, experimental=False, QGIS mínimo 3.40 e máximo 3.99, licença GPL-2.0-or-later, autor e contato revisados. Descrição em inglês informa somente as fontes ativas e as dependências. Os links GitHub do repositório e de issues responderam HTTP 200 nesta revisão.

A instalação Windows e o projeto real do usuário não foram executados aqui. As consultas online são testes pontuais, sem garantia de disponibilidade futura ou de todos os anos para todos os imóveis. O espelho Microsoft HLS anuncia início em 2020. A série NASA original é mais longa, mas não foi anunciada como integralmente disponível neste acesso.

O portal MapBiomas informava suspensão temporária do download de mapas em 20/11/2026. A retirada do conector não declara o fim dos dados MapBiomas/GEE. ASTER não foi convertido em acesso anônimo; a integração NASA baixável é HLS, um produto diferente.

A simulação de terreno sob nuvens foi descartada. A opacidade não recupera observações ausentes. Não foi validada uma taxa de acerto temática, uma decisão jurídica ou a precisão cartográfica de um parecer ambiental. O sinalizador de distribuição estável não substitui a revisão do profissional responsável nem a aprovação do repositório QGIS.

Nenhum envio ao GitHub ou ao catálogo oficial QGIS foi realizado. O ZIP de código-fonte deve atualizar o repositório antes da submissão do ZIP de instalação correspondente.
