# Proteções de execução 5.2.6 — 23/11/2026

Problema observado: exceções no retorno da busca ao ler/gravar o acervo no disco D:,
indisponível no Windows durante a inspeção. Há também registros de fechamento nativo
Qt (stack overflow/access violation) sem pilha que confirme a origem exata.

Mudanças:
- Verificação do acervo e persistência da busca em segundo plano.
- Leitura inválida/unidade perdida não escapam do callback para a interface Qt;
  o catálogo existente e a preferência de localização são preservados.
- Resultados cancelados/descartados não atualizam a interface. Exceções Python ao
  apresentar resultados são registradas e exibidas sem abrir novo diálogo modal.
- Fechamento cancela/desconecta tarefas sem esperar rede/GDAL e sem encadear close
  recursivamente. Ao reabrir, as abas aguardam as tarefas anteriores terminarem.
  Uma chamada nativa bloqueada ainda pode levar até seu timeout para encerrar.
- Miniaturas somente ao selecionar uma cena, uma por vez; cache limitado a 16 imagens
  e apenas a seleção mais recente permanece na fila. Sem baixar todas as miniaturas.
- Bandas baixadas sequencialmente, reduzindo concorrência de disco/memória com o mapa.
- Preparação da prévia em segundo plano e cinco abas preservadas.

Validação: 301 testes aprovados, zero falhas, zero erros, zero ignorados, em processo
separado com QGIS 3.44.7/Python 3.12 no Windows e configurações de teste isoladas.
Inclui perda de unidade, falha de escrita/leitura, callback com erro, resultado tardio,
fechamento durante tarefa, timer da interface, cache limitado e concorrência serial.
Bandit 1.9.4: zero apontamentos/erros, todas as regras padrão, sem suprimir regras.
Flake8 7.5.0: zero nas regras F,E711,E712,E713,E714,E721,E722,E731,E741,E742,E743,E9.
ZIPs validados por CRC e correspondência entre plugin e código-fonte.

Entrega: pacote preparado; não instalado nem reativado automaticamente. A configuração
do perfil default foi conferida com usgs_catalogo_qgis=false. Projeto e acervo não foram
movidos ou apagados. Reconecte D: ou escolha uma pasta acessível antes de usar o acervo.
experimental=False é mantido, sem representar certificação de ausência de falhas.
Não foi reproduzida conclusivamente a queda nativa do Qt nem medido ganho de desempenho
no uso real após reativação. Os testes confirmam as proteções específicas acima.
