# SPDX-License-Identifier: GPL-2.0-or-later
"""3.5.3-style imagery page; secondary workflows are constructed on demand."""
from qgis.PyQt.QtWidgets import QDialog,QScrollArea,QWidget,QVBoxLayout,QLabel,QFileDialog
from qgis.PyQt.QtCore import QStandardPaths
from qgis.core import QgsSettings
from .plugin import CatalogDialog


class LightCatalogDialog(CatalogDialog):
    def __init__(self, iface, parent=None):
        super().__init__(iface,parent,compact=True)
        self.setWindowTitle('Catálogo Multiespectral 5.3.0 · Imagens, situação fundiária, PRODES e carta-imagem')

    def init_compact_pages(self):
        self.simple_mode=True
        self.prodes_dialog=self.environmental_tab=self.cartography_tab=None
        self._active_page=0
        self._pages={}
        for index,title in enumerate(('Situação fundiária','Analisar PRODES','Carta-imagem'),1):
            scroll=QScrollArea(self.tabs);scroll.setWidgetResizable(True)
            placeholder=QWidget();layout=QVBoxLayout(placeholder)
            note=QLabel('Abra esta aba para carregar os controles.');layout.addWidget(note);layout.addStretch()
            scroll.setWidget(placeholder);self.tabs.addTab(scroll,title);self._pages[index]=scroll
        self.environmental_scroll=self._pages[1];self.prodes_scroll=self._pages[2]
        self.tabs.currentChanged.connect(self.open_page)
        self.false_color.setText('Vegetação / umidade')
        self.info.setText('Busque e selecione uma cena. Escolha a opção de bandas nesta página e clique em Prévia e importar.')

    def open_page(self,index):
        if index!=self._active_page and self.workers():
            self.tabs.blockSignals(True);self.tabs.setCurrentIndex(self._active_page);self.tabs.blockSignals(False)
            self.info.setText('Aguarde ou cancele a operação atual antes de iniciar outro módulo.')
            return
        self._active_page=index
        if index==0:
            return
        try:
            widget=None
            if index==1 and self.environmental_tab is None:
                from .environmental_ui import EnvironmentalTab
                widget=self.environmental_tab=EnvironmentalTab(self.iface,self._pages[index])
                combo=widget.parcel
            elif index==2 and self.prodes_dialog is None:
                from .prodes_ui import ProdesDialog
                widget=self.prodes_dialog=ProdesDialog(self.iface,self._pages[index],embedded=True)
                combo=widget.property_box
            elif index==3 and self.cartography_tab is None:
                from .cartography_ui import CartographyTab
                widget=self.cartography_tab=CartographyTab(self)
                # Only explicitly checked vectors enter a new map.
                from qgis.PyQt.QtCore import Qt
                for i in range(widget.layers.count()):widget.layers.item(i).setCheckState(Qt.CheckState.Unchecked)
                combo=widget.parcel.combo
            if widget is not None:
                position=combo.findData(self.layer_box.currentData())
                if position>=0:combo.setCurrentIndex(position)
                if index==3:widget.parcel._explicit=True
                self._pages[index].setWidget(widget)
        except Exception as exc:
            self.command_error('Não foi possível abrir esta aba: '+str(exc))

    def show_prodes(self):
        self.tabs.setCurrentIndex(2)
        self.show();self.raise_();self.activateWindow()

    def selection_changed(self):
        super().selection_changed()
        self.false_color.setText('Vegetação / umidade')

    def choose_analysis_preset(self,preset):
        if self.job:return
        index=self.preset.findData(preset)
        if index>=0:self.preset.setCurrentIndex(index)
        self.tabs.setCurrentIndex(0)

    def workers(self):
        values=[self.job]
        for panel in (getattr(self,'prodes_dialog',None),getattr(self,'environmental_tab',None)):
            values.append(getattr(panel,'job',None))
        return [worker for worker in values if worker is not None]

    def select_archive_folder(self):
        if self.workers():
            self.info.setText('Aguarde ou cancele a operação antes de trocar o acervo.');return
        initial=QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DocumentsLocation)
        folder=QFileDialog.getExistingDirectory(self,'Pasta do acervo local',initial)
        if folder:self.run_job('folder',self.folder_ready,path=folder)

    def folder_ready(self,folder):
        self.archive_path=folder;QgsSettings().setValue('catalogo_multiespectral/acervo',folder)
        self.archive_label.setText(folder);self.archive_notice.clear();self.archive_notice.hide()
        self.archive=None;self.reset_results()
        self.info.setText('Pasta do acervo verificada. Faça uma nova busca.')

    def showEvent(self,event):
        self._closing=False
        if self.environmental_tab:self.environmental_tab.busy(False)
        if self.prodes_dialog:
            self.prodes_dialog.tabs.setEnabled(True);self.prodes_dialog.cancel_button.setEnabled(False)
        self.resume_when_idle()
        QDialog.showEvent(self,event)

    def closeEvent(self,event):
        self._closing=True;self.preview_generation+=1;self.preview_queue.clear()
        retiring=self.workers()+list(self.preview_replies)
        self._retiring_workers=list(getattr(self,'_retiring_workers',[]))+retiring
        for worker in retiring:worker.detach()
        self.job=None
        if self.environmental_tab:
            self.environmental_tab.job=None;self.environmental_tab.timer.stop()
        if self.prodes_dialog:
            self.prodes_dialog.job=None;self.prodes_dialog.map_stopping=True;self.prodes_dialog.maps_in_progress=False
            self.prodes_dialog.canvas.stopRendering();self.prodes_dialog.canvas.setLayers([])
        self.preview_replies.clear();self.preview_active=0
        preview=getattr(self,'image_preview',None)
        if preview is not None:preview.reject()
        self.set_busy(False)
        QDialog.closeEvent(self,event)
