# SPDX-License-Identifier: GPL-2.0-or-later
"""Local, QA-masked water indices and comparable observations on one grid."""
import csv
import html
import os
import numpy as np
from .spectral import INDEX_DEFINITIONS,normalized_difference
from .stac import CatalogError
from .classification import prepare_raster,mask_geometry,check
from .storage import atomic_json


def run_indices(payload,folder,cancelled=lambda:False,progress=lambda x:None):
    from osgeo import gdal
    from .prodes_auto import qa_valid
    from .preflight import validate_dates
    check(cancelled)
    images=payload['images'];index=payload['index']
    if index not in INDEX_DEFINITIONS:raise CatalogError('Índice desconhecido.')
    temporal=payload.get('mode')!='single'
    if temporal:validate_dates(images)
    elif len(images)!=1:raise CatalogError('Selecione uma imagem para calcular o índice.')
    threshold=float(payload.get('water_threshold',0))
    if not np.isfinite(threshold) or not -1<=threshold<=1:raise CatalogError('O limiar deve estar entre -1 e 1.')
    if any(not image.get('qa_path') or not os.path.isfile(image['qa_path']) for image in images):
        raise CatalogError('Todas as imagens precisam de QA. Reimporte o Band Set completo.')
    os.makedirs(folder,exist_ok=True)
    base=dict(payload,**images[0]);base['resolution']=max(image.get('resolution',0) for image in images)
    reference=prepare_raster(base,folder,cancelled);grid=gdal.Open(reference)
    gt=grid.GetGeoTransform();bounds=(gt[0],gt[3]+grid.RasterYSize*gt[5],gt[0]+grid.RasterXSize*gt[1],gt[3])
    inside=mask_geometry(grid,[payload['geometry']])!=0;common=inside.copy();paths=[]
    def aligned(path,nodata):
        ds=gdal.Warp('',path,format='MEM',dstSRS=grid.GetProjection(),outputBounds=bounds,
                     width=grid.RasterXSize,height=grid.RasterYSize,resampleAlg='near',dstNodata=nodata,outputType=gdal.GDT_Float32,
                     callback=lambda *args:0 if cancelled() else 1)
        check(cancelled)
        if ds is None:raise CatalogError('Não foi possível alinhar uma das entradas.')
        return ds
    def save(path,values):
        partial=path+'.part.tif';out=None
        try:
            check(cancelled)
            out=gdal.GetDriverByName('GTiff').Create(partial,grid.RasterXSize,grid.RasterYSize,1,gdal.GDT_Float32,['TILED=YES','COMPRESS=DEFLATE'])
            out.SetProjection(grid.GetProjection());out.SetGeoTransform(gt)
            out.SetMetadata({'INDEX':index.upper(),'FORMULA':'(A-B)/(A+B)','QA_APPLIED':'True','SOURCE':'Catálogo Multiespectral 5.2.0'})
            out.GetRasterBand(1).SetNoDataValue(-9999);out.GetRasterBand(1).WriteArray(values);out=None
            check(cancelled);os.replace(partial,path)
        finally:
            out=None
            if os.path.isfile(partial):os.remove(partial)
    for n,image in enumerate(images):
        check(cancelled);progress('Calculando '+index.upper()+' · '+image.get('date','sem data'))
        ds=aligned(image['path'],-9999);channels=[];valid=inside.copy()
        for number in image['pair']:
            raw=ds.GetRasterBand(number).ReadAsArray();valid&=np.isfinite(raw)&(raw!=-9999)
            scale,offset=image['coefficients'][number-1];channels.append(raw*scale+offset)
        ds=None;values=normalized_difference(*channels);channels=[]
        qa=aligned(image['qa_path'],255);valid&=qa_valid(qa.ReadAsArray().astype('uint32'),image['qa_kind']);qa=None
        if image.get('saturation_path'):
            sat=aligned(image['saturation_path'],65535);valid&=sat.ReadAsArray()==0;sat=None
        valid&=values!=-9999;common&=valid
        path=os.path.join(folder,index+'_'+str(n+1)+'.tif');save(path,np.where(valid,values,-9999));paths.append(path)
    if int(common.sum())<9:raise CatalogError('Menos de nove pixels válidos comuns. Escolha outras imagens ou outra área.')
    pixel_ha=abs(gt[1]*gt[5])/10000;series=[];first=None;last=None
    for image,path in zip(images,paths):
        check(cancelled);ds=gdal.Open(path);values=ds.ReadAsArray();ds=None;values=np.where(common,values,-9999)
        save(path,values)
        if first is None:first=values.copy()
        last=values
        row={'date':image.get('date','não informada'),'mean':float(values[common].mean()),'min':float(values[common].min()),'max':float(values[common].max())}
        if index in ('ndwi','mndwi'):row['water_ha']=int((common&(values>threshold)).sum())*pixel_ha
        series.append(row)
    output=paths[0]
    if temporal:
        output=os.path.join(folder,'delta_'+index+'.tif');save(output,np.where(common,last-first,-9999))
    csv_path=os.path.join(folder,'serie.csv')
    with open(csv_path,'w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(series[0]));writer.writeheader();writer.writerows(series)
    result={'type':'temporal_index' if temporal else 'spectral','index':index,'path':output,'observation_paths':paths,
            'dates':[i.get('date','não informada') for i in images],'series':series,'valid_ha':int(common.sum())*pixel_ha,
            'water_threshold':threshold,'csv':csv_path,'source':[i['source_info'] for i in images],
            'limitations':INDEX_DEFINITIONS[index][3]+' Somente pixels válidos comuns e resolução mais grosseira informada. '
            'Área por limiar é estimativa exploratória; confira visualmente. Não mede volume, vazão, profundidade ou potabilidade.'}
    result['report']=write_report(result,folder);atomic_json(os.path.join(folder,'resultado.json'),result)
    grid=None
    return result


def write_report(result,folder):
    def esc(value):
        return html.escape(str(value))
    title=INDEX_DEFINITIONS[result['index']][0]
    fields=list(result['series'][0]);body=['<!doctype html><meta charset="utf-8"><style>body{font:16px Arial;margin:32px;max-width:1000px}table{border-collapse:collapse}td,th{border:1px solid #abc;padding:8px}</style>',
        '<h1>'+esc(title)+'</h1><p>'+esc(result['limitations'])+'</p>',
        '<p>Área válida comum: {:.4f} ha. Limiar exploratório de água: índice &gt; {} (apenas NDWI/MNDWI).</p>'.format(result['valid_ha'],result['water_threshold']),
        '<p>Diferença: última data menos primeira. Médias e áreas usam os mesmos pixels em todas as datas.</p>' if result['type']=='temporal_index' else '',
        '<table><tr>'+''.join('<th>'+esc({'date':'Data','mean':'Média','min':'Mínimo','max':'Máximo','water_ha':'Área acima do limiar (ha)'}[f])+'</th>' for f in fields)+'</tr>']
    for row in result['series']:body.append('<tr>'+''.join('<td>'+esc(round(row[f],4) if isinstance(row[f],float) else row[f])+'</td>' for f in fields)+'</tr>')
    body+=['</table><h2>Fontes e calibração</h2><pre>'+esc(result['source'])+'</pre>']
    if result.get('input_checksums'):body.append('<h2>Integridade</h2><pre>'+esc(result['input_checksums'])+'</pre>')
    path=os.path.join(folder,'relatorio.html')
    with open(path,'w',encoding='utf-8') as stream:stream.write('\n'.join(body))
    return path
