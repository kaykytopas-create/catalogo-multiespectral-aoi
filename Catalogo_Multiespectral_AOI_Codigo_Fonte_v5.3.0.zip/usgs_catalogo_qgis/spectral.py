# SPDX-License-Identifier: GPL-2.0-or-later
"""Two-band normalized differences, with explicit physical interpretation."""
INDEX_DEFINITIONS = {
    'ndvi': ('NDVI · vegetação', 'nir08', 'red', 'Vigor espectral da vegetação.'),
    'nbr': ('NBR · perturbação da vegetação', 'nir08', 'swir22', 'Mudança espectral; não determina causa.'),
    'ndwi': ('NDWI · água superficial', 'green', 'nir08', 'Realça água aberta; sombras e superfícies urbanas podem confundir.'),
    'mndwi': ('MNDWI · água / áreas urbanas', 'green', 'swir16', 'Realça água e reduz algumas confusões com áreas construídas.'),
    'ndmi': ('NDMI · umidade da vegetação', 'nir08', 'swir16', 'Indicador espectral de umidade da vegetação, não umidade do solo em porcentagem.'),
    'ndti': ('NDTI · contraste de turbidez', 'red', 'green', 'Indicador exploratório apenas sobre água identificada; não fornece NTU, concentração de sedimentos ou potabilidade.'),
}
INDEX_PRODUCTS = tuple(INDEX_DEFINITIONS)
ALIASES = {'green':'B03','red':'B04','blue':'B02','nir08':'B08','swir16':'B11','swir22':'B12'}


def band_pair(keys, index):
    pair = INDEX_DEFINITIONS[index][1:3]
    return tuple(keys.index(k if k in keys else ALIASES[k])+1 for k in pair)


def normalized_difference(a, b):
    import numpy as np
    denominator=a+b
    valid=np.isfinite(a)&np.isfinite(b)&(a>=0)&(b>=0)&(a<=1.5)&(b<=1.5)&(denominator>1e-6)
    result=np.full(a.shape,-9999,dtype='float32')
    np.divide(a-b,denominator,out=result,where=valid)
    return result


def style_index(layer, index='ndwi', difference=False):
    from qgis.core import QgsColorRampShader,QgsRasterShader,QgsSingleBandPseudoColorRenderer
    from qgis.PyQt.QtGui import QColor
    limit=2 if difference else 1
    colors=[(-limit,'#a6611a'),(0,'#f5f5f5'),(limit,'#0185b4' if index in ('ndwi','mndwi') else '#35955b')]
    if index=='ndti':colors=[(-limit,'#2166ac'),(0,'#f5f5f5'),(limit,'#8c510a')]
    ramp=QgsColorRampShader(-limit,limit);ramp.setColorRampType(QgsColorRampShader.Type.Interpolated)
    ramp.setColorRampItemList([QgsColorRampShader.ColorRampItem(v,QColor(c),str(v)) for v,c in colors])
    shader=QgsRasterShader(-limit,limit);shader.setRasterShaderFunction(ramp)
    layer.setRenderer(QgsSingleBandPseudoColorRenderer(layer.dataProvider(),1,shader))
    layer.triggerRepaint()
