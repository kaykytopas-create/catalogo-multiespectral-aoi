# SPDX-License-Identifier: GPL-2.0-or-later
"""Public Sentinel-2 Collection 1 COGs from Earth Search v1.

Keep a separate internal collection so band files from Microsoft and AWS
are never mixed under one product identity or calibration.
"""
import copy
import math
from urllib.parse import urlparse
from .stac import CatalogError

COLLECTION = 'sentinel-2-l2a-aws'
REMOTE_COLLECTION = 'sentinel-2-c1-l2a'
SEARCH_URL = 'https://earth-search.aws.element84.com/v1/search'
ASSET_HOST = 'e84-earth-search-sentinel-data.s3.us-west-2.amazonaws.com'


def public_asset(url):
    parsed = urlparse(url)
    try:
        return (parsed.scheme == 'https' and parsed.hostname == ASSET_HOST
                and parsed.port in (None,443) and not parsed.username and not parsed.password
                and not parsed.query and parsed.path.startswith('/sentinel-2-c1-l2a/'))
    except ValueError:
        return False


def normalize_earth_search(raw):
    if raw.get('collection') != REMOTE_COLLECTION:
        raise CatalogError('A fonte AWS retornou uma coleção diferente de Sentinel-2 C1 L2A.')
    item = copy.deepcopy(raw)
    item['collection'] = COLLECTION
    item['catalog:original_collection'] = REMOTE_COLLECTION
    item['catalog:sources'] = ['Copernicus / AWS Open Data / Earth Search']
    item['catalog:product'] = 'Sentinel-2 L2A · AWS C1'
    item['catalog:kind'] = 'reflectance'
    assets = {}
    for key,asset in item.get('assets',{}).items():
        if not public_asset(asset.get('href','')):
            continue
        bands = asset.get('eo:bands') or [{}]
        name = bands[0].get('name','')
        if len(bands) == 1 and name.startswith('B') and asset.get('href','').lower().endswith('.tif'):
            metadata = (asset.get('raster:bands') or [{}])[0]
            try:
                scale,offset = float(metadata['scale']),float(metadata['offset'])
                if not math.isfinite(scale) or scale <= 0 or not math.isfinite(offset):
                    raise ValueError('calibration')
            except (KeyError,ValueError,TypeError) as exc:
                raise CatalogError('Calibração de superfície ausente/inválida na banda AWS '+name) from exc
            assets[name] = asset
        elif key.lower() == 'scl':
            asset.pop('eo:bands',None);assets['SCL'] = asset
        else:
            asset.pop('eo:bands',None);assets[key] = asset
    item['assets'] = assets
    return item
