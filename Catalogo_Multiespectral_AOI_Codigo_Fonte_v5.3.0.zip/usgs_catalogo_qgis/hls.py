# SPDX-License-Identifier: GPL-2.0-or-later
"""NASA HLS v2 surface reflectance, anonymously mirrored by Microsoft.

Keep HLS products distinct from USGS C2/ESA L2A: HLS is a harmonized
30 m product, not another mirror of the original scene and not ASTER.
"""
import copy
from .stac import CatalogError

HLS_COLLECTIONS = ('hls2-l30', 'hls2-s30')
HLS_LABELS = {'hls2-l30': 'NASA HLS L30 · Landsat · 30 m',
              'hls2-s30': 'NASA HLS S30 · Sentinel-2 · 30 m'}
# Use S30's narrow NIR B8A, spectrally matched to L30 B05.
COMMON = {'B01': 'coastal', 'B02': 'blue', 'B03': 'green', 'B04': 'red'}
EXTRA = {'hls2-l30': {'B05': 'nir08', 'B06': 'swir16', 'B07': 'swir22'},
         'hls2-s30': {'B05': 'rededge1', 'B06': 'rededge2', 'B07': 'rededge3',
                     'B08': 'nir', 'B8A': 'nir08', 'B11': 'swir16', 'B12': 'swir22'}}
WAVELENGTHS = {'coastal': .443, 'blue': .482, 'green': .561, 'red': .655,
               'rededge1': .704, 'rededge2': .740, 'rededge3': .783,
               'nir': .835, 'nir08': .865, 'swir16': 1.61, 'swir22': 2.20}


def normalize_hls(raw):
    collection = raw.get('collection')
    if collection not in HLS_COLLECTIONS:
        raise CatalogError('Coleção NASA HLS não reconhecida.')
    item = copy.deepcopy(raw)
    item['catalog:kind'] = 'reflectance'
    item['catalog:product'] = HLS_LABELS[collection]
    item['catalog:sources'] = ['NASA HLS / Microsoft Planetary Computer']
    item['catalog:resolution'] = 30
    item['catalog:units'] = 'surface_reflectance'
    assets = {}
    mapping = dict(COMMON, **EXTRA[collection])
    for key, asset in item.get('assets', {}).items():
        if key in mapping:
            semantic = mapping[key]
            asset['eo:bands'] = [dict((asset.get('eo:bands') or [{}])[0],
                                      name=key, common_name=semantic,
                                      center_wavelength=WAVELENGTHS[semantic])]
            asset['raster:bands'] = [{'scale': .0001, 'offset': 0,
                                       'nodata': -9999, 'spatial_resolution': 30}]
            assets[semantic] = asset
        else:
            # Angles, cirrus and brightness-temperature bands are not surface
            # reflectance Band Set members. They remain auxiliary assets.
            asset.pop('eo:bands', None)
            if key == 'Fmask':
                asset['raster:bands'] = [{'scale': 1, 'offset': 0, 'nodata': 255}]
            assets[key] = asset
    item['assets'] = assets
    return item


def fmask_flags(values):
    """NASA HLS v2 Fmask bits; zero is valid clear land, 255 is fill."""
    import numpy as np
    bits = values.astype('uint16')
    valid = np.isfinite(values) & (values >= 0) & (values < 255)
    clouds = (bits & 3) != 0  # reserved cirrus bit and cloud bit
    clear = valid & ((bits & 31) == 0) & ((bits & 192) != 192)
    return valid, clouds, clear
