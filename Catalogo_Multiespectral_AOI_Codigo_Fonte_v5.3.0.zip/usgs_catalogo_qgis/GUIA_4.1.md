# Guia 4.1 · tarefas prontas sem login

## Imagens

Escolha o limite, o período e as fontes. Landsat, Sentinel-2 e NASA HLS já vêm marcados. Sentinel-2 inclui Microsoft e AWS/Earth Search. HLS inclui L30 e S30 na mesma aba Imagens. Não existe mais a aba Fontes complementares.

Selecione uma cena e pressione Prévia e importar ou Alt+I. Confira nuvens, deslocamento, data e cobertura no mapa com o limite. Confirme para importar. O filtro da cena não equivale a ausência de nuvem dentro do imóvel. Na ausência de cobertura, tente outra cena real.

HLS mantém pixels de 30 m. Sentinel-2 mantém 10/20 m conforme banda. O espelho Microsoft HLS anuncia início em 2020; para datas anteriores use os demais acervos conforme disponibilidade.

## Bandas e análise

| Opção | RGB ou cálculo |
|---|---|
| Cor natural | Vermelho / verde / azul |
| PRODES e análise de vegetação | SWIR1 / NIR / vermelho |
| Infravermelho vegetação | NIR / vermelho / verde |
| Solo exposto / supressão | SWIR2 / SWIR1 / vermelho |
| Cicatriz e SWIR | SWIR2 / NIR / vermelho |
| Agricultura | SWIR2 / SWIR1 / azul |
| Terra / água | NIR / SWIR1 / vermelho |
| NDVI | (NIR − vermelho) / (NIR + vermelho) |
| NBR | (NIR − SWIR2) / (NIR + SWIR2) |

Os números são ajustados por produto. HLS S30 usa NIR B8A; Sentinel-2 L2A usa B08; HLS L30 usa B05. Band Set cria uma camada multibanda com bandas refletivas em ordem espectral. A aparência não comprova sozinha desmatamento, incêndio ou consolidação legal.

Os produtos ativos já são de superfície e dispensam outra aplicação de DOS1. Escala, offset e NoData são preservados. O zero da Fmask HLS representa terreno claro válido.

## Comandos

- Baixe e importe NASA HLS cor natural, uma imagem por ano de 2020 a 2025, com até 5% de nuvens.
- Baixe NASA HLS Landsat, composição PRODES, de 2020 a 2025 e salve no acervo offline.
- Busque imagens Sentinel-2 cor natural de 2020 a 2025.

NASA/HLS escolhe esse processamento; Landsat ou Sentinel-2 junto desse termo restringe L30 ou S30. Sem fonte explícita, o padrão continua Landsat. Acervo offline como destino permite download online; modo offline como origem usa somente arquivos locais. Ausência de resultado é informada sem relaxar os critérios.

## PRODES e acervo

PRODES reúne limite, consolidada técnica, incrementos anuais, aquisição temporal e relatório para revisão. Pode usar Landsat e NASA HLS com calibração e qualidade próprias. Diferenças de sensor, estação e processamento devem ser consideradas pelo técnico.

Acervo offline lista e reabre arquivos existentes. Auditoria completa verifica SHA-256 e blocos. Mantenha juntas as bandas de um VRT. A retirada das fontes complementares não apaga downloads anteriores. Não há reconstrução simulada de terreno sob nuvens nesta versão.
