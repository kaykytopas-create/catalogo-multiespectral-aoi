# Validação 5.1.0 — 21/11/2026

Ambiente: Windows, QGIS 3.44.7, Python 3.12 e GDAL/NumPy do QGIS.
Suíte completa: 282 testes aprovados, zero falhas, zero erros, zero testes ignorados.
Inclui os quatro testes que falharam na avaliação 5.0.1, testes de configuração guiada,
sincronização do imóvel, preferências, validação prévia, classificação sintética, séries,
fila real em QgsTask, cartas A4/A3 e exportação PNG/PDF, integridade e concorrência do acervo.
Os testes fecham os arquivos e liberam os objetos; não ignoram erros de exclusão.
O teste de bloqueio JSON verifica tanto recuperação transitória quanto preservação do
arquivo anterior quando o bloqueio persiste.

Os testes foram executados em processo QGIS separado, com configurações de teste isoladas.
O plugin instalado, projeto aberto, acervo e fila do usuário não foram substituídos.
Interfaces Início e Classificação verificadas por renderização Qt em 1024 × 700.
Não houve validação temática em campo, nova campanha de downloads online, certificação
de desempenho ou execução em todas as versões de QGIS. Os metadados declaram 3.40–3.99;
a execução desta entrega foi em 3.44.7. Nenhum critério de QA ou independência foi relaxado.

Reproduzir: no Python do QGIS, com o diretório do código no PYTHONPATH, inicialize
QgsApplication e execute unittest discover em usgs_catalogo_qgis/tests. Utilize perfil
de teste separado: alguns testes criam/removem camadas, layouts e preferências temporárias.
