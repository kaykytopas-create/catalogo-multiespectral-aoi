# SPDX-License-Identifier: GPL-2.0-or-later
import os
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QWidget,QVBoxLayout,QFormLayout,QHBoxLayout,QLabel,QComboBox,QLineEdit,QPushButton,QListWidget,QListWidgetItem,QFileDialog,QMessageBox
from qgis.core import QgsProject,QgsRasterLayer,QgsVectorLayer,QgsFeatureRequest
from .parcel import ParcelPicker
from .cartography import create_layout,export_layout


class CartographyTab(QWidget):
    def __init__(self,owner):
        super().__init__(owner);self.owner=owner;self.result=None
        layout=QVBoxLayout(self);intro=QLabel('Gere uma carta-imagem editável: mapa à esquerda, legenda e identificação à direita. Coordenadas, escala, área e SRC são calculados. Os campos e elementos podem ser ajustados no Designer de Layout do QGIS.');intro.setWordWrap(True);layout.addWidget(intro)
        self.parcel=ParcelPicker(owner.iface,owner.layer_box,self);layout.addWidget(self.parcel)
        form=QFormLayout();self.raster=QComboBox();self.preset=QComboBox();self.paper=QComboBox();self.orientation=QComboBox()
        for title,key in [('Manter composição atual',''),('Cor natural','natural'),('PRODES · SWIR1/NIR/vermelho','prodes'),('Cicatriz · SWIR2/NIR/vermelho','burn'),('Infravermelho vegetação','infrared')]:self.preset.addItem(title,key)
        self.paper.addItems(['A4','A3']);self.orientation.addItems(['Paisagem','Retrato'])
        for title,widget in [('Imagem / classificação',self.raster),('Composição (Band Set)',self.preset),('Folha',self.paper),('Orientação',self.orientation)]:form.addRow(title,widget)
        self.fields={}
        for key,title,default in [('title','Título','CARTA-IMAGEM'),('property','Propriedade',''),('owner','Detentor',''),('technician','Responsável técnico',''),('processor','Processamento',''),('municipality','Município / UF',''),('date','Data da imagem (se ausente na camada)','')]:
            edit=QLineEdit(default);self.fields[key]=edit;form.addRow(title,edit)
        layout.addLayout(form);self.layers=QListWidget();self.layers.setMaximumHeight(110);layout.addWidget(QLabel('Camadas temáticas da carta e da legenda:'));layout.addWidget(self.layers)
        self.logo='';row=QHBoxLayout()
        for title,callback in [('Atualizar camadas',self.refresh),('Escolher logomarca',self.choose_logo),('Gerenciador de layouts',self.manager)]:
            button=QPushButton(title);button.clicked.connect(callback);row.addWidget(button)
        layout.addLayout(row);row=QHBoxLayout()
        for title,callback in [('Gerar carta editável',self.generate),('Abrir designer',self.designer),('Exportar PDF / PNG',self.export)]:
            button=QPushButton(title);button.setMinimumHeight(42);button.clicked.connect(callback);row.addWidget(button)
        layout.addLayout(row);self.info=QLabel('A legenda usa as camadas selecionadas. PRODES não consultado não é apresentado como ausência de PRODES. Salve o projeto QGIS para manter o layout no Gerenciador.');self.info.setWordWrap(True);layout.addWidget(self.info);layout.addStretch();self.refresh()
    def refresh(self):
        checked={self.layers.item(i).data(Qt.ItemDataRole.UserRole):self.layers.item(i).checkState() for i in range(self.layers.count())}
        current=self.raster.currentData();self.raster.clear();self.layers.clear();self.parcel.refresh()
        for layer in QgsProject.instance().mapLayers().values():
            if not layer.isValid() or layer.customProperty('catalogo_layout_aux',False):continue
            if isinstance(layer,QgsRasterLayer):self.raster.addItem(layer.name(),layer.id())
            elif isinstance(layer,QgsVectorLayer) and layer.geometryType()==2:
                item=QListWidgetItem(layer.name());item.setData(Qt.ItemDataRole.UserRole,layer.id());item.setFlags(item.flags()|Qt.ItemFlag.ItemIsUserCheckable);item.setCheckState(checked.get(layer.id(),Qt.CheckState.Checked if 'prodes' in layer.name().lower() else Qt.CheckState.Unchecked));self.layers.addItem(item)
        index=self.raster.findData(current)
        if index>=0:self.raster.setCurrentIndex(index)
    def choose_logo(self):
        path,_=QFileDialog.getOpenFileName(self,'Logomarca','','Imagem (*.png *.jpg *.svg)')
        if path:self.logo=path
    def manager(self):
        if self.owner.iface:self.owner.iface.showLayoutManager()
    def generate(self):
        try:
            config={key:widget.text().strip() for key,widget in self.fields.items()};config.update(root=self.owner.archive_path,parcel=QgsProject.instance().mapLayer(self.parcel.resolve().layer_id),raster=QgsProject.instance().mapLayer(self.raster.currentData()),preset=self.preset.currentData(),paper=self.paper.currentText(),landscape=self.orientation.currentIndex()==0,logo=self.logo)
            config['plain']=getattr(self.owner,'simple_mode',False)
            layer=config['parcel'];features=list(layer.getSelectedFeatures()) if layer.selectedFeatureCount() else list(layer.getFeatures(QgsFeatureRequest().setLimit(2)))
            aliases={'property':('nome_imovel','imovel','nome','fazenda'),'owner':('detentor','proprietario','nome_prop'),'technician':('resp_tec','tecnico','responsavel'),'municipality':('municipio','nm_mun','municipality')}
            names={field.name().lower():field.name() for field in layer.fields()}
            for key,candidates in aliases.items():
                if config.get(key):continue
                for candidate in candidates:
                    if candidate not in names:continue
                    values={str(feature[names[candidate]]).strip() for feature in features if feature[names[candidate]] is not None and str(feature[names[candidate]]).strip() not in ('','NULL')}
                    if len(values)==1:config[key]=values.pop();self.fields[key].setText(config[key]);break
            if config.get('municipality') and 'uf' in names and '/' not in config['municipality']:
                ufs={str(feature[names['uf']]).strip() for feature in features}
                if len(ufs)==1:config['municipality']+='/'+ufs.pop();self.fields['municipality'].setText(config['municipality'])
            config['overlays']=[QgsProject.instance().mapLayer(self.layers.item(i).data(Qt.ItemDataRole.UserRole)) for i in range(self.layers.count()) if self.layers.item(i).checkState()==Qt.CheckState.Checked]
            self.result=create_layout(config,self.owner.iface);self.info.setText('Carta criada no Gerenciador de layouts. Modelo editável salvo: '+self.result['template'])
        except Exception as exc:self.error(exc)
    def designer(self):
        if self.result and self.owner.iface:self.owner.iface.openLayoutDesigner(self.result['layout'])
    def export(self):
        if not self.result:self.info.setText('Gere uma carta primeiro.');return
        path,_=QFileDialog.getSaveFileName(self,'Exportar carta',os.path.join(self.result['folder'],'carta.pdf'),'PDF (*.pdf);;PNG (*.png)')
        if path:
            try:export_layout(self.result['layout'],path);self.info.setText('Exportado: '+path)
            except Exception as exc:self.error(exc)
    def error(self,exc):self.info.setText(str(exc));QMessageBox.warning(self,'Carta-imagem',str(exc))
