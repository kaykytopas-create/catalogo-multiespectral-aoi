# Contributing

Use QGIS 3.40–3.x with its own Python, qgis.PyQt, GDAL and NumPy. Do not install a separate PyQt into QGIS. Tests include pure logic, synthetic rasters, managed task execution and GUI workflow checks; they require the QGIS runtime.

```sh
QT_QPA_PLATFORM=offscreen /usr/bin/python3 -m unittest discover -s usgs_catalogo_qgis/tests -v
python3 usgs_catalogo_qgis/tools/prepare_release.py --check
```

Network is mocked in automated tests. Live provider checks are separate and documented in VALIDACAO_4.0.md. Keep real client data and credentials out of tests and issue reports. Include QGIS/GDAL/plugin versions, CRS, scene ID, source, reproducible steps and the complete sanitized error.

Use TaskWorker/QgsTask with immutable input snapshots; create project layers/renderers only in GUI callbacks. A finished callback must remain short. Preserve source units, NoData and spectral identity. Never apply vegetation indices or radiometric correction to categorical maps. A new collection needs an explicit calibration rule and tests. Offline mode must not silently fall back to the network.

Public catalog requests use cancellable QgsNetworkAccessManager calls. Raster range reads use GDAL; proxy compatibility must also be checked in the intended environment. No provider credentials are bundled. QGIS4 compatibility is not declared.

GPL-2.0-or-later applies to contributions. Do not commit caches, imagery, client reports or compiled Python. Publish the source matching the installer.
