# SPDX-License-Identifier: GPL-2.0-or-later
"""Managed background work; terminal callbacks run on the GUI thread."""
from qgis.core import QgsApplication, QgsTask
from qgis.PyQt.QtCore import Qt, pyqtSignal


class TaskWorker(QgsTask):
    result = pyqtSignal(object)
    failed = pyqtSignal(str)
    status = pyqtSignal(str)
    done = pyqtSignal()

    def __init__(self, parent=None, description='Catálogo Multiespectral'):
        super().__init__(description, QgsTask.Flag.CanCancel)
        self._stop = False
        self._active = False
        self._detached = False
        self._failed = False
        self.failed.connect(self._record_failure, Qt.ConnectionType.DirectConnection)

    def _record_failure(self, message):
        self._failed = True

    @property
    def stopping(self):
        return self._stop or self.isCanceled()

    @stopping.setter
    def stopping(self, value):
        self._stop = bool(value)
        if value:
            super().cancel()

    def cancel(self):
        self.stopping = True

    def start(self):
        self._active = True
        QgsApplication.taskManager().addTask(self)

    def isRunning(self):
        return self._active

    def run(self):
        try:
            if not self.stopping:
                self.work()
            return not self.stopping and not self._failed
        except Exception as exc:
            if not self.stopping:
                self.failed.emit(str(exc))
            return False

    def finished(self, result):
        self._active = False
        if not self._detached:
            self.done.emit()

    def detach(self):
        """Unload must never block the GUI on an outstanding HTTP/GDAL request."""
        self._detached = True
        self.cancel()
        for name in ('result', 'failed', 'status', 'done', 'prepared'):
            signal = getattr(self, name, None)
            if signal is not None:
                try:
                    signal.disconnect()
                except (TypeError, RuntimeError):
                    continue
