# Uso da versão compacta 5.3.0

1. Abra Imagens e escolha a camada do limite. Se houver vários imóveis, selecione um.
2. Confira a pasta do acervo. Se a unidade D: estiver desconectada, reconecte-a ou
   use Escolher pasta para selecionar uma pasta acessível. Nenhum acervo é movido.
3. Escolha o período e os satélites. NASA HLS permanece disponível junto de Landsat
   e Sentinel-2. Clique em Buscar imagens e selecione uma cena.
4. Na própria página, em Opções de bandas e índices, escolha a composição RGB ou
   NDWI, MNDWI, NDMI, NDTI, NDVI ou NBR. A disponibilidade depende das bandas da cena.
5. Clique em Prévia e importar. Apenas mudar a opção de bandas não inicia processamento.
   Confira a prévia antes de importar a camada para o projeto.

NDWI/MNDWI ajudam a identificar água; NDMI indica umidade da vegetação. NDTI é um
índice exploratório, não uma medição de turbidez em laboratório. Nenhum deles mede
vazão, volume ou potabilidade. Nuvens, sombras, resolução e época influenciam o resultado.

Situação fundiária e Analisar PRODES têm abas próprias. Seus controles carregam
quando você abre a aba. Aguarde ou cancele a tarefa atual antes de mudar de módulo.
Fechar o plugin solicita cancelamento sem esperar a rede; chamadas nativas já
iniciadas podem aguardar o timeout para terminar.

Em Carta-imagem, escolha limite e imagem já importada, mantenha a composição atual,
preencha a identificação, marque apenas as camadas desejadas e gere a carta editável.
Use o Designer existente para ajustar e exportar PDF/PNG. Nenhum novo algoritmo foi criado.

Índices com mais de 4 milhões de pixels são recusados antes da alocação integral de
memória: use uma área menor. Miniaturas são obtidas somente para a cena selecionada;
downloads de bandas são sequenciais e as prévias são preparadas em segundo plano.
Fontes online indisponíveis são informadas; dados locais permanecem no acervo.
