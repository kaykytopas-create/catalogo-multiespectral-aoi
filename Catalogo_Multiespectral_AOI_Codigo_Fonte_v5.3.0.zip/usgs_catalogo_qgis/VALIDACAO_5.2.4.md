# Responsividade 5.2.4 — 23/11/2026

O QGIS instalado estava com o plugin 5.2.1. Foram encontrados registros Windows/Qt
de stack overflow e access violation em encerramentos anteriores. O registro Python
não continha pilha que atribuísse a falha a uma linha específica do plugin.
O projeto aberto tinha 69 camadas. Em processo separado, o projeto foi lido e a abertura
do plugin 5.2.3 levou aproximadamente 0,66 s. A reprodução isolada de 30 ciclos de seleção
de bandas/presets passou antes da correção, tanto com interface nativa quanto offscreen;
o teste com miniaturas online também passou. Portanto a falha nativa original não foi
reproduzida de forma conclusiva, nem pode ser declarada definitivamente eliminada.

Problemas verificáveis corrigidos: atalhos iniciavam aquisição sem um segundo clique;
contraste/inspeção de pixels eram executados na interface após download; a janela de prévia
usava exec modal dentro do callback da tarefa. Agora os atalhos só selecionam, a aquisição
é explícita, a preparação é feita com GDAL independente em segundo plano e a prévia abre
sem loop modal aninhado. Renderização é interrompida antes de alterar opacidade. O contorno
e a inspeção respeitam a seleção do imóvel. Estatística de fallback tem amostra limitada.
Também foi corrigida a mensagem de arquivo fora do acervo para caminhos em outro disco Windows.

295 testes aprovados, zero falhas, erros ou ignorados, no Windows/QGIS 3.44.7/Python 3.12.
Novos testes: atalhos sem download; amostragem e cancelamento; timer da interface continua
durante preparação lenta em QgsTask; prévia retorna sem exec e permite importar a camada.
Bandit 1.9.4: zero apontamentos/erros, todas as regras padrão, incluindo testes.
Flake8 7.5.0: zero apontamentos nas regras do projeto F,E711,E712,E713,E714,E721,E722,
E731,E741,E742,E743,E9 (não são todas as regras cosméticas do Flake8).
ZIPs validados por CRC e equivalência de arquivos. experimental=False preservado.
Não houve nova certificação de todos os serviços online, homologação temática ou aprovação
do repositório QGIS. O projeto e o acervo do usuário não foram modificados pelos testes.

Referência técnica sobre tarefas e interface:
https://api.qgis.org/api/master/classQgsTask.html
