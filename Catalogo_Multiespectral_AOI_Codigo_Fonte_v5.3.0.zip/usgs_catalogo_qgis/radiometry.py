# SPDX-License-Identifier: GPL-2.0-or-later
"""Collection-aware atmospheric rules; original surface products are preserved."""
import math
import os
from .stac import CatalogError

SURFACE_COLLECTIONS = {'landsat-c2-l2', 'sentinel-2-l2a', 'sentinel-2-l2a-aws', 'modis-09A1-061', 'hls2-l30', 'hls2-s30'}
WAVELENGTHS = {'coastal': .44, 'blue': .48, 'green': .56, 'red': .66,
               'nir08': .86, 'swir16': 1.61, 'swir22': 2.2}


def band_set(item):
    from .stac import available_bands
    def wavelength(pair):
        key, asset = pair
        band = (asset.get('eo:bands') or [{}])[0]
        return float(band.get('center_wavelength', WAVELENGTHS.get(band.get('common_name', key), 999)))
    return [key for key, _ in sorted(available_bands(item), key=lambda pair: (wavelength(pair), pair[0]))]


def correction_policy(item):
    collection = item.get('collection', '')
    kind = item.get('catalog:kind', 'reflectance')
    if kind == 'categorical':
        return {'action': 'skip', 'reason': 'Mapa categórico: classes preservadas; DOS1 e índices espectrais bloqueados.'}
    if kind == 'thermal':
        return {'action': 'skip', 'reason': 'Produto térmico: temperatura/qualidade, sem DOS1 ou NDVI.'}
    if collection in SURFACE_COLLECTIONS:
        return {'action': 'skip', 'reason': 'Reflectância de superfície já corrigida; não reaplicar DOS1.'}
    # DOS1 is allowed only for explicitly calibrated TOA reflectance, never DNs,
    # radiance, an unknown collection or an undocumented solar geometry.
    elevation = item.get('properties', {}).get('view:sun_elevation')
    try:
        valid_sun = math.isfinite(float(elevation)) and 0 < float(elevation) <= 90
    except (TypeError, ValueError):
        valid_sun = False
    if collection == 'landsat-c2-l1' and item.get('catalog:units') == 'toa_reflectance' and valid_sun:
        return {'action': 'dos1', 'reason': 'L1 calibrado em reflectância TOA; DOS1 por objeto escuro, registrado no acervo.'}
    return {'action': 'blocked', 'reason': 'Metadados radiométricos insuficientes para DOS1 seguro. Nenhuma correção inventada.'}


def dos1_file(source, target, item, key, cancelled=lambda: False):
    """Conservative dark-object subtraction on calibrated TOA reflectance.

    The 0.01 dark target and one-percent lower quantile are recorded. Sampling is
    bounded; this approximation is not a physical atmospheric inversion.
    """
    import numpy as np
    from osgeo import gdal
    if correction_policy(item)['action'] != 'dos1':
        raise CatalogError('DOS1 não permitido para esta coleção/unidade.')
    asset=item.get('assets',{}).get(key,{})
    band_info=(asset.get('eo:bands') or [{}])[0]
    common=band_info.get('common_name',key)
    wavelength=band_info.get('center_wavelength',WAVELENGTHS.get(common))
    if wavelength is None or not 0.3 <= float(wavelength) < 3.0:
        raise CatalogError('DOS1 bloqueado: banda não identificada como refletiva.')
    metadata = (asset.get('raster:bands') or [{}])[0]
    if 'scale' not in metadata:
        raise CatalogError('DOS1 exige escala/offset radiométricos explícitos por banda.')
    scale, offset = float(metadata['scale']), float(metadata.get('offset', 0))
    if not math.isfinite(scale) or scale <= 0 or not math.isfinite(offset):
        raise CatalogError('Calibração radiométrica inválida.')
    src = gdal.Open(source)
    band = src.GetRasterBand(1)
    nodata = band.GetNoDataValue()
    sample = band.ReadAsArray(buf_xsize=min(1024, src.RasterXSize), buf_ysize=min(1024, src.RasterYSize))
    valid = np.isfinite(sample)
    if nodata is not None:
        valid &= sample != nodata
    values = sample[valid].astype('float64')*scale+offset
    values = values[(values >= 0) & (values <= 1.5)]
    if len(values) < 100:
        raise CatalogError('DOS1: amostra insuficiente de pixels válidos.')
    dark = max(0., float(np.percentile(values, 1)) - .01)
    partial = target + '.part.tif'
    out = None
    try:
        out = gdal.GetDriverByName('GTiff').Create(partial, src.RasterXSize, src.RasterYSize, 1,
                    gdal.GDT_Float32, ['TILED=YES', 'COMPRESS=DEFLATE'])
        out.SetGeoTransform(src.GetGeoTransform()); out.SetProjection(src.GetProjection())
        out.SetMetadata({'ATMOSPHERIC_CORRECTION': 'DOS1', 'DARK_QUANTILE': '1',
                         'DARK_PATH_REFLECTANCE': str(dark), 'REFERENCE_REFLECTANCE': '0.01'})
        dst = out.GetRasterBand(1); dst.SetNoDataValue(-9999)
        for y in range(0, src.RasterYSize, 256):
            if cancelled():
                raise CatalogError('DOS1 cancelado.')
            raw = band.ReadAsArray(0, y, src.RasterXSize, min(256, src.RasterYSize-y))
            valid = np.isfinite(raw)
            if nodata is not None:
                valid &= raw != nodata
            result = np.where(valid, np.maximum(0, raw.astype('float32')*scale+offset-dark), -9999)
            dst.WriteArray(result, 0, y)
        out.FlushCache(); out = None
        src = None
        os.replace(partial, target)
    finally:
        out = src = None
        if os.path.exists(partial):
            os.remove(partial)
    return target
