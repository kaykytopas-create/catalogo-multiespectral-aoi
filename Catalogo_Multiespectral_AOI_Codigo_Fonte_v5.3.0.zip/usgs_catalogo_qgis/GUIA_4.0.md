# Guia 4.0 · tarefas prontas

## Imagens e Bandas

Selecione o imóvel e pesquise. O filtro inicial mantém cenas Landsat/Sentinel com menos de 20 por cento de nuvens. Selecione a linha com a data desejada. O botão azul fixo no rodapé, ou Alt+I, abre a prévia georreferenciada com o limite. Confirme para adicionar a composição. O arquivo permanece no acervo mesmo quando a prévia é fechada sem importar.

Na aba Bandas e análise, os atalhos escolhem a composição e iniciam o mesmo fluxo de prévia/importação. Cor natural, PRODES, vegetação, solo exposto e cicatriz têm bandas previamente mapeadas para cada sensor. NDVI usa NIR/vermelho; NBR usa NIR/SWIR2. A aparência espectral de uma cicatriz não comprova sua causa ou enquadramento legal.

Band Set completo adiciona uma única camada com todas as bandas espectrais disponíveis, em ordem de comprimento de onda. Esse botão reutiliza as bandas já salvas e baixa somente as faltantes. A composição visual e o Band Set são produtos distintos; não substituem as bandas originais.

## Fontes complementares

O limite é o mesmo escolhido em Imagens; o período é próprio desta aba. Consulte, selecione uma ou mais linhas e use Baixar/importar selecionados. Desmarque Importar no projeto para guardar somente no acervo.

- **MODIS:** composto de 8 dias, cerca de 500 m. A data mostrada é o início do intervalo, não uma captura instantânea. A cobertura e o estado de nuvens local devem ser conferidos; não é adequado para desenhar detalhes de pequenas propriedades.
- **ASTER:** lista metadados públicos. Abrir portal oficial direciona ao Earthdata para acesso externo aos arquivos; o plugin não solicita, guarda ou contorna credenciais.
- **GOES:** uma observação diária do canal térmico 13 às 15 h UTC, até 31 dias por busca. O produto é temperatura em Kelvin, não cor natural. Pixels de preenchimento e DQF diferente de zero viram NoData. Confirme qualidade antes de interpretar.
- **MapBiomas:** lista todos os anos da coleção 11, de 1985 a 2025, que tocam o período. Baixar série anual consultada tenta esses anos e informa falhas. Um bloqueio comum 401/403 interrompe novas tentativas na mesma fonte. Use o portal oficial/GEE enquanto o acesso público estiver indisponível. A entrada opcional de GeoTIFF local aceita arquivo por ano com AAAA no nome ou exportação multibanda com descrições classification_AAAA. A coleção do arquivo fornecido não é autenticada pelo plugin. Códigos de classe são preservados; códigos sem rótulo incorporado aparecem como Classe N.

## PRODES

A aba própria reúne limites, bases anuais por bioma, recorte, evidências e relatório. A investigação histórica continua usando Landsat/Sentinel e suas verificações existentes. Não substitui automaticamente a evidência por MODIS, GOES ou classes MapBiomas. As novas fontes podem ser adicionadas ao projeto como apoio, com sua origem explícita.

## Acervo offline

Atualizar lista usa o índice local. Na primeira listagem, pastas anteriores são indexadas automaticamente. Reabrir selecionado valida o arquivo e o adiciona sem rede. Verificar integridade completa relê os blocos e compara SHA-256. Arquivos divergentes são identificados, sem apagá-los automaticamente. Para recuperar uma banda de imagem, utilize Baixar novamente na aba Bandas e análise, com conexão à internet.

Não apague nem mova isoladamente as bandas que sustentam um VRT; mantenha a estrutura da pasta ao copiar o acervo. Arquivos de uma mesma cena podem atender a várias composições. O índice não contém uma cópia de todo o arquivo público: ele descreve os recortes efetivamente consultados/preparados para cada imóvel.

## Cancelamento e mensagens

Cancelar pede encerramento cooperativo. Uma leitura GDAL em curso pode levar até seu timeout para devolver o controle. Produtos já concluídos ficam salvos. Sem cobertura, acesso externo, indisponibilidade temporária e integridade divergente são situações diferentes, apresentadas como pendências/falhas, nunca como sucesso.
