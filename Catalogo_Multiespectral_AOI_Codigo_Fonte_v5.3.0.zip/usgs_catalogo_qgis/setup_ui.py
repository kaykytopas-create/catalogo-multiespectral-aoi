# SPDX-License-Identifier: GPL-2.0-or-later
"""Common settings and explicit navigation, without starting work implicitly."""
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QFormLayout, QHBoxLayout,
    QLabel, QPushButton, QComboBox, QCheckBox, QLineEdit, QDateEdit)
from qgis.core import QgsProject, QgsSettings
from .parcel import ParcelPicker
from .stac import CatalogError


def show_page(owner, page):
    if hasattr(owner,'show_step') and page is owner.analysis_scroll:
        owner.show_step(1)
        return
    for i in range(owner.tabs.count()):
        widget = owner.tabs.widget(i)
        if widget is page or (hasattr(widget, 'widget') and widget.widget() is page):
            owner.tabs.setCurrentIndex(i)
            return


class SetupTab(QWidget):
    def __init__(self, owner):
        super().__init__(owner)
        self.owner = owner
        layout = QVBoxLayout(self)
        intro = QLabel('Comece aqui: escolha o imóvel, confira as opções e aplique. '
                       'Os atalhos abrem a etapa desejada; nenhum download ou análise começa sozinho.')
        intro.setWordWrap(True)
        layout.addWidget(intro)
        self.parcel = ParcelPicker(owner.iface, owner.layer_box, self)
        layout.addWidget(self.parcel)
        form = QFormLayout()
        self.folder = QLabel(owner.archive_path); self.folder.setWordWrap(True)
        row = QHBoxLayout(); row.addWidget(self.folder, 1)
        button = QPushButton('Escolher pasta do acervo'); button.clicked.connect(self.choose_folder)
        row.addWidget(button); form.addRow('Salvar imagens e análises:', row)
        self.offline = QCheckBox('Usar somente arquivos já baixados')
        form.addRow('Sem internet:', self.offline)
        self.start = QDateEdit(); self.end = QDateEdit()
        for widget in (self.start, self.end):
            widget.setCalendarPopup(True); widget.setDisplayFormat('dd/MM/yyyy')
        self.start.setDate(owner.start.date()); self.end.setDate(owner.end.date())
        row = QHBoxLayout(); row.addWidget(self.start); row.addWidget(QLabel('até')); row.addWidget(self.end)
        form.addRow('Período para buscar imagens:', row)
        self.sources = QComboBox()
        for title, key in [('Todos os catálogos disponíveis', 'all'), ('Sentinel-2', 'sentinel'),
                           ('Landsat', 'landsat'), ('NASA HLS · 30 m', 'hls')]:
            self.sources.addItem(title, key)
        form.addRow('Satélites:', self.sources)
        self.paper = QComboBox(); self.paper.addItems(['A4', 'A3'])
        self.orientation = QComboBox(); self.orientation.addItems(['Paisagem', 'Retrato'])
        row = QHBoxLayout(); row.addWidget(self.paper); row.addWidget(self.orientation)
        form.addRow('Formato das cartas:', row)
        self.technician = QLineEdit(); self.technician.setPlaceholderText('Opcional; confira antes de emitir a carta')
        form.addRow('Responsável técnico:', self.technician)
        layout.addLayout(form)
        self.remember = QCheckBox('Lembrar satélites, modo offline, formato e responsável neste computador')
        layout.addWidget(self.remember)
        button = QPushButton('Aplicar configurações às abas'); button.clicked.connect(self.apply)
        layout.addWidget(button)
        self.info = QLabel('A seleção de feições do imóvel é respeitada em todas as abas.'); self.info.setWordWrap(True)
        layout.addWidget(self.info)
        for title, page in [('1. Buscar e escolher imagens', owner.imagery_page),
                            ('2. Baixar Band Set completo / conferir qualidade', owner.analysis_scroll),
                            ('3. Desenhar amostras e classificar', owner.classification_tab),
                            ('4. Comparar datas', owner.temporal_tab),
                            ('5. Gerar carta-imagem', owner.cartography_tab),
                            ('Ver tarefas e resultados', owner.queue_tab),
                            ('Consultar PRODES', owner.prodes_scroll),
                            ('Consultar situação ambiental e fundiária', owner.environmental_scroll),
                            ('Abrir acervo offline', owner.archive_tab)]:
            button = QPushButton(title)
            button.clicked.connect(lambda checked=False, target=page: show_page(owner, target))
            layout.addWidget(button)
        layout.addStretch()
        settings = QgsSettings()
        if settings.value('catalogo_multiespectral/facil/lembrar', False, type=bool):
            self.remember.setChecked(True)
            self.sources.setCurrentIndex(max(0, self.sources.findData(settings.value('catalogo_multiespectral/facil/fontes', 'all'))))
            self.offline.setChecked(settings.value('catalogo_multiespectral/facil/offline', False, type=bool))
            self.paper.setCurrentText(settings.value('catalogo_multiespectral/facil/folha', 'A4'))
            self.orientation.setCurrentIndex(1 if settings.value('catalogo_multiespectral/facil/orientacao', 0, type=int) == 1 else 0)
            self.technician.setText(settings.value('catalogo_multiespectral/facil/tecnico', '', type=str))

    def choose_folder(self):
        self.owner.select_archive_folder()
        self.folder.setText(self.owner.archive_path)
        self.info.setText(self.owner.archive_notice.text() or self.owner.info.text())

    def apply(self):
        owner = self.owner
        try:
            if owner.workers():
                raise CatalogError('Aguarde ou cancele as tarefas antes de aplicar as configurações.')
            if self.start.date() > self.end.date():
                raise CatalogError('A data inicial deve ser anterior ou igual à final.')
            parcel = self.parcel.resolve()
            owner.refresh_layers()
            owner.layer_box.setCurrentIndex(owner.layer_box.findData(parcel.layer_id))
            for tab in (owner.classification_tab, owner.temporal_tab, owner.cartography_tab):
                tab.parcel.refresh()
                tab.parcel.combo.setCurrentIndex(tab.parcel.combo.findData(parcel.layer_id))
                tab.parcel._explicit = True
            owner.prodes_dialog.refresh_layers()
            owner.prodes_dialog.property_box.setCurrentIndex(owner.prodes_dialog.property_box.findData(parcel.layer_id))
            owner.environmental_tab.refresh_layers()
            owner.environmental_tab.parcel.setCurrentIndex(owner.environmental_tab.parcel.findData(parcel.layer_id))
            layer = QgsProject.instance().mapLayer(parcel.layer_id)
            owner.prodes_dialog.selected.setChecked(bool(layer.selectedFeatureCount()))
            owner.environmental_tab.selected.setChecked(bool(layer.selectedFeatureCount()))
            owner.year.setCurrentIndex(0)
            owner.start.setDate(self.start.date()); owner.end.setDate(self.end.date())
            source = self.sources.currentData()
            owner.landsat.setChecked(source in ('all', 'landsat'))
            owner.sentinel.setChecked(source in ('all', 'sentinel'))
            owner.nasa_hls.setChecked(source in ('all', 'hls'))
            owner.offline.setChecked(self.offline.isChecked())
            owner.cartography_tab.paper.setCurrentText(self.paper.currentText())
            owner.cartography_tab.orientation.setCurrentIndex(self.orientation.currentIndex())
            owner.cartography_tab.fields['technician'].setText(self.technician.text().strip())
            settings = QgsSettings(); prefix = 'catalogo_multiespectral/facil/'
            settings.setValue(prefix+'lembrar', self.remember.isChecked())
            if self.remember.isChecked():
                for key, value in [('fontes', source), ('offline', self.offline.isChecked()),
                    ('folha', self.paper.currentText()), ('orientacao', self.orientation.currentIndex()),
                    ('tecnico', self.technician.text().strip())]: settings.setValue(prefix+key, value)
            else:
                for key in ('fontes', 'offline', 'folha', 'orientacao', 'tecnico'): settings.remove(prefix+key)
            self.info.setText('Configurações aplicadas. Escolha um atalho abaixo. '
                             'Nas consultas ambientais, confira também a UF e os campos específicos.')
        except Exception as exc:
            self.info.setText(str(exc))
