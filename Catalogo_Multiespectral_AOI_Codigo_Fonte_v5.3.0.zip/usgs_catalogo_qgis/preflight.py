# SPDX-License-Identifier: GPL-2.0-or-later
"""Cheap checks before queueing; pixel and QA checks remain in the worker."""
from datetime import date
from .stac import CatalogError


def validate_samples(regions):
    from .classification import CLASSES
    if not regions:
        raise CatalogError('Crie amostras: desenhe treino e validação independente para pelo menos duas classes.')
    counts = {}
    for region in regions:
        c, role = region['class'], region['role']
        if c not in CLASSES or role not in ('treino', 'validacao'):
            raise CatalogError('Amostra com classe ou finalidade inválida.')
        counts.setdefault(c, {'treino': 0, 'validacao': 0})[role] += 1
    missing = [CLASSES[c][0] + ': falta ' + ('treinamento' if not v['treino'] else 'validação independente')
               for c, v in sorted(counts.items()) if not v['treino'] or not v['validacao']]
    if len(counts) < 2:
        missing.insert(0, 'São necessárias pelo menos duas classes de cobertura.')
    if missing:
        raise CatalogError('Cada classe exige amostras separadas de treino e validação.\n' + '\n'.join(missing))
    from osgeo import ogr
    geometries = [ogr.CreateGeometryFromWkt(r['geometry']) for r in regions]
    for i, geom in enumerate(geometries):
        if geom is None or geom.IsEmpty() or not geom.IsValid():
            raise CatalogError('Amostra vazia ou inválida; revise o polígono '+str(i+1)+'.')
        for j in range(i):
            if geom.Intersects(geometries[j]) and geom.Intersection(geometries[j]).GetArea() > 1e-14:
                raise CatalogError('Amostras sobrepostas: polígonos {} e {}. Desenhe áreas separadas.'.format(j+1, i+1))
    return counts


def validate_dates(images):
    if not 2 <= len(images) <= 60:
        raise CatalogError('Selecione de duas a 60 imagens usando Ctrl ou Shift.')
    try:
        dates = [date.fromisoformat(i['date']) for i in images]
        if any(d.isoformat() != i['date'] for d, i in zip(dates, images)):
            raise ValueError()
    except (KeyError, TypeError, ValueError):
        raise CatalogError('Preencha todas as datas no formato AAAA-MM-DD, por exemplo 2024-08-15.')
    if len(set(dates)) != len(dates):
        raise CatalogError('Há datas repetidas. Escolha imagens de datas diferentes.')
