import os
import json
import tempfile
import unittest
import numpy as np
from osgeo import gdal
from qgis.core import QgsApplication,QgsProject,QgsRasterLayer
from qgis.PyQt.QtCore import QEventLoop,QTimer
from usgs_catalogo_qgis.tests.test_analysis5 import fixture
from usgs_catalogo_qgis.spectral import band_pair,normalized_difference
from usgs_catalogo_qgis.hydrology import run_indices
from usgs_catalogo_qgis.jrc_water import tile_urls,download
from usgs_catalogo_qgis.stac import CatalogError,index_keys,write_index
from usgs_catalogo_qgis.simple_ui import SimpleCatalogDialog,image_payload


def water_fixture(root):
    p=fixture(root);original=gdal.Open(p['path']);path=os.path.join(root,'six.tif')
    ds=gdal.GetDriverByName('GTiff').Create(path,64,64,6,gdal.GDT_Float32)
    ds.SetGeoTransform(original.GetGeoTransform());ds.SetProjection(original.GetProjection());original=None
    for n,value in enumerate([.1,.4,.2,.1,.05,.07],1):ds.GetRasterBand(n).Fill(value);ds.GetRasterBand(n).SetNoDataValue(-9999)
    ds=None;p.update(path=path,bands=['blue','green','red','nir08','swir16','swir22'],coefficients=[[1,0]]*6,resolution=30,date='2020-01-01')
    return p


class Water520Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QgsApplication.instance() or QgsApplication([],False)

    def test_normalized_formulas_invalid_pixels_and_band_aliases(self):
        result=normalized_difference(np.array([.4,0,-.1]),np.array([.1,0,.2]))
        self.assertAlmostEqual(float(result[0]),.6);self.assertEqual(result[1],-9999);self.assertEqual(result[2],-9999)
        self.assertEqual(band_pair(['B02','B03','B04','B08','B11','B12'],'mndwi'),(2,5))
        self.assertEqual(band_pair(['red','green'],'ndti'),(1,2))

    def test_downloaded_index_uses_calibration_and_requires_qa(self):
        with tempfile.TemporaryDirectory() as root:
            p=water_fixture(root);paths={}
            for key,number in [('green',2),('swir16',5)]:
                paths[key]=root+'/'+key+'.tif';ds=gdal.Translate(paths[key],p['path'],bandList=[number]);ds=None
            item={'collection':'hls2-s30','assets':{k:{'href':v,'eo:bands':[{'name':k}],'raster:bands':[{'scale':1,'offset':0}]} for k,v in paths.items()}}
            self.assertEqual(index_keys(item,'mndwi'),('green','swir16'))
            with self.assertRaisesRegex(CatalogError,'qualidade'):write_index(item,paths,root+'/bad.tif',gdal,'mndwi')
            paths['Fmask']=p['qa_path'];write_index(item,paths,root+'/index.tif',gdal,'mndwi')
            ds=gdal.Open(root+'/index.tif');a=ds.ReadAsArray();meta=ds.GetMetadata();ds=None
            self.assertTrue(np.allclose(a,(.4-.05)/(.4+.05)));self.assertEqual(meta['QA_APPLIED'],'True')

    def test_single_water_index_with_quality_and_provenance(self):
        with tempfile.TemporaryDirectory() as root:
            p=water_fixture(root);p['pair']=(2,4)
            qa=gdal.Open(p['qa_path'],gdal.GA_Update);a=np.zeros((64,64),dtype='uint8');a[:32,:]=2;qa.GetRasterBand(1).WriteArray(a);qa=None
            result=run_indices(dict(p,images=[p],index='ndwi',mode='single'),root+'/result')
            ds=gdal.Open(result['path']);a=ds.ReadAsArray();ds=None
            self.assertTrue(np.allclose(a[a!=-9999],.6));self.assertTrue(np.any(a==-9999))
            self.assertTrue(os.path.isfile(result['csv']));self.assertTrue(os.path.isfile(result['report']))
            self.assertGreater(result['series'][0]['water_ha'],0)

    def test_temporal_water_area_and_signed_change(self):
        with tempfile.TemporaryDirectory() as root:
            p=water_fixture(root);p['pair']=(2,4)
            second=dict(p,date='2021-01-01',path=root+'/second.tif')
            src=gdal.Open(p['path']);ds=gdal.GetDriverByName('GTiff').CreateCopy(second['path'],src);src=None
            ds.GetRasterBand(2).Fill(.1);ds.GetRasterBand(4).Fill(.4);ds=None
            result=run_indices(dict(p,images=[p,second],index='ndwi'),root+'/result')
            self.assertGreater(result['series'][0]['water_ha'],0);self.assertEqual(result['series'][1]['water_ha'],0)
            ds=gdal.Open(result['path']);a=ds.ReadAsArray();ds=None;self.assertTrue(np.allclose(a[a!=-9999],-1.2))

    def test_invalid_dates_qa_and_cancel_do_not_return_success(self):
        with tempfile.TemporaryDirectory() as root:
            p=water_fixture(root);p['pair']=(2,4)
            with self.assertRaises(CatalogError):run_indices(dict(p,images=[p,p],index='ndwi'),root+'/bad')
            with self.assertRaises(CatalogError):run_indices(dict(p,images=[dict(p,qa_path='')],index='ndwi',mode='single'),root+'/qa')
            with self.assertRaises(CatalogError):run_indices(dict(p,images=[p],index='ndwi',mode='single'),root+'/cancel',cancelled=lambda:True)
            self.assertFalse(any(n.endswith('.part.tif') for _,_,files in os.walk(root) for n in files))

    def test_jrc_grid_boundaries_product_and_offline(self):
        urls=tile_urls([-51,-4,-50.99,-3.99],'occurrence')
        self.assertEqual(len(urls),1);self.assertIn('occurrence_60W_0N_v1_5_2024.tif',urls[0])
        self.assertEqual(len(tile_urls([-50.01,-.01,-49.99,.01],'extent')),4)
        with self.assertRaises(CatalogError):tile_urls([-51,-4,-50,-3],'fake')
        with tempfile.TemporaryDirectory() as root:
            with self.assertRaisesRegex(CatalogError,'offline'):download(root,[-51,-4,-50.99,-3.99],'extent',offline=True)

    def test_restored_tabs_and_no_old_classification_execution(self):
        dialog=SimpleCatalogDialog(None)
        try:
            self.assertEqual([dialog.tabs.tabText(i) for i in range(dialog.tabs.count())],['Bandas e análise','Comparação temporal','Carta-imagem','Situação fundiária','Analisar PRODES'])
            dialog.tabs.setCurrentWidget(dialog.environmental_scroll)
            self.assertIs(dialog.tabs.currentWidget().widget(),dialog.environmental_tab)
            dialog.show_prodes()
            self.assertIs(dialog.tabs.currentWidget().widget(),dialog.prodes_dialog)
            marker=object();dialog.prodes_dialog.parcel=marker
            dialog.show_step(0);dialog.show_prodes()
            self.assertIs(dialog.prodes_dialog.parcel,marker)
            self.assertTrue(dialog.command_box.isHidden())
            dialog.show_step(1);self.assertEqual(dialog.steps.currentIndex(),1)
            with tempfile.TemporaryDirectory() as root:
                dialog.archive_path=root;dialog.queue_tab.root=None
                old=dialog.queue_tab.store().add('classification',{'samples':[]})
                dialog.queue_tab.refresh();self.assertEqual(dialog.queue_tab.rows,[])
                dialog.queue_tab.start();self.assertIsNone(dialog.queue_tab.job)
                self.assertEqual(dialog.queue_tab.store().read()[0]['id'],old['id'])
        finally:dialog.close()

    def test_single_index_runs_as_qgstask_and_imports(self):
        with tempfile.TemporaryDirectory() as root:
            p=water_fixture(root);p['pair']=(2,4)
            dialog=SimpleCatalogDialog(None);dialog.archive_path=root
            before=set(QgsProject.instance().mapLayers())
            try:
                dialog.queue_tab.enqueue('spectral',dict(p,images=[p],index='ndwi',mode='single'));dialog.queue_tab.start()
                loop=QEventLoop();dialog.queue_tab.job.done.connect(loop.quit);QTimer.singleShot(30000,loop.quit);loop.exec()
                row=dialog.queue_tab.store().read()[0];self.assertEqual(row['state'],'concluida',row['message'])
                layers=[l for ident,l in QgsProject.instance().mapLayers().items() if ident not in before]
                self.assertEqual(len(layers),1);self.assertIn('NDWI',layers[0].name())
                self.assertEqual(layers[0].customProperty('catalogo_multiespectral_periodo'),'2020-01-01')
            finally:
                for ident in set(QgsProject.instance().mapLayers())-before:QgsProject.instance().removeMapLayer(ident)
                dialog.close()

    def test_multispectral_collection_keys_and_swir_resolution(self):
        with tempfile.TemporaryDirectory() as root:
            p=water_fixture(root);layer=QgsRasterLayer(p['path'],'Band Set','gdal')
            metadata={'keys':['B02','B03','B04','B08','B11','B12'],'coefficients':p['coefficients'],'qa_path':p['qa_path'],'qa_kind':'sentinel','native_resolution':10,'scene_id':'test','collection':'sentinel-2-l2a'}
            layer.setCustomProperty('catalogo_multiespectral_espectral',json.dumps(metadata))
            try:self.assertEqual(image_payload(layer,'mndwi')['resolution'],20)
            finally:layer=None
