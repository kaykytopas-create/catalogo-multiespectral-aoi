# SPDX-License-Identifier: GPL-2.0-or-later
import os
import tempfile
import unittest
from qgis.core import QgsApplication,QgsProject,QgsVectorLayer,QgsFeature,QgsGeometry,QgsRasterLayer,QgsLayoutItemMap,QgsLayoutItemLegend
from usgs_catalogo_qgis.tests.test_analysis5 import fixture
from usgs_catalogo_qgis.cartography import create_layout,export_layout


class CartographyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QgsApplication.instance() or QgsApplication([],False);cls.app.initQgis()
    def test_editable_layout_and_actual_crs_area_legend_template_and_exports(self):
        with tempfile.TemporaryDirectory() as root:
            p=fixture(root);project=QgsProject.instance();parcel=QgsVectorLayer('Polygon?crs=EPSG:4326','Imóvel de teste','memory');f=QgsFeature();f.setGeometry(QgsGeometry.fromWkt(p['geometry']));parcel.dataProvider().addFeatures([f]);parcel.updateExtents();project.addMapLayer(parcel)
            raster=QgsRasterLayer(p['path'],'Cena sintética','gdal');project.addMapLayer(raster)
            for paper,landscape in [('A4',True),('A4',False),('A3',True)]:
                result=create_layout({'root':root,'parcel':parcel,'raster':raster,'title':'PRODES — IMÓVEL TESTE','property':'Imóvel teste','paper':paper,'landscape':landscape})
                layout=result['layout'];self.assertTrue(os.path.isfile(result['template']));self.assertGreater(result['area_ha'],360)
                self.assertIsInstance(layout.itemById('mapa_principal'),QgsLayoutItemMap);self.assertIsInstance(layout.itemById('legenda_editavel'),QgsLayoutItemLegend)
                self.assertEqual(layout.itemById('mapa_principal').crs().authid(),'EPSG:31982')
                self.assertTrue(any('PRODES não consultado' in item.text() for item in layout.items() if hasattr(item,'text')))
                export_layout(layout,os.path.join(root,paper+str(landscape)+'.png'));export_layout(layout,os.path.join(root,paper+str(landscape)+'.pdf'))
                self.assertGreater(os.path.getsize(os.path.join(root,paper+str(landscape)+'.pdf')),1000)
                project.layoutManager().removeLayout(layout)
            project.removeAllMapLayers()
            from qgis.PyQt.QtCore import QCoreApplication,QEvent
            # Layout removal schedules QObject deletion. Flush it before removing
            # GeoPackages held by the layout's render jobs on Windows.
            QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete)
            QgsApplication.processEvents()
            raster=None;parcel=None;result=None;layout=None
