# SPDX-License-Identifier: GPL-2.0-or-later
import json
import os
import tempfile
import unittest
import numpy as np
from osgeo import gdal,ogr,osr
from usgs_catalogo_qgis.classification import train_forest,predict,accuracy,run_classification
from usgs_catalogo_qgis.temporal import run_temporal
from usgs_catalogo_qgis.stac import CatalogError
from usgs_catalogo_qgis.work_queue import QueueStore,input_signatures


def geometry(x1,y1,x2,y2):
    geom=ogr.CreateGeometryFromWkt('POLYGON(({} {},{} {},{} {},{} {},{} {}))'.format(x1,y1,x2,y1,x2,y2,x1,y2,x1,y1))
    source=osr.SpatialReference();source.ImportFromEPSG(32722);target=osr.SpatialReference();target.ImportFromEPSG(4326)
    source.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER);target.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    geom.Transform(osr.CoordinateTransformation(source,target));return geom.ExportToWkt()


def fixture(root):
    sr=osr.SpatialReference();sr.ImportFromEPSG(32722);path=os.path.join(root,'source.tif')
    ds=gdal.GetDriverByName('GTiff').Create(path,64,64,3,gdal.GDT_Float32);ds.SetProjection(sr.ExportToWkt());ds.SetGeoTransform((500000,30,0,9600000,0,-30))
    rng=np.random.default_rng(42)
    for n,(left,right) in enumerate(((.15,.4),(.65,.25),(.06,.22)),1):
        a=np.full((64,64),left);a[:,32:]=right;a+=rng.normal(0,.003,a.shape);ds.GetRasterBand(n).WriteArray(a);ds.GetRasterBand(n).SetNoDataValue(-9999)
    ds=None
    qa_path=os.path.join(root,'quality.tif');qa=gdal.GetDriverByName('GTiff').Create(qa_path,64,64,1,gdal.GDT_Byte);qa.SetProjection(sr.ExportToWkt());qa.SetGeoTransform((500000,30,0,9600000,0,-30));qa.GetRasterBand(1).SetNoDataValue(255);qa.GetRasterBand(1).Fill(0);qa=None
    wkt=geometry(500000,9600000,501920,9598080);bounds=ogr.CreateGeometryFromWkt(wkt).GetEnvelope();regions=[]
    for c,x in ((1,500060),(2,501020)):
        for role,top in (('treino',9599940),('validacao',9598740)):
            regions.append({'class':c,'role':role,'geometry':geometry(x,top,x+360,top-360)})
    return {'path':path,'qa_path':qa_path,'qa_kind':'hls','rect':[bounds[0],bounds[2],bounds[1],bounds[3]],'geometry':wkt,'samples':regions,'coefficients':[[1,0]]*3,'bands':['swir16','nir08','red'],'source_info':{'scene':'synthetic','date':'2020-01-01'}}


class AnalysisTests(unittest.TestCase):
    def test_random_forest_reproducible_and_generalizes_to_independent_samples(self):
        rng=np.random.default_rng(1);x=rng.normal(size=(200,4));y=np.where(x[:,0]+x[:,1]>0,1,2)
        a=train_forest(x,y,12);b=train_forest(x,y,12)
        self.assertEqual(a,b);xx=rng.normal(size=(1000,4));truth=np.where(xx[:,0]+xx[:,1]>0,1,2);labels,votes=predict(a,xx)
        self.assertGreater(float((labels==truth).mean()),.85);self.assertTrue(np.all((votes>=.5)&(votes<=1)))
    def test_confusion_matrix_orientation_and_per_class_errors(self):
        result=accuracy(np.array([1,1,2,2]),np.array([1,2,2,2]),[1,2]);self.assertEqual(result['matrix_rows_reference_columns_prediction'],[[1,1],[0,2]]);self.assertEqual(result['overall_accuracy'],.75);self.assertEqual(result['per_class'][0]['recall'],.5)
    def test_cancelled_training_stops(self):
        with self.assertRaises(CatalogError):train_forest([[0],[1]],[1,2],cancelled=lambda:True)
    def test_full_classification_preserves_source_and_reports_independent_validation(self):
        with tempfile.TemporaryDirectory() as root:
            p=fixture(root);before=input_signatures(p);result=run_classification(p,os.path.join(root,'result'))
            self.assertEqual(before,input_signatures(p));self.assertGreater(result['metrics']['overall_accuracy'],.95);self.assertEqual(set(result['areas_ha']),{'1','2'});self.assertTrue(os.path.isfile(result['confidence']))
            with open(result['report']) as f:report=f.read()
            self.assertIn('Matriz de confusão',report);self.assertIn('Assinaturas espectrais',report);self.assertIn('Não é garantia',report)
    def test_validation_overlap_and_missing_class_are_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            p=fixture(root);p['samples'][1]['geometry']=p['samples'][0]['geometry']
            with self.assertRaisesRegex(CatalogError,'sobrepostas'):run_classification(p,os.path.join(root,'bad'))
            p=fixture(root);p['samples']=[r for r in p['samples'] if r['role']=='treino']
            with self.assertRaisesRegex(CatalogError,'Cada classe'):run_classification(p,os.path.join(root,'missing'))
    def test_temporal_real_dates_common_pixels_and_changes(self):
        with tempfile.TemporaryDirectory() as root:
            p=fixture(root);image={key:p[key] for key in ('path','bands','coefficients','source_info','qa_path','qa_kind')};image.update(index_bands={'swir':1,'nir':2,'red':3},date='2020-01-01')
            second=dict(image,date='2021-01-01');result=run_temporal(dict(p,images=[image,second]),os.path.join(root,'time'))
            self.assertAlmostEqual(result['decrease_ha'],0);ds=gdal.Open(result['path']);a=ds.ReadAsArray();self.assertTrue(np.all(a[a!=-9999]==0));self.assertEqual(len(result['series']),2)
            ds=None  # Close the GDAL handle before Windows removes the directory.
            with self.assertRaises(CatalogError):run_temporal(dict(p,images=[image,image]),os.path.join(root,'same'))
    def test_queue_persistence_retry_and_input_changes(self):
        with tempfile.TemporaryDirectory() as root:
            store=QueueStore(root);job=store.add('classification',{'test':1});store.update(job['id'],state='executando');store.recover();self.assertEqual(store.read()[0]['state'],'interrompida')
            store.update(job['id'],state='pendente');self.assertEqual(QueueStore(root).read()[0]['state'],'pendente')
            p=fixture(root);before=input_signatures(p);ds=gdal.Open(p['path'],gdal.GA_Update);ds.GetRasterBand(1).Fill(.2);ds=None;self.assertNotEqual(before,input_signatures(p))
            with open(store.path) as stream:self.assertEqual(json.load(stream)['version'],1)

class AdditionalQualityTests(unittest.TestCase):
    def test_indeterminate_predictions_count_as_validation_errors(self):
        m=accuracy(np.array([1,1,2,2]),np.array([1,0,2,0]),[1,2])
        self.assertEqual(m['validation_pixels'],4);self.assertEqual(m['overall_accuracy'],.5);self.assertIn(0,m['classes'])
    def test_json_model_round_trip_preserves_predictions(self):
        x=np.array([[0],[.1],[.2],[.8],[.9],[1]]*4);y=np.array([1,1,1,2,2,2]*4);m=train_forest(x,y,8)
        a,_=predict(m,x);b,_=predict(json.loads(json.dumps(m)),x);np.testing.assert_array_equal(a,b)
    def test_three_date_series_and_cancellation_cleanup(self):
        with tempfile.TemporaryDirectory() as root:
            p=fixture(root);image={key:p[key] for key in ('path','coefficients','source_info','qa_path','qa_kind')};image['index_bands']={'swir':1,'nir':2,'red':3}
            result=run_temporal(dict(p,images=[dict(image,date=date) for date in ('2020-01-01','2021-01-01','2022-01-01')]),os.path.join(root,'series'))
            self.assertEqual(len(result['series']),3)
            with self.assertRaises(CatalogError):run_classification(p,os.path.join(root,'cancel'),cancelled=lambda:True)
            self.assertFalse(any(name.endswith('.part.tif') for _,_,names in os.walk(root) for name in names))
    def test_corrupted_queue_is_reported_without_overwriting_it(self):
        with tempfile.TemporaryDirectory() as root:
            store=QueueStore(root)
            with open(store.path,'w') as f:f.write('{broken')
            with self.assertRaises(CatalogError):store.recover()
            with open(store.path) as f:self.assertEqual(f.read(),'{broken')

    def test_saturated_pixels_are_excluded_when_mask_is_available(self):
        with tempfile.TemporaryDirectory() as root:
            p=fixture(root);path=os.path.join(root,'saturation.tif')
            ds=gdal.GetDriverByName('GTiff').CreateCopy(path,gdal.Open(p['qa_path']))
            data=np.zeros((64,64),dtype='uint8');data[30:35,30:35]=1;ds.GetRasterBand(1).WriteArray(data);ds=None
            p['saturation_path']=path;result=run_classification(p,os.path.join(root,'masked'))
            self.assertGreaterEqual(result['unobserved_ha'],25*.09)
