# SPDX-License-Identifier: GPL-2.0-or-later
import copy
import unittest
from usgs_catalogo_qgis.earth_search import (COLLECTION, REMOTE_COLLECTION, ASSET_HOST,
    normalize_earth_search, public_asset)
from usgs_catalogo_qgis.public_sources import MultiCatalog,merge_scenes
from usgs_catalogo_qgis.stac import (CatalogError, index_keys, preset_keys,
    reflectance_coefficients, preview_url)
from usgs_catalogo_qgis.radiometry import correction_policy


def raw_sentinel():
    href='https://'+ASSET_HOST+'/sentinel-2-c1-l2a/tile/'
    bands=['B02','B03','B04','B08','B8A','B11','B12']
    assets={key:{'href':href+key+'.tif','eo:bands':[{'name':key}],
                'raster:bands':[{'scale':.0001,'offset':-.1,'nodata':0}]} for key in bands}
    assets.update(scl={'href':href+'SCL.tif'},thumbnail={'href':href+'thumbnail.jpg'},
                  visual={'href':href+'TCI.tif','eo:bands':[{'name':key} for key in ('B04','B03','B02')]},
                  preview={'href':href+'L2A_PVI.tif','eo:bands':[{'name':key} for key in ('B04','B03','B02')]},
                  protected={'href':'s3://requester-pays/original.jp2'})
    return {'id':'AWS-tile','collection':REMOTE_COLLECTION,
            'properties':{'datetime':'2024-08-27T13:43:38Z','eo:cloud_cover':5,'platform':'sentinel-2b'},'assets':assets}


class EarthSearchTests(unittest.TestCase):
    def test_presets_scale_qa_and_only_public_assets_are_retained(self):
        raw=raw_sentinel();original=copy.deepcopy(raw);item=normalize_earth_search(raw)
        self.assertEqual(raw,original);self.assertEqual(item['collection'],COLLECTION)
        self.assertEqual(preset_keys(item,'natural'),('B04','B03','B02'))
        self.assertEqual(preset_keys(item,'prodes'),('B11','B08','B04'))
        self.assertEqual(index_keys(item,'ndvi'),('B08','B04'))
        self.assertEqual(index_keys(item,'nbr'),('B08','B12'))
        self.assertEqual(reflectance_coefficients(item,'B04'),(.0001,-.1))
        self.assertEqual(correction_policy(item)['action'],'skip')
        self.assertIn('SCL',item['assets']);self.assertNotIn('protected',item['assets'])
        self.assertNotIn('eo:bands',item['assets']['visual'])
        self.assertTrue(item['assets']['B04']['href'].endswith('B04.tif'))
        self.assertIn('thumbnail.jpg',preview_url(item))

    def test_missing_or_unknown_calibration_is_not_invented(self):
        raw=raw_sentinel();raw['assets']['B04'].pop('raster:bands')
        with self.assertRaises(CatalogError):normalize_earth_search(raw)
        raw['collection']='sentinel-2-l1c'
        with self.assertRaises(CatalogError):normalize_earth_search(raw)

    def test_public_unsigned_urls_and_url_safety(self):
        client=MultiCatalog();url=raw_sentinel()['assets']['B04']['href']
        client.json_request=lambda *args:self.fail('A public AWS COG does not need signing')
        self.assertEqual(client.signed_url(url),url)
        for bad in (url.replace('https:','http:'),url.replace(ASSET_HOST,'user@'+ASSET_HOST),
                url.replace('/sentinel-2-c1-l2a/','/private/'),url+'?signature=wrong',
                url.replace(ASSET_HOST,ASSET_HOST+':bad')):
            self.assertFalse(public_asset(bad))
            with self.assertRaises(CatalogError):client.signed_url(bad)

    def test_aws_search_queries_only_aws_and_paginates_without_microsoft(self):
        client=MultiCatalog();calls=[]
        next_link={'href':'https://earth-search.aws.element84.com/v1/search?next=1','rel':'next'}
        def request(url,payload=None):
            calls.append((url,payload))
            return {'type':'FeatureCollection','features':[raw_sentinel()],
                    'links':[] if '?next' in url else [next_link]}
        client.json_request=request
        first,token=client.search([COLLECTION],[-50,-5,-49,-4],'2024-01-01','2024-12-31')
        second,last=client.search([COLLECTION],[-50,-5,-49,-4],'2024-01-01','2024-12-31',token)
        self.assertEqual(len(calls),2);self.assertIsNone(last)
        self.assertEqual(calls[0][1]['collections'],[REMOTE_COLLECTION])
        self.assertEqual(calls[0][1]['query']['eo:cloud_cover'],{'lt':20})
        self.assertEqual(first[0]['collection'],COLLECTION);self.assertEqual(len(second),1)

    def test_microsoft_outage_does_not_discard_aws_results(self):
        client=MultiCatalog()
        def request(url,payload=None):
            if 'microsoft.com' in url:raise CatalogError('test outage')
            return {'type':'FeatureCollection','features':[raw_sentinel()],'links':[]}
        client.json_request=request
        result,_=client.search(['sentinel-2-l2a',COLLECTION],[-50,-5,-49,-4],'2024-01-01','2024-12-31')
        self.assertEqual(len(result),1);self.assertIn('test outage',result.warnings[0])

    def test_aws_and_microsoft_representations_never_share_band_mirrors(self):
        aws=normalize_earth_search(raw_sentinel())
        pc=copy.deepcopy(aws);pc['collection']='sentinel-2-l2a'
        self.assertEqual(len(merge_scenes([pc,aws])),2)
        for link in ({'href':'https://evil.test/v1/search'},
                     {'href':'https://earth-search.aws.element84.com/private'},
                     {'href':'https://earth-search.aws.element84.com/v1/search','method':'DELETE'}):
            with self.assertRaises(CatalogError):MultiCatalog().search_earth_search([-50,-5,-49,-4],'2024-01-01','2024-12-31',link)
