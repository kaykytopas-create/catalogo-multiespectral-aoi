# SPDX-License-Identifier: GPL-2.0-or-later
import json
import unittest
from urllib.parse import parse_qs,urlparse
from usgs_catalogo_qgis.extended_sources import ExtendedCatalog,annual_items,normalize_modis
from usgs_catalogo_qgis.radiometry import correction_policy,band_set
from usgs_catalogo_qgis.stac import CatalogError,index_keys,preset_keys

RECT=(-55,-12,-54.99,-11.99)


class ExtendedSourceTests(unittest.TestCase):
    def test_annual_series_is_complete_and_bounded(self):
        items,warnings=annual_items(RECT,'1980-06-01','2026-02-01')
        self.assertEqual([v['properties']['year'] for v in items],list(range(1985,2026)))
        self.assertEqual(len({v['id'] for v in items}),41)
        self.assertTrue(warnings)
        for item in items:
            self.assertEqual(correction_policy(item)['action'],'skip')
            self.assertFalse(index_keys(item,'ndvi'));self.assertFalse(index_keys(item,'nbr'))
            self.assertEqual(band_set(item),[])
        self.assertEqual(annual_items((20,40,21,41),'2000-01-01','2001-12-31')[0],[])

    def test_mapbiomas_partial_year_includes_annual_map(self):
        items,_=annual_items(RECT,'2000-07-01','2002-02-01')
        self.assertEqual([v['properties']['year'] for v in items],[2000,2001,2002])

    def test_surface_policy_and_unknown_calibration_are_safe(self):
        for collection in ('landsat-c2-l2','sentinel-2-l2a','modis-09A1-061'):
            self.assertEqual(correction_policy({'collection':collection})['action'],'skip')
        self.assertEqual(correction_policy({'collection':'aster-l1t-004'})['action'],'blocked')
        item={'collection':'landsat-c2-l1','catalog:units':'toa_reflectance','properties':{'view:sun_elevation':40}}
        self.assertEqual(correction_policy(item)['action'],'dos1')
        item['properties']['view:sun_elevation']=float('nan')
        self.assertEqual(correction_policy(item)['action'],'blocked')

    def test_modis_semantics_order_scale_and_temporal_interval(self):
        assets={key:{'href':'https://test.blob.core.windows.net/modis/'+key+'.tif'} for key in
                ('sur_refl_b07','sur_refl_b01','sur_refl_b03','sur_refl_b02','sur_refl_b04','sur_refl_b05','sur_refl_b06')}
        item=normalize_modis({'id':'MOD09','collection':'modis-09A1-061','assets':assets,
            'properties':{'datetime':None,'start_datetime':'2024-07-01T00:00:00Z','end_datetime':'2024-07-08T23:59:59Z'}})
        self.assertEqual(band_set(item),['blue','green','red','nir08','nir12','swir16','swir22'])
        self.assertEqual(index_keys(item,'ndvi'),('nir08','red'))
        self.assertEqual(preset_keys(item,'natural'),('red','green','blue'))
        self.assertEqual(item['properties']['datetime'],'2024-07-01T00:00:00Z')
        self.assertTrue(item['properties']['end_datetime'].endswith('Z'))
        self.assertEqual(item['assets']['red']['raster:bands'][0]['scale'],.0001)
        self.assertEqual(item['assets']['nir12']['eo:bands'][0]['common_name'],'nir12')

    def test_aster_search_is_public_paginated_and_explicit_about_authentication(self):
        urls=[]
        def fetch(url):
            urls.append(url)
            return json.dumps({'feed':{'entry':[{'producer_granule_id':str(i),'time_start':'2000-01-01T00:00:00Z',
                   'links':[{'href':'https://example.nasa.gov/data.hdf'}]} for i in range(100)]}}).encode()
        data=ExtendedCatalog(fetch=fetch).search('aster',RECT,'2000-01-01','2000-12-31')
        self.assertEqual(data['cursor'],2)
        self.assertEqual(parse_qs(urlparse(urls[0]).query)['short_name'],['AST_L1T'])
        self.assertTrue(all(item['catalog:requires_auth'] for item in data['items']))
        self.assertTrue(data['warnings'])
        with self.assertRaises(CatalogError):ExtendedCatalog().download(data['items'][0],None,lambda x:None)

    def test_goes_daily_selection_and_transition_preserve_actual_timestamp(self):
        urls=[]
        def fetch(url):
            urls.append(url)
            satellite='19' if 'goes19' in url else '16'
            prefix=parse_qs(urlparse(url).query)['prefix'][0]
            stamp='20250941500200' if satellite=='19' else '20250931500300'
            key=prefix+'OR_ABI-L2-CMIPF-M6C13_G'+satellite+'_s'+stamp+'_e000_c000.nc'
            return ('<ListBucketResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/"><IsTruncated>false</IsTruncated><Contents><Key>'+key+'</Key></Contents></ListBucketResult>').encode()
        data=ExtendedCatalog(fetch=fetch).search('goes',RECT,'2025-04-03','2025-04-04')
        self.assertEqual(len(data['items']),2)
        self.assertIn('goes16',urls[0]);self.assertIn('goes19',urls[1])
        self.assertEqual(data['items'][0]['properties']['datetime'],'2025-04-03T15:00:30+00:00')
        for item in data['items']:
            self.assertFalse(index_keys(item,'ndvi'))
            self.assertEqual(correction_policy(item)['action'],'skip')
        with self.assertRaises(CatalogError):ExtendedCatalog(fetch=fetch).search('goes',RECT,'2020-01-01','2020-12-31')

    def test_no_coverage_failure_and_cancellation_are_distinguished(self):
        self.assertTrue(ExtendedCatalog(fetch=lambda url:b'').search('goes',(100,10,101,11),'2024-01-01','2024-01-01')['warnings'])
        def unavailable(url):raise OSError('HTTP 403')
        data=ExtendedCatalog(fetch=unavailable).search('goes',RECT,'2024-01-01','2024-01-01')
        self.assertEqual(data['items'],[]);self.assertIn('403',data['warnings'][0])
        with self.assertRaises(CatalogError):ExtendedCatalog(cancelled=lambda:True,fetch=unavailable).search('goes',RECT,'2024-01-01','2024-01-01')
