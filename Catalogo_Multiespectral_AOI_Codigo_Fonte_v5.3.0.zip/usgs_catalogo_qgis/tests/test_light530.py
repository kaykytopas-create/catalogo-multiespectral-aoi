# SPDX-License-Identifier: GPL-2.0-or-later
import tempfile
import unittest
from unittest.mock import patch,Mock
from qgis.core import QgsProject,QgsVectorLayer,QgsFeature,QgsGeometry
from qgis.PyQt.QtWidgets import QTableWidgetItem
from usgs_catalogo_qgis.light_ui import LightCatalogDialog
from usgs_catalogo_qgis.archive import LocalArchive
from usgs_catalogo_qgis.tests.test_presets_quality import scene
from usgs_catalogo_qgis.stac import write_index
from types import SimpleNamespace


class LightInterfaceTests(unittest.TestCase):
    def test_result_after_finished_does_not_repeat_archive_write_in_ui(self):
        with tempfile.TemporaryDirectory() as root:
            dialog=LightCatalogDialog(None)
            try:
                dialog.archive=LocalArchive(root,(-50,-5,-49.99,-4.99),'EPSG:4326');dialog.job=None
                worker=SimpleNamespace(_stop=False,_detached=False,archive_saved=True)
                with patch.object(dialog.archive,'remember_many') as write:
                    dialog.deliver_result(worker,dialog.got_scenes,([],None))
                write.assert_not_called()
                self.assertIsNone(dialog._callback_worker)
            finally:dialog.close()

    def test_oversized_index_is_rejected_before_memory_allocation(self):
        raster=SimpleNamespace(RasterXSize=3000,RasterYSize=3000)
        gdal=SimpleNamespace(Open=Mock(return_value=raster))
        with self.assertRaisesRegex(Exception,'memória limitada'):
            write_index(scene(),{'nir08':'nir.tif','red':'red.tif'},'unused.tif',gdal,'ndvi')

    def test_four_tabs_lazy_modules_and_inline_water_options(self):
        with patch('usgs_catalogo_qgis.plugin.resolve_archive',side_effect=AssertionError('disk probe at startup')):
            dialog=LightCatalogDialog(None)
        try:
            self.assertEqual([dialog.tabs.tabText(i) for i in range(dialog.tabs.count())],['Imagens','Situação fundiária','Analisar PRODES','Carta-imagem'])
            self.assertIsNone(dialog.prodes_dialog);self.assertIsNone(dialog.environmental_tab);self.assertIsNone(dialog.cartography_tab)
            self.assertFalse(hasattr(dialog,'queue_tab'));self.assertFalse(hasattr(dialog,'classification_tab'))
            self.assertTrue(dialog.imagery_page.isAncestorOf(dialog.preset));self.assertTrue(dialog.nasa_hls.isChecked())
            item=scene();dialog.scenes=[item];dialog.table.setRowCount(1)
            dialog.table.setItem(0,0,QTableWidgetItem('scene'))
            with patch.object(dialog,'pump_previews'):dialog.table.selectRow(0)
            values=[dialog.preset.itemData(i) for i in range(dialog.preset.count())]
            for index in ('ndwi','mndwi','ndmi','ndti','ndvi','nbr'):self.assertIn(index,values)
            with patch.object(dialog,'import_scene') as run:
                for index in ('natural','mndwi','ndti'):dialog.choose_analysis_preset(index)
                self.assertFalse(run.called)
        finally:dialog.close()

    def test_secondary_pages_load_once_and_close_safely(self):
        dialog=LightCatalogDialog(None)
        try:
            dialog.tabs.setCurrentIndex(1);environment=dialog.environmental_tab
            self.assertIsNotNone(environment);self.assertIsNone(dialog.prodes_dialog)
            dialog.show_prodes();prodes=dialog.prodes_dialog;self.assertIsNotNone(prodes)
            dialog.tabs.setCurrentIndex(3);self.assertIsNotNone(dialog.cartography_tab)
            dialog.tabs.setCurrentIndex(1);self.assertIs(dialog.environmental_tab,environment)
            dialog.tabs.setCurrentIndex(2);self.assertIs(dialog.prodes_dialog,prodes)
        finally:dialog.close()

    def test_many_parcels_are_rejected_without_reading_whole_layer(self):
        layer=QgsVectorLayer('Polygon?crs=EPSG:4326','many parcels','memory')
        feature=QgsFeature();feature.setGeometry(QgsGeometry.fromWkt('POLYGON((-50 -5,-49.99 -5,-49.99 -4.99,-50 -4.99,-50 -5))'))
        layer.dataProvider().addFeatures([feature,feature,feature]);QgsProject.instance().addMapLayer(layer)
        dialog=LightCatalogDialog(None)
        try:
            dialog.layer_box.setCurrentIndex(dialog.layer_box.findData(layer.id()))
            original=layer.getFeatures;limits=[]
            def bounded(request):
                limits.append(request.limit());return original(request)
            with patch.object(layer,'getFeatures',side_effect=bounded):
                with self.assertRaisesRegex(Exception,'única feição'):dialog.area()
            self.assertEqual(limits,[2])
        finally:dialog.close();QgsProject.instance().removeMapLayer(layer.id())

    def test_new_folder_commit_and_drive_failure_preserve_choice(self):
        with tempfile.TemporaryDirectory() as root:
            dialog=LightCatalogDialog(None)
            try:
                dialog.archive_path=root
                dialog.archive=LocalArchive(root,(-50,-5,-49.99,-4.99),'EPSG:4326')
                with patch.object(dialog.archive,'remember_many',side_effect=OSError('disk lost')):
                    dialog.got_scenes(([],None))
                self.assertEqual(dialog.archive_path,root);self.assertIn('Reconecte',dialog.info.text())
                dialog._closing=True
                callback=Mock();dialog.deliver_result(Mock(_stop=False,_detached=False),callback,[])
                self.assertFalse(callback.called)
            finally:dialog.close()
