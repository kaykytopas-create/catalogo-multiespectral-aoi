# SPDX-License-Identifier: GPL-2.0-or-later
import tempfile
import time
import unittest
from types import SimpleNamespace
from unittest.mock import patch
from qgis.core import QgsApplication,QgsProject,QgsVectorLayer,QgsFeature,QgsGeometry
from qgis.PyQt.QtCore import QEventLoop,QTimer,QThread
from usgs_catalogo_qgis.plugin import Job,PreviewDialog
from usgs_catalogo_qgis.simple_ui import SimpleCatalogDialog
from usgs_catalogo_qgis.archive import LocalArchive
from usgs_catalogo_qgis.display_prepare import prepare_display
from usgs_catalogo_qgis.tests.test_water520 import water_fixture
from usgs_catalogo_qgis.tests.test_presets_quality import scene


class ResponsivenessTests(unittest.TestCase):
    def test_band_shortcut_does_not_download(self):
        dialog=SimpleCatalogDialog(None)
        try:
            dialog.preset.addItem('Cor natural','natural')
            with patch.object(dialog,'import_scene') as download:
                dialog.choose_analysis_preset('natural')
                self.assertFalse(download.called)
                self.assertEqual(dialog.steps.currentIndex(),1)
        finally:dialog.close()

    def test_display_sample_and_cancellation(self):
        with tempfile.TemporaryDirectory() as root:
            fixture=water_fixture(root)
            output=prepare_display(fixture['path'],geometry=fixture['geometry'])
            self.assertEqual(len(output['limits']),3)
            self.assertIsNotNone(output['quality'])
            self.assertTrue(all(high>low for low,high in output['limits'].values()))
            with self.assertRaisesRegex(Exception,'cancelada'):
                prepare_display(fixture['path'],cancelled=lambda:True)

    def test_download_display_preparation_keeps_gui_timer_running(self):
        with tempfile.TemporaryDirectory() as root:
            fixture=water_fixture(root);archive=LocalArchive(root,(-55,-12,-54.99,-11.99),'EPSG:4326')
            item=scene();threads=[];ticks=[];events=[]
            def slow_prepare(*args,**kwargs):
                threads.append(QThread.currentThread()==QgsApplication.instance().thread())
                time.sleep(.2)
                return prepare_display(*args,**kwargs)
            job=Job('download',archive=archive,item=item,rgb_keys=('red','green','blue'),prepare_display=True)
            loop=QEventLoop();timer=QTimer();timer.timeout.connect(lambda:ticks.append(1));timer.start(10)
            job.result.connect(events.append);job.done.connect(loop.quit)
            with patch('usgs_catalogo_qgis.plugin.PublicCatalog.download_scene',return_value=([],[],fixture['path'])),patch('usgs_catalogo_qgis.display_prepare.prepare_display',side_effect=slow_prepare):
                job.start();QTimer.singleShot(10000,loop.quit);loop.exec()
            timer.stop()
            self.assertEqual(threads,[False]);self.assertGreater(len(ticks),3)
            self.assertEqual(len(events),1);self.assertIsNotNone(job.display)

    def test_preview_returns_without_nested_exec_and_can_import(self):
        with tempfile.TemporaryDirectory() as root:
            fixture=water_fixture(root)
            from osgeo import gdal
            path=root+'/rgb.tif';gdal.Translate(path,fixture['path'],bandList=[1,2,3])
            project=QgsProject.instance();before=set(project.mapLayers())
            parcel=QgsVectorLayer('Polygon?crs=EPSG:4326','test parcel','memory')
            feature=QgsFeature();feature.setGeometry(QgsGeometry.fromWkt(fixture['geometry']))
            parcel.dataProvider().addFeatures([feature]);parcel.updateExtents();project.addMapLayer(parcel)
            dialog=SimpleCatalogDialog(None)
            try:
                item=scene();item['properties']={'datetime':'2020-01-01','eo:cloud_cover':0}
                dialog.active_scene=item;dialog.active_layer_id=parcel.id();dialog.active_product='rgb'
                dialog.active_bands=('red','green','blue')
                dialog.active_archive=dialog.archive=LocalArchive(root,(-55,-12,-54.99,-11.99),'EPSG:4326')
                dialog.job=SimpleNamespace(display=prepare_display(path,geometry=fixture['geometry']))
                with patch.object(PreviewDialog,'exec',side_effect=AssertionError('nested modal loop')):
                    dialog.got_rasters(([],[],path))
                    self.assertIsNotNone(dialog.image_preview)
                    dialog.image_preview.accept()
                self.assertIsNone(dialog.image_preview)
                self.assertGreater(len(project.mapLayers()),len(before)+1)
            finally:
                dialog.job=None;dialog.close()
                for identifier in set(project.mapLayers())-before:project.removeMapLayer(identifier)
                QgsApplication.processEvents()
