import tempfile
import unittest
from unittest.mock import patch
from qgis.core import QgsApplication,QgsProject,QgsVectorLayer,QgsFeature,QgsGeometry
from qgis.PyQt.QtCore import QDate
from usgs_catalogo_qgis.plugin import CatalogDialog
from usgs_catalogo_qgis.preflight import validate_dates,validate_samples
from usgs_catalogo_qgis.setup_ui import show_page
from usgs_catalogo_qgis.stac import CatalogError
from usgs_catalogo_qgis.tests.test_analysis5 import fixture


class EasySetupTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QgsApplication.instance() or QgsApplication([],False)

    def setUp(self):
        self.layer=QgsVectorLayer('Polygon?crs=EPSG:4326','Imóvel configuração','memory')
        feature=QgsFeature();feature.setGeometry(QgsGeometry.fromWkt('POLYGON((-51 -4,-50.99 -4,-50.99 -4.01,-51 -4.01,-51 -4))'))
        self.layer.dataProvider().addFeatures([feature]);self.layer.updateExtents()
        QgsProject.instance().addMapLayer(self.layer)
        self.dialog=CatalogDialog(None)
        self.setup=self.dialog.setup_tab
        self.setup.parcel.combo.setCurrentIndex(self.setup.parcel.combo.findData(self.layer.id()))

    def tearDown(self):
        self.dialog.close()
        QgsProject.instance().removeMapLayer(self.layer.id())

    def test_apply_common_settings_and_navigation_without_queueing(self):
        self.setup.sources.setCurrentIndex(self.setup.sources.findData('hls'))
        self.setup.start.setDate(QDate(2020,1,1));self.setup.end.setDate(QDate(2021,1,1))
        self.setup.paper.setCurrentText('A3');self.setup.technician.setText('Técnico de teste')
        self.setup.remember.setChecked(False)
        before=self.dialog.queue_tab.store().read()
        self.setup.apply()
        self.assertIn('Configurações aplicadas',self.setup.info.text())
        for tab in (self.dialog.classification_tab,self.dialog.temporal_tab,self.dialog.cartography_tab):
            self.assertEqual(tab.parcel.combo.currentData(),self.layer.id())
            show_page(self.dialog,tab)
            self.assertIs(self.dialog.tabs.currentWidget().widget(),tab)
        self.assertEqual(self.dialog.environmental_tab.parcel.currentData(),self.layer.id())
        self.assertEqual(self.dialog.prodes_dialog.property_box.currentData(),self.layer.id())
        self.assertFalse(self.dialog.prodes_dialog.selected.isChecked())
        self.assertTrue(self.dialog.nasa_hls.isChecked());self.assertFalse(self.dialog.landsat.isChecked())
        self.assertEqual(self.dialog.start.date(),QDate(2020,1,1))
        self.assertEqual(self.dialog.cartography_tab.paper.currentText(),'A3')
        self.assertEqual(before,self.dialog.queue_tab.store().read())

    def test_selected_features_and_remembered_settings(self):
        self.layer.selectAll();self.setup.remember.setChecked(True)
        self.setup.sources.setCurrentIndex(self.setup.sources.findData('sentinel'))
        self.setup.paper.setCurrentText('A3');self.setup.apply()
        self.assertTrue(self.dialog.prodes_dialog.selected.isChecked())
        self.assertTrue(self.dialog.environmental_tab.selected.isChecked())
        other=CatalogDialog(None)
        try:
            self.assertTrue(other.setup_tab.remember.isChecked())
            self.assertEqual(other.setup_tab.sources.currentData(),'sentinel')
            self.assertEqual(other.setup_tab.paper.currentText(),'A3')
        finally:
            other.close();self.setup.remember.setChecked(False);self.setup.apply()

    def test_invalid_period_does_not_apply_anything(self):
        before=self.dialog.start.date()
        self.setup.start.setDate(QDate(2024,1,1));self.setup.end.setDate(QDate(2020,1,1))
        self.setup.apply()
        self.assertIn('data inicial',self.setup.info.text())
        self.assertEqual(self.dialog.start.date(),before)

    def test_missing_samples_are_explained_by_class(self):
        with tempfile.TemporaryDirectory() as root:
            p=fixture(root)
            self.assertEqual(len(validate_samples(p['samples'])),2)
            with self.assertRaisesRegex(CatalogError,'validação independente'):
                validate_samples([r for r in p['samples'] if r['role']=='treino'])

    def test_invalid_dates_are_rejected_before_queueing(self):
        for dates in ([],['2020-01-01'],['2020-01-01','2020-01-01'],['2020-13-01','2021-01-01'],['20200101','2021-01-01']):
            with self.assertRaises(CatalogError):validate_dates([{'date':d} for d in dates])
        validate_dates([{'date':'2020-01-01'},{'date':'2021-01-01'}])

    def test_classification_invalid_samples_do_not_enter_queue(self):
        tab=self.dialog.classification_tab
        with patch('usgs_catalogo_qgis.analysis_ui.raster_snapshot',return_value={}), \
             patch('usgs_catalogo_qgis.analysis_ui.region_payload',return_value=[]), \
             patch.object(tab,'error') as error, patch.object(self.dialog.queue_tab,'enqueue') as enqueue:
            tab.run();enqueue.assert_not_called();error.assert_called_once()

    def test_rgb_composition_is_not_silently_ignored(self):
        from qgis.core import QgsRasterLayer
        from usgs_catalogo_qgis.cartography import create_layout
        with tempfile.TemporaryDirectory() as root:
            p=fixture(root);raster=QgsRasterLayer(p['path'],'RGB','gdal')
            try:
                with self.assertRaisesRegex(CatalogError,'Manter composição atual'):
                    create_layout({'parcel':self.layer,'raster':raster,'preset':'burn','root':root})
            finally:raster=None
