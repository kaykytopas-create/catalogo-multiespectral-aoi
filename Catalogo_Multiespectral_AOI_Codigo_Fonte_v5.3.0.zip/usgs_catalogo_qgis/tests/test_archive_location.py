# SPDX-License-Identifier: GPL-2.0-or-later
"""Regression checks for unavailable Windows drives and unwritable archives."""
import os
import tempfile
import unittest
from unittest.mock import patch

from qgis.core import QgsApplication, QgsSettings
from usgs_catalogo_qgis.archive_location import resolve_archive, writable_directory
from usgs_catalogo_qgis.plugin import CatalogDialog
from usgs_catalogo_qgis.stac import CatalogError
from usgs_catalogo_qgis.work_queue import QueueStore


class ArchiveLocationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QgsApplication.instance() or QgsApplication([], False)
        cls.app.initQgis()

    def test_valid_archive_is_reused_and_probe_is_removed(self):
        with tempfile.TemporaryDirectory() as root:
            path = os.path.join(root, 'acervo')
            selected, notice = resolve_archive(path, [os.path.join(root, 'fallback')])
            self.assertEqual(selected, path)
            self.assertEqual(notice, '')
            self.assertEqual(os.listdir(path), [])

    def test_missing_windows_drive_opens_dialog_without_losing_preference(self):
        settings = QgsSettings()
        key = 'catalogo_multiespectral/acervo'
        existed = settings.contains(key)
        old = settings.value(key)
        missing = 'D:\\Acervo\\Catalogo'
        real_makedirs = os.makedirs

        def mkdir(path, *args, **kwargs):
            if os.fspath(path).startswith(os.path.abspath(missing)):
                raise FileNotFoundError(3, 'Unidade D indisponível', 'D:\\')
            return real_makedirs(path, *args, **kwargs)

        try:
            settings.setValue(key, missing)
            with tempfile.TemporaryDirectory() as root:
                with patch('usgs_catalogo_qgis.archive_location.os.makedirs', side_effect=mkdir), \
                     patch('usgs_catalogo_qgis.plugin.QStandardPaths.writableLocation', return_value=root):
                    dialog = CatalogDialog(None)
                    expected = os.path.join(root, 'Catalogo_Multiespectral_Acervo')
                    self.assertEqual(dialog.archive_path, expected)
                    self.assertEqual(settings.value(key), missing)
                    self.assertIn(missing, dialog.archive_notice.text())
                    self.assertIn('não foram movidos', dialog.archive_notice.text())
                    self.assertFalse(os.path.exists(dialog.queue_tab.store().path))
                    self.assertTrue(dialog.queue_tab.enqueue('download', {'test': True}))
                    self.assertTrue(os.path.isfile(os.path.join(expected, 'fila_tarefas.json')))
                    dialog.close()
        finally:
            if existed:
                settings.setValue(key, old)
            else:
                settings.remove(key)

    def test_readonly_preferred_location_uses_writable_fallback(self):
        with tempfile.TemporaryDirectory() as root:
            blocked, fallback = os.path.join(root, 'blocked'), os.path.join(root, 'fallback')
            real_probe = writable_directory

            def probe(path):
                if path == blocked:
                    raise CatalogError('Sem permissão')
                return real_probe(path)

            with patch('usgs_catalogo_qgis.archive_location.writable_directory', side_effect=probe):
                selected, notice = resolve_archive(blocked, [fallback])
            self.assertEqual(selected, fallback)
            self.assertIn(blocked, notice)

    def test_no_writable_location_does_not_prevent_opening(self):
        with tempfile.TemporaryDirectory() as root:
            missing = os.path.join(root, 'unavailable')
            with patch('usgs_catalogo_qgis.plugin.resolve_archive', return_value=(missing, 'Nenhuma pasta disponível')):
                dialog = CatalogDialog(None)
            self.assertEqual(dialog.tabs.count(), 10)
            self.assertIn('Nenhuma pasta', dialog.archive_notice.text())
            with patch('usgs_catalogo_qgis.work_queue.atomic_json', side_effect=PermissionError('Read only')):
                self.assertFalse(dialog.queue_tab.enqueue('download', {}))
            self.assertIn('Não foi possível salvar', dialog.queue_tab.info.text())
            self.assertFalse(os.path.exists(missing))
            dialog.close()

    def test_recovery_of_empty_or_unchanged_queue_does_not_write(self):
        with tempfile.TemporaryDirectory() as root:
            store = QueueStore(os.path.join(root, 'missing'))
            with patch('usgs_catalogo_qgis.work_queue.atomic_json', side_effect=PermissionError('Read only')) as write:
                store.recover()
                write.assert_not_called()
            self.assertFalse(os.path.exists(store.root))
            store = QueueStore(root)
            store.add('download', {})
            with patch('usgs_catalogo_qgis.work_queue.atomic_json') as write:
                store.recover()
                write.assert_not_called()

    def test_failed_recovery_can_retry_when_drive_returns(self):
        with tempfile.TemporaryDirectory() as root:
            store = QueueStore(root)
            row = store.add('download', {})
            store.update(row['id'], state='executando')
            dialog = CatalogDialog(None)
            dialog.archive_path = root
            tab = dialog.queue_tab
            with patch('usgs_catalogo_qgis.work_queue.atomic_json', side_effect=FileNotFoundError('Unidade removida')):
                tab.refresh()
                self.assertNotEqual(tab.root, root)
                self.assertIn('Não foi possível salvar', tab.info.text())
                self.assertEqual(store.read()[0]['state'], 'executando')
            tab.refresh()
            self.assertEqual(tab.root, root)
            self.assertEqual(store.read()[0]['state'], 'interrompida')
            dialog.close()

    def test_failed_enqueue_keeps_existing_queue_and_reports_error(self):
        with tempfile.TemporaryDirectory() as root:
            dialog = CatalogDialog(None)
            dialog.archive_path = root
            tab = dialog.queue_tab
            self.assertTrue(tab.enqueue('download', {'original': True}))
            before = tab.store().read()
            with patch('usgs_catalogo_qgis.work_queue.atomic_json', side_effect=PermissionError('Sem permissão')):
                self.assertFalse(tab.enqueue('download', {'new': True}))
            self.assertEqual(tab.store().read(), before)
            self.assertIn('Escolher pasta', tab.info.text())
            dialog.close()

    def test_folder_change_rejects_unwritable_location_and_keeps_current(self):
        with tempfile.TemporaryDirectory() as root:
            dialog = CatalogDialog(None)
            dialog.archive_path = root
            with patch('usgs_catalogo_qgis.plugin.QFileDialog.getExistingDirectory', return_value='/blocked'), \
                 patch('usgs_catalogo_qgis.plugin.writable_directory', side_effect=CatalogError('Sem permissão')):
                dialog.select_archive_folder()
            self.assertEqual(dialog.archive_path, root)
            self.assertIn('Sem permissão', dialog.archive_notice.text())
            dialog.close()

    def test_folder_change_refreshes_queue_without_moving_old_jobs(self):
        settings = QgsSettings()
        key = 'catalogo_multiespectral/acervo'
        existed, old = settings.contains(key), settings.value(key)
        try:
            with tempfile.TemporaryDirectory() as root:
                first, second = os.path.join(root, 'first'), os.path.join(root, 'second')
                dialog = CatalogDialog(None)
                dialog.archive_path = first
                self.assertTrue(dialog.queue_tab.enqueue('download', {'old': True}))
                with patch('usgs_catalogo_qgis.plugin.QFileDialog.getExistingDirectory', return_value=second):
                    dialog.select_archive_folder()
                self.assertEqual(dialog.archive_path, second)
                self.assertEqual(settings.value(key), second)
                self.assertEqual(dialog.queue_tab.rows, [])
                self.assertEqual(len(QueueStore(first).read()), 1)
                self.assertEqual(dialog.archive_tab.folder.text(), second)
                dialog.close()
        finally:
            if existed:
                settings.setValue(key, old)
            else:
                settings.remove(key)

    def test_corrupted_queue_start_is_reported_without_crashing_or_overwriting(self):
        with tempfile.TemporaryDirectory() as root:
            dialog = CatalogDialog(None)
            dialog.archive_path = root
            path = QueueStore(root).path
            with open(path, 'w', encoding='utf8') as stream:
                stream.write('{broken')
            dialog.queue_tab.start()
            self.assertIsNone(dialog.queue_tab.job)
            self.assertIn('preserve o arquivo', dialog.queue_tab.info.text())
            with open(path, encoding='utf8') as stream:
                self.assertEqual(stream.read(), '{broken')
            dialog.close()
