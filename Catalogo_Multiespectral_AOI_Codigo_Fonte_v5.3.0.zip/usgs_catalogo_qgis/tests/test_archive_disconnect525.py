# SPDX-License-Identifier: GPL-2.0-or-later
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import Mock,patch
from usgs_catalogo_qgis.simple_ui import SimpleCatalogDialog
from usgs_catalogo_qgis.plugin import Job
from usgs_catalogo_qgis.archive import LocalArchive
from usgs_catalogo_qgis.stac import CatalogError


class ArchiveDisconnectTests(unittest.TestCase):
    def test_search_callback_contains_read_and_write_errors(self):
        dialog=SimpleCatalogDialog(None)
        try:
            dialog.offline.setChecked(False)
            original=dialog.archive_path
            for error in (OSError(22,'Invalid argument'),FileNotFoundError('drive missing'),CatalogError('unreadable catalog')):
                dialog.archive=SimpleNamespace(remember_many=Mock(side_effect=error))
                dialog.got_scenes(([],{'href':'next'}))
                self.assertIn('Reconecte',dialog.info.text())
                self.assertEqual(dialog.archive_path,original)
                self.assertIsNone(dialog.next_link)
        finally:dialog.close()

    def test_search_worker_checks_archive_and_saves_before_result(self):
        with tempfile.TemporaryDirectory() as root:
            archive=LocalArchive(root,(-55,-12,-54.99,-11.99),'EPSG:4326')
            job=Job('search',search_archive=archive);events=[]
            job.result.connect(lambda value:events.append(('result',job.archive_saved)))
            job.failed.connect(lambda value:events.append(('failed',value)))
            with patch('usgs_catalogo_qgis.plugin.writable_directory',side_effect=CatalogError('unavailable')),patch('usgs_catalogo_qgis.plugin.PublicCatalog.search') as search:
                job.work();self.assertFalse(search.called)
            self.assertEqual(events[0][0],'failed')
            events.clear()
            with patch('usgs_catalogo_qgis.plugin.PublicCatalog.search',return_value=([],None)) as search:
                job.work()
                self.assertNotIn('search_archive',search.call_args.kwargs)
            self.assertEqual(events,[('result',True)])
            self.assertEqual(archive.read()['scenes'],{})
