# SPDX-License-Identifier: GPL-2.0-or-later
import os
import tempfile
import unittest
from qgis.core import QgsApplication,QgsProject,QgsRasterLayer
from qgis.PyQt.QtCore import QEventLoop,QTimer
from usgs_catalogo_qgis.plugin import CatalogDialog
from usgs_catalogo_qgis.tests.test_analysis5 import fixture
from usgs_catalogo_qgis.analysis_ui import raster_snapshot
from usgs_catalogo_qgis.stac import CatalogError


class AnalysisInterfaceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QgsApplication.instance() or QgsApplication([],False);cls.app.initQgis()
    def test_actual_qgstask_queue_classifies_imports_and_reopens_report(self):
        with tempfile.TemporaryDirectory() as root:
            payload=fixture(root);dialog=CatalogDialog(None);dialog.archive_path=root;tab=dialog.queue_tab
            tab.enqueue('classification',payload);tab.start();self.assertIsNotNone(tab.job)
            loop=QEventLoop();tab.job.done.connect(loop.quit);QTimer.singleShot(30000,loop.quit);loop.exec()
            self.assertIsNone(tab.job);row=tab.store().read()[0];self.assertEqual(row['state'],'concluida',row['message'])
            self.assertTrue(row['result']['input_checksums']);self.assertTrue(os.path.isfile(row['result']['report']))
            layers=[layer for layer in QgsProject.instance().mapLayers().values() if layer.customProperty('catalogo_multiespectral_analise','')]
            self.assertEqual(len(layers),1);self.assertEqual(layers[0].renderer().type(),'paletted')
            self.assertEqual(layers[0].customProperty('catalogo_multiespectral_data'),'2020-01-01')
            QgsProject.instance().removeMapLayer(layers[0].id());dialog.close()
    def test_drawing_defaults_and_auxiliary_layers_are_not_offered_as_inputs(self):
        dialog=CatalogDialog(None);tab=dialog.classification_tab;tab.create_samples();layer=QgsProject.instance().mapLayer(tab.samples.currentData())
        self.assertTrue(layer.isEditable());self.assertEqual(layer.defaultValueDefinition(layer.fields().indexFromName('uso')).expression(),"'treino'")
        tab.role.setCurrentIndex(1);self.assertEqual(layer.defaultValueDefinition(layer.fields().indexFromName('uso')).expression(),"'validacao'")
        layer.setCustomProperty('catalogo_layout_aux',True);dialog.cartography_tab.refresh()
        self.assertFalse(any(dialog.cartography_tab.layers.item(i).data(256)==layer.id() for i in range(dialog.cartography_tab.layers.count())))
        QgsProject.instance().removeMapLayer(layer.id());dialog.close()
    def test_uncalibrated_raster_is_not_silently_used_for_classification(self):
        with tempfile.TemporaryDirectory() as root:
            payload=fixture(root);raster=QgsRasterLayer(payload['path'],'Sem metadados','gdal')
            with self.assertRaisesRegex(CatalogError,'calibração'):raster_snapshot(raster)
            raster=None  # Release the provider before TemporaryDirectory cleanup.
    def test_layout_manager_button_routes_to_qgis(self):
        dialog=CatalogDialog(None)
        class Interface:
            calls=0
            def showLayoutManager(self):self.calls+=1
        iface=Interface();dialog.iface=iface;dialog.cartography_tab.manager();self.assertEqual(iface.calls,1);dialog.iface=None;dialog.close()
