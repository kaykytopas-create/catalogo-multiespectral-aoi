# SPDX-License-Identifier: GPL-2.0-or-later
import tempfile
import time
import unittest
from types import SimpleNamespace
from unittest.mock import Mock,patch
from qgis.core import QgsApplication
from qgis.PyQt.QtCore import QEventLoop,QTimer,QByteArray,QBuffer,QIODevice
from qgis.PyQt.QtGui import QImage
from usgs_catalogo_qgis.simple_ui import SimpleCatalogDialog
from usgs_catalogo_qgis.archive import LocalArchive
from usgs_catalogo_qgis.tasks import TaskWorker
from usgs_catalogo_qgis.tests.test_presets_quality import scene


class LifecycleTests(unittest.TestCase):
    def test_callback_failure_is_reported_without_modal_dialog(self):
        dialog=SimpleCatalogDialog(None)
        try:
            worker=SimpleNamespace(_stop=False,_detached=False)
            with patch('usgs_catalogo_qgis.plugin.QMessageBox.warning') as warning:
                dialog.deliver_result(worker,Mock(side_effect=OSError('disco indisponível')),None)
                self.assertFalse(warning.called)
                self.assertIn('disco indisponível',dialog.info.text())
            callback=Mock();worker._stop=True
            dialog.deliver_result(worker,callback,None);self.assertFalse(callback.called)
        finally:dialog.close()

    def test_close_detaches_without_waiting_and_discards_late_result(self):
        class Slow(TaskWorker):
            def work(self):
                time.sleep(.35)
                self.result.emit('late')
        dialog=SimpleCatalogDialog(None);worker=Slow();events=[]
        dialog.job=worker
        worker.result.connect(lambda value:dialog.deliver_result(worker,events.append,value))
        worker.start();start=time.monotonic();dialog.close()
        self.assertLess(time.monotonic()-start,.2)
        self.assertTrue(worker._detached);self.assertIsNone(dialog.job)
        dialog.show();self.assertFalse(dialog.tabs.isEnabled())
        loop=QEventLoop();QTimer.singleShot(700,loop.quit);loop.exec()
        self.assertEqual(events,[]);self.assertTrue(dialog.tabs.isEnabled())
        self.assertFalse(worker.isRunning());dialog.close()

    def test_search_does_not_prefetch_all_thumbnails(self):
        with tempfile.TemporaryDirectory() as root:
            dialog=SimpleCatalogDialog(None)
            try:
                dialog.archive=LocalArchive(root,(-55,-12,-54.99,-11.99),'EPSG:4326')
                item=scene();item['properties']={'datetime':'2020-01-01','eo:cloud_cover':0}
                with patch('usgs_catalogo_qgis.plugin.preview_url',return_value='https://planetarycomputer.microsoft.com/api/data/v1/test.png'),patch.object(dialog,'pump_previews'):
                    dialog.got_scenes(([item],None))
                self.assertEqual(dialog.preview_queue,[])
                self.assertIn('Selecione',dialog.table.item(0,0).text())
            finally:dialog.close()

    def test_thumbnail_cache_is_bounded_and_closed_dialog_ignores_results(self):
        dialog=SimpleCatalogDialog(None);dialog.archive=None
        try:
            data=QByteArray();buffer=QBuffer(data);buffer.open(QIODevice.OpenModeFlag.WriteOnly)
            image=QImage(4,4,QImage.Format.Format_RGB32);image.fill(0);image.save(buffer,'PNG');buffer.close()
            for n in range(24):dialog.preview_finished(bytes(data),0,str(n),dialog.preview_generation,False)
            self.assertEqual(len(dialog.preview_cache),16)
            dialog.close();dialog.preview_finished(bytes(data),0,'late',dialog.preview_generation,False)
            self.assertNotIn('late',dialog.preview_cache)
        finally:dialog.close();QgsApplication.processEvents()
