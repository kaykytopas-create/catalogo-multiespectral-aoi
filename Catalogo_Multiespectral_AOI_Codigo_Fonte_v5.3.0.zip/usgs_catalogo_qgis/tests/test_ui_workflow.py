# SPDX-License-Identifier: GPL-2.0-or-later
import os
import tempfile
import unittest
from qgis.core import QgsApplication,QgsProject,QgsVectorLayer,QgsFeature,QgsGeometry
from qgis.PyQt.QtCore import QPoint,Qt
from qgis.PyQt.QtTest import QTest
from usgs_catalogo_qgis.plugin import CatalogDialog


class InterfaceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QgsApplication.instance() or QgsApplication([],False)
        cls.app.initQgis()

    def test_separate_tabs_ready_presets_shortcut_and_single_parcel_snapshot(self):
        with tempfile.TemporaryDirectory() as root:
            project=QgsProject.instance()
            parcel=QgsVectorLayer('Polygon?crs=EPSG:4326','Imóvel sintético','memory')
            feature=QgsFeature();feature.setGeometry(QgsGeometry.fromWkt('POLYGON((-55 -12,-54.99 -12,-54.99 -11.99,-55 -11.99,-55 -12))'))
            parcel.dataProvider().addFeatures([feature]);parcel.updateExtents();project.addMapLayer(parcel)
            dialog=CatalogDialog(None);dialog.archive_path=root
            dialog.layer_box.setCurrentIndex(dialog.layer_box.findData(parcel.id()))
            dialog.current_search()
            self.assertEqual([dialog.tabs.tabText(i) for i in range(dialog.tabs.count())],
                ['Início','Imagens','PRODES','Bandas e análise','Acervo offline','Situação ambiental e fundiária','Classificação','Comparação temporal','Cartas-imagem','Fila de tarefas'])
            self.assertTrue(dialog.nasa_hls.isChecked())
            self.assertIn('hls2-l30',dialog.collections())
            self.assertIn('sentinel-2-l2a-aws',dialog.collections())
            item={'id':'TEST','collection':'landsat-c2-l2','properties':{'datetime':'2000-01-01T00:00:00Z','eo:cloud_cover':0,'platform':'landsat-5'},
                  'assets':{key:{'href':'https://test.blob.core.windows.net/data/'+key+'.tif','eo:bands':[{'name':key,'common_name':key}]} for key in ('blue','green','red','nir08','swir16','swir22')}}
            dialog.got_scenes(([item],None));dialog.table.selectRow(0)
            calls=[];dialog.import_product=lambda product:calls.append(product)
            dialog.tabs.setCurrentIndex(1);dialog.show();self.app.processEvents()
            for width,height in ((1180,850),(1024,700),(900,600)):
                dialog.resize(width,height);self.app.processEvents()
                button=dialog.import_button
                for position in (0,dialog.imagery_scroll.verticalScrollBar().maximum()):
                    dialog.imagery_scroll.verticalScrollBar().setValue(position);self.app.processEvents()
                    y=button.mapTo(dialog,QPoint(0,0)).y()
                    self.assertLessEqual(y+button.height(),dialog.height());self.assertGreaterEqual(button.height(),48)
            dialog.choose_analysis_preset('natural');self.assertEqual(calls,['rgb'])
            dialog.choose_analysis_preset('ndvi');self.assertEqual(calls,['rgb','ndvi'])
            self.assertEqual(dialog.import_button.shortcut().toString(),'Alt+I')
            dialog.activateWindow();self.app.setActiveWindow(dialog);QTest.qWait(250)
            QTest.keyClick(dialog.import_button,Qt.Key.Key_I,Qt.KeyboardModifier.AltModifier);QTest.qWait(250)
            self.assertEqual(calls,['rgb','ndvi','ndvi'])
            from osgeo import gdal,osr
            import numpy as np
            path=os.path.join(root,'bandset.tif')
            dataset=gdal.GetDriverByName('GTiff').Create(path,16,16,6,gdal.GDT_UInt16)
            sr=osr.SpatialReference();sr.ImportFromEPSG(4326)
            dataset.SetProjection(sr.ExportToWkt());dataset.SetGeoTransform((-55,.001,0,-12,0,-.001))
            for number in range(1,7):dataset.GetRasterBand(number).WriteArray(np.arange(10000,10256,dtype='uint16').reshape(16,16))
            dataset=None
            keys=['blue','green','red','nir08','swir16','swir22'];dialog.bandset_context=(item,keys)
            dialog.got_bandset(([],[],path));dialog.got_bandset(([],[],path))
            layers=[layer for layer in project.mapLayers().values() if layer.customProperty('catalogo_multiespectral_band_set','')]
            self.assertEqual(len(layers),1)
            renderer=layers[0].renderer()
            self.assertEqual((renderer.redBand(),renderer.greenBand(),renderer.blueBand()),(3,2,1))
            project.removeMapLayer(layers[0].id())
            self.assertTrue(os.path.isfile(dialog.archive.index_path))
            dialog.close();project.removeMapLayer(parcel.id())
