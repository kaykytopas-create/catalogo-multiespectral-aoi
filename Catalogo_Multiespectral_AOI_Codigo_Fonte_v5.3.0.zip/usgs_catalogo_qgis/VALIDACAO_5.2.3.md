# Validação 5.2.3 — 21/11/2026

291 testes aprovados, zero falhas, zero erros, zero ignorados.
Ambiente Windows, QGIS 3.44.7, Python 3.12 e GDAL/NumPy do QGIS.
A suíte verifica as cinco abas, navegação para os widgets originais de Situação fundiária
e Analisar PRODES, além das análises hídricas, comparação temporal, acervo, processamento,
cartas e módulos originais. As abas restauradas foram renderizadas e inspecionadas na 5.2.1; interface inalterada nesta revisão.
Flake8 7.5.0: zero apontamentos nas regras de CI do projeto: F,E711,E712,E713,E714,
E721,E722,E731,E741,E742,E743,E9. Não é uma varredura de todas as regras de estilo.
Correção E731: def no lugar de lambda atribuída; escape HTML preservado.
Correção Bandit B108: TemporaryDirectory no teste de caminhos; nenhuma supressão adicionada.
Bandit 1.9.4: zero apontamentos e zero erros na varredura recursiva de todo o plugin,
incluindo testes e ferramentas, sem excluir regras ou arquivos. Os dois B108 foram
reproduzidos no arquivo original antes da correção. A revisão do portal não foi reexecutada.
Testes executados em processo QGIS separado, com configurações de teste isoladas.
ZIPs verificados por CRC, equivalência dos arquivos do plugin e metadados de versão.
experimental=False mantido; aprovação no repositório QGIS não foi realizada.
Não houve nova consulta online completa a todos os serviços fundiários/PRODES nesta revisão;
a restauração usa as implementações originais. Acesso depende dos serviços externos.
O teste online JRC foi realizado na versão 5.2.0, cujo downloader não foi alterado aqui.
O projeto aberto e a instalação do usuário não foram substituídos. Faixa declarada QGIS
3.40–3.99, execução efetiva em 3.44.7. Sem validação temática em campo ou certificação jurídica.
