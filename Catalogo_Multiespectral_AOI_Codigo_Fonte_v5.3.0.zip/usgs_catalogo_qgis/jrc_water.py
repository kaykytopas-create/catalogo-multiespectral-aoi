# SPDX-License-Identifier: GPL-2.0-or-later
"""JRC GSW v1.5 public aggregate products, separate from dated spectral scenes."""
import hashlib
import json
import math
import os
from .stac import CatalogError,bbox
from .storage import atomic_json,AssetIndex,path_lock
from .tasks import TaskWorker

ROOT='https://s3.waw4-1.cloudferro.com/swift/v1/global-surface-water/download2024/Aggregated/VER1-5/'
PRODUCTS={'occurrence':'Ocorrência de água · 1984–2024 (%)','recurrence':'Recorrência de água · 1984–2024 (%)','extent':'Extensão máxima histórica de água · 1984–2024'}


def tile_urls(rect,product):
    if product not in PRODUCTS:raise CatalogError('Produto JRC não reconhecido.')
    west,south,east,north=bbox(rect)
    if south < -60 or north > 80:raise CatalogError('Área fora da grade de distribuição JRC utilizada.')
    urls=[]
    for x in range(math.floor(west/10)*10,math.ceil(east/10)*10,10):
        for y in range(math.floor(south/10)*10+10,math.ceil(north/10)*10+1,10):
            lon=str(abs(x))+('W' if x<0 else 'E');lat=str(abs(y))+('S' if y<0 else 'N')
            urls.append(ROOT+product+'/'+product+'_'+lon+'_'+lat+'_v1_5_2024.tif')
    if len(urls)>4:raise CatalogError('Área muito grande para este download. Selecione um limite menor.')
    return urls


def download(root,rect,product,offline=False,cancelled=lambda:False,progress=lambda x:None):
    from osgeo import gdal
    urls=tile_urls(rect,product)
    # Resolution is the native 1 arcsecond; no artificial spatial refinement.
    if (rect[2]-rect[0])*3600*(rect[3]-rect[1])*3600>20000000:
        raise CatalogError('Recorte acima de 20 milhões de pixels; reduza a área.')
    identity=hashlib.sha256(json.dumps([rect,product,'v1.5-2024']).encode()).hexdigest()[:20]
    folder=os.path.join(root,'hidrologia','JRC_GSW_1_5',identity);os.makedirs(folder,exist_ok=True)
    path=os.path.join(folder,product+'.tif')
    with path_lock(path,cancelled):
        if os.path.isfile(path):
            from .stac import validate_cached_raster
            validate_cached_raster(path,gdal,cancelled)
        else:
            if offline:raise CatalogError('Este recorte JRC ainda não está no acervo. Desmarque o modo offline para baixá-lo.')
            progress('Lendo recorte JRC GSW v1.5; aguarde…')
            partial=path+'.part.tif';ds=None;sources=[]
            options={'GDAL_HTTP_CONNECTTIMEOUT':'15','GDAL_HTTP_TIMEOUT':'45','GDAL_HTTP_MAX_RETRY':'1','GDAL_DISABLE_READDIR_ON_OPEN':'EMPTY_DIR','CPL_VSIL_CURL_ALLOWED_EXTENSIONS':'.tif'}
            previous={k:gdal.GetThreadLocalConfigOption(k) for k in options}
            try:
                for k,v in options.items():gdal.SetThreadLocalConfigOption(k,v)
                for url in urls:
                    if cancelled():raise CatalogError('Download JRC cancelado.')
                    source=gdal.Open('/vsicurl/'+url)
                    if source is None:raise CatalogError('Uma das folhas JRC não respondeu; recorte incompleto não será salvo.')
                    sources.append(source)
                ds=gdal.Warp(partial,sources,format='GTiff',dstSRS='EPSG:4326',outputBounds=rect,
                             xRes=1/3600,yRes=1/3600,resampleAlg='near',srcNodata=255,dstNodata=255,outputType=gdal.GDT_Byte,
                             creationOptions=['TILED=YES','COMPRESS=DEFLATE'],callback=lambda *args:0 if cancelled() else 1)
                if cancelled():raise CatalogError('Download JRC cancelado.')
                if ds is None:raise CatalogError('A fonte JRC não respondeu ou não cobre o recorte. Nenhum resultado completo foi salvo.')
                import numpy as np
                sample=ds.GetRasterBand(1).ReadAsArray(buf_xsize=min(512,ds.RasterXSize),buf_ysize=min(512,ds.RasterYSize))
                if not np.any(sample!=255):raise CatalogError('Sem observações JRC válidas nesta área.')
                ds.SetMetadata({'SOURCE':'EC JRC/Google','VERSION':'1.5','PERIOD':'1984-2024','PRODUCT':product,'UNITS':'percent' if product!='extent' else '0=not detected;1=detected;255=nodata'})
                ds=None;sources=[];source=None
                from .stac import validate_raster
                validate_raster(partial,gdal,cancelled)
                os.replace(partial,path)
            finally:
                ds=None
                for k,v in previous.items():gdal.SetThreadLocalConfigOption(k,v)
                if os.path.isfile(partial):os.remove(partial)
        record={'path':path,'product':product,'name':'JRC · '+PRODUCTS[product],'period':'1984–2024','source':'EC JRC/Google','urls':urls,
                'note':'Produto histórico agregado; não é uma imagem de 2024 nem prova de água presente hoje. Resolução aproximada de 30 m.'}
        atomic_json(path+'.source.json',record)
        AssetIndex(root).register(path,'hidrologia',identity,product,{'id':record['name'],'sources':['EC JRC/Google'],'period':record['period']},cancelled)
        return record


class JrcWorker(TaskWorker):
    def __init__(self,root,rect,product,offline=False):
        super().__init__(description='Catálogo · água histórica JRC')
        self.args=(root,rect,product,offline)
    def work(self):self.result.emit(download(*self.args,cancelled=lambda:self.stopping,progress=self.status.emit))


def style(layer,product):
    from qgis.core import QgsColorRampShader,QgsRasterShader,QgsSingleBandPseudoColorRenderer
    from qgis.PyQt.QtGui import QColor
    maximum=1 if product=='extent' else 100
    ramp=QgsColorRampShader(0,maximum);ramp.setColorRampType(QgsColorRampShader.Type.Discrete if product=='extent' else QgsColorRampShader.Type.Interpolated)
    ramp.setColorRampItemList([QgsColorRampShader.ColorRampItem(0,QColor('#eeeeee'),'0'),QgsColorRampShader.ColorRampItem(maximum,QColor('#0066cc'),str(maximum)+(' · água detectada' if product=='extent' else '%'))])
    shader=QgsRasterShader(0,maximum);shader.setRasterShaderFunction(ramp)
    layer.setRenderer(QgsSingleBandPseudoColorRenderer(layer.dataProvider(),1,shader))
