from .spectral import INDEX_PRODUCTS
# SPDX-License-Identifier: GPL-2.0-or-later
"""Guided ROI training, persisted queue, independent validation and time series."""
import json
import os
from qgis.PyQt.QtCore import Qt, QUrl, QVariant
from qgis.PyQt.QtGui import QColor, QDesktopServices
from qgis.PyQt.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QFormLayout,QLabel,QComboBox,QPushButton,
    QTableWidget,QTableWidgetItem,QHeaderView,QAbstractItemView,QMessageBox,QTextBrowser,QFileDialog)
from qgis.core import (QgsProject,QgsRasterLayer,QgsVectorLayer,QgsField,QgsDefaultValue,QgsGeometry,
    QgsCoordinateReferenceSystem,QgsCoordinateTransform,QgsPalettedRasterRenderer,QgsVectorFileWriter)
from .parcel import ParcelPicker
from .stac import CatalogError
from .classification import CLASSES
from .work_queue import QueueStore,QueueWorker
from .preflight import validate_samples, validate_dates
from .setup_ui import show_page


def raster_snapshot(layer):
    if not isinstance(layer,QgsRasterLayer) or not layer.isValid() or not os.path.isfile(layer.source()):raise CatalogError('Selecione um raster local do catálogo, preferencialmente Band Set completo.')
    raw=layer.customProperty('catalogo_multiespectral_espectral','')
    if not raw:raise CatalogError('Raster sem calibração arquivada. Reimporte um Band Set ou composição pelo Catálogo atualizado.')
    metadata=json.loads(str(raw));bands=metadata['keys']
    if layer.bandCount()!=len(bands):raise CatalogError('Metadados não correspondem ao raster.')
    if not metadata.get('qa_path') or not os.path.isfile(metadata['qa_path']):raise CatalogError('Máscara de qualidade ausente. Reimporte o Band Set com conexão para baixar QA.')
    return {'path':layer.source(),'bands':bands,'coefficients':metadata['coefficients'],
            'qa_path':metadata['qa_path'],'qa_kind':metadata['qa_kind'],'saturation_path':metadata.get('saturation_path',''),'resolution':metadata['native_resolution'],
            'date':str(layer.customProperty('catalogo_multiespectral_data','')),
            'source_info':{'name':layer.name(),'scene':metadata['scene_id'],'collection':metadata['collection'],
                           'sources':metadata.get('sources',[]),'date':str(layer.customProperty('catalogo_multiespectral_data','')),'bands':bands,'coefficients':metadata['coefficients']}}


def region_payload(layer):
    if not isinstance(layer,QgsVectorLayer):raise CatalogError('Crie ou selecione uma camada de amostras.')
    if any(layer.fields().indexFromName(f)<0 for f in ('classe','uso')):raise CatalogError('Amostras exigem campos classe (1 a 5) e uso (treino ou validacao).')
    result=[];transform=QgsCoordinateTransform(layer.crs(),QgsCoordinateReferenceSystem('EPSG:4326'),QgsProject.instance())
    for feature in layer.getFeatures():
        geom=QgsGeometry(feature.geometry())
        if geom.isEmpty() or not geom.isGeosValid():raise CatalogError('Amostra vazia ou inválida.')
        geom.transform(transform);c=int(feature['classe']);role=str(feature['uso'])
        if c not in CLASSES or role not in ('treino','validacao'):raise CatalogError('Classe/uso inválido nas amostras.')
        result.append({'class':c,'role':role,'geometry':geom.asWkt()})
    return result


class QueueTab(QWidget):
    def __init__(self,owner):
        super().__init__(owner);self.owner=owner;self.job=None
        layout=QVBoxLayout(self);note=QLabel('Tarefas ficam salvas no acervo. Retomar repete a etapa interrompida, reutiliza downloads válidos e verifica se as entradas mudaram. O tempo exibido é medido, sem promessa de duração.');note.setWordWrap(True);layout.addWidget(note)
        self.table=QTableWidget(0,4);self.table.setHorizontalHeaderLabels(['Tarefa','Estado','Andamento','Tempo (s)']);self.table.horizontalHeader().setSectionResizeMode(2,QHeaderView.ResizeMode.Stretch);self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows);self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers);layout.addWidget(self.table)
        row=QHBoxLayout()
        for text,callback in [('Atualizar',self.refresh),('Executar pendentes',self.start),('Retomar selecionada',self.retry),('Cancelar execução',self.cancel),('Abrir resultado',self.open_result)]:
            button=QPushButton(text);button.clicked.connect(callback);row.addWidget(button)
        layout.addLayout(row);self.info=QLabel();self.info.setWordWrap(True);layout.addWidget(self.info)
        self.root=None;self.rows=[];self.refresh()
    def store(self):
        store=QueueStore(self.owner.archive_path)
        if self.root!=store.root:
            store.recover();self.root=store.root
        return store
    def refresh(self):
        old=self.table.currentRow();identity=self.rows[old]['id'] if 0<=old<len(self.rows) else None
        try:self.rows=self.store().read()
        except (CatalogError,OSError) as exc:self.rows=[];self.info.setText(str(exc))
        allowed=getattr(self.owner,'allowed_queue_actions',None)
        if allowed is not None:self.rows=[row for row in self.rows if row['action'] in allowed]
        self.table.setRowCount(len(self.rows))
        for i,row in enumerate(self.rows):
            for j,text in enumerate((row['action']+' · '+row['id'][:8],row['state'],row['message'],str(row.get('elapsed_seconds','')))):self.table.setItem(i,j,QTableWidgetItem(text))
        if self.rows:self.table.selectRow(next((i for i,row in enumerate(self.rows) if row['id']==identity),len(self.rows)-1))
        for i,row in enumerate(self.rows):
            for j in range(4):self.table.item(i,j).setToolTip(row.get('message',''))
    def enqueue(self,action,payload):
        if hasattr(self.owner,'show_queue'):self.owner.show_queue()
        else:self.owner.tabs.setCurrentWidget(self)
        try:
            self.store().add(action,payload);self.refresh();self.info.setText('Tarefa salva. Use Executar pendentes; acompanhe e cancele nesta aba.')
            return True
        except (CatalogError,OSError) as exc:self.info.setText(str(exc));return False
    def start(self):
        if self.job:return
        try:
            store=self.store()
            allowed=getattr(self.owner,'allowed_queue_actions',None)
            if not any(row['state']=='pendente' and (allowed is None or row['action'] in allowed) for row in store.read()):self.info.setText('Nenhuma análise pendente nesta pasta de acervo.');return
            self.job=QueueWorker(store,allowed);self.job.status.connect(self.status);self.job.result.connect(self.completed);self.job.done.connect(self.finished);self.job.failed.connect(self.status);self.job.start()
        except (CatalogError,OSError) as exc:self.job=None;self.info.setText(str(exc))
    def status(self,message):self.info.setText(message);self.refresh()
    def retry(self):
        if self.job:return
        i=self.table.currentRow()
        if i<0:return
        if self.rows[i]['state']=='concluida':self.info.setText('Tarefa concluída. Crie uma nova para repetir sem substituir o histórico.');return
        if self.rows[i]['action']=='classification' and self.rows[i]['state']=='falha':
            try:validate_samples(self.rows[i]['payload'].get('samples',[]))
            except CatalogError as exc:
                self.info.setText(str(exc)+'\nA tarefa guarda as amostras antigas. Corrija na aba Classificação e crie uma nova tarefa.');return
        try:self.store().update(self.rows[i]['id'],state='pendente',message='Aguardando retomada');self.refresh();self.start()
        except (CatalogError,OSError) as exc:self.info.setText(str(exc))
    def cancel(self):
        if self.job:self.job.cancel()
    def completed(self,result):
        self.refresh()
        if result['type']=='queue_image':
            from .prodes_auto import scene_metadata
            record=result['result'];item=result['item'];layer=QgsRasterLayer(record['path'],record['date']+' · '+result['preset'],'gdal')
            if result['preset'] in INDEX_PRODUCTS:self.owner.configure_ndvi(layer)
            else:self.owner.configure_rgb(layer,False,item,tuple(record['bands']))
            layer.setCustomProperty('catalogo_multiespectral_data',record['date'])
            layer.setCustomProperty('catalogo_multiespectral_bandas',','.join(record['bands']))
            if result['preset'] not in INDEX_PRODUCTS:layer.setCustomProperty('catalogo_multiespectral_espectral',json.dumps(scene_metadata(item,record['bands'],os.path.dirname(record['path']))))
            if layer.isValid() and not any(isinstance(existing,QgsRasterLayer) and existing.source()==layer.source() for existing in QgsProject.instance().mapLayers().values()):QgsProject.instance().addMapLayer(layer)
            return
        if result['type']=='download':self.info.setText('Lote concluído: {} cenas preparadas. Anos não atendidos: {}. Consulte Imagens/Acervo offline.'.format(len(result.get('scenes',[])),result.get('missing_years',[])));return
        layer=QgsRasterLayer(result['path'],'Classificação RF' if result['type']=='classification' else 'Variação NDVI · datas reais','gdal')
        if result['type']=='classification':
            palette=([QgsPalettedRasterRenderer.Class(0,QColor('#aaaaaa'),'Indeterminado')] if result.get('indeterminate_ha',0)>0 else [])+[QgsPalettedRasterRenderer.Class(c,QColor(color),name) for c,(name,color) in CLASSES.items() if result['areas_ha'].get(str(c),0)>0];layer.setRenderer(QgsPalettedRasterRenderer(layer.dataProvider(),1,palette))
        else:
            from .spectral import style_index
            style_index(layer,result.get('index','ndvi'),difference=result['type']!='spectral')
            layer.setName(('Índice ' if result['type']=='spectral' else 'Variação ')+result.get('index','ndvi').upper()+' · área selecionada')
        if result['type']=='classification':
            layer.setCustomProperty('catalogo_multiespectral_data',result['source'].get('date',''))
            layer.setCustomProperty('catalogo_multiespectral_bandas','Classificação RF · '+','.join(result['bands']))
        layer.setCustomProperty('catalogo_multiespectral_analise',result['report']);layer.setCustomProperty('catalogo_multiespectral_datas',json.dumps(result.get('dates',[])))
        if result.get('index'):
            dates=result.get('dates',[])
            layer.setCustomProperty('catalogo_multiespectral_periodo',' → '.join(dict.fromkeys([dates[0],dates[-1]])) if dates else '')
            layer.setCustomProperty('catalogo_multiespectral_bandas',result['index'].upper())
        if layer.isValid():QgsProject.instance().addMapLayer(layer);layer.saveNamedStyle(result['path']+'.qml')
        self.info.setText('Resultado adicionado ao QGIS. Abra o relatório na tarefa selecionada para conferir métricas, áreas e limitações.')
    def finished(self):self.job=None;self.refresh()
    def open_result(self):
        i=self.table.currentRow()
        if i>=0:
            path=self.rows[i].get('result',{}).get('report')
            if path and os.path.isfile(path):QDesktopServices.openUrl(QUrl.fromLocalFile(path))


class ClassificationTab(QWidget):
    def __init__(self,owner):
        super().__init__(owner);self.owner=owner
        layout=QVBoxLayout(self);intro=QLabel('1. Escolha um Band Set. 2. Desenhe exemplos de cada cobertura, separando treino e validação. 3. Classifique e confira o relatório. As classes são coberturas espectrais; não definem consolidação legal.');intro.setWordWrap(True);layout.addWidget(intro)
        self.parcel=ParcelPicker(owner.iface,owner.layer_box,self);layout.addWidget(self.parcel)
        form=QFormLayout();self.raster=QComboBox();self.samples=QComboBox();self.category=QComboBox();self.role=QComboBox()
        for c,(name,_) in CLASSES.items():self.category.addItem(name,c)
        self.role.addItem('Treinamento','treino');self.role.addItem('Validação independente','validacao')
        for title,widget in [('Imagem / Band Set',self.raster),('Camada de amostras',self.samples),('Classe da próxima amostra',self.category),('Finalidade da próxima amostra',self.role)]:form.addRow(title,widget)
        layout.addLayout(form);row=QHBoxLayout()
        for text,callback in [('Atualizar camadas',self.refresh),('Criar amostras',self.create_samples),('Carregar amostras',self.load_samples),('Desenhar amostra',self.draw),('Salvar amostras no acervo',self.save_samples)]:
            button=QPushButton(text);button.clicked.connect(callback);row.addWidget(button)
        layout.addLayout(row);self.info=QLabel('Exija ao menos duas classes e polígonos de treino e validação para cada classe. Amostras não podem se sobrepor.');self.info.setWordWrap(True);layout.addWidget(self.info)
        run=QPushButton('Classificar imóvel · Random Forest e validação');run.setMinimumHeight(44);run.clicked.connect(self.run);layout.addWidget(run);layout.addStretch();self.refresh()
        self.category.currentIndexChanged.connect(self.defaults);self.role.currentIndexChanged.connect(self.defaults)
        row=QHBoxLayout()
        for title,callback in [('Conferir amostras',self.check_samples),('Preparar Band Set',lambda:show_page(self.owner,self.owner.analysis_scroll))]:
            button=QPushButton(title);button.clicked.connect(callback);row.addWidget(button)
        layout.insertLayout(1,row)
    def refresh(self):
        for box,kind in ((self.raster,QgsRasterLayer),(self.samples,QgsVectorLayer)):
            current=box.currentData();box.clear()
            for layer in QgsProject.instance().mapLayers().values():
                if layer.customProperty('catalogo_layout_aux',False):continue
                if isinstance(layer,kind) and layer.isValid() and (kind!=QgsRasterLayer or layer.bandCount()>=3) and (kind!=QgsVectorLayer or layer.fields().indexFromName('classe')>=0):box.addItem(layer.name(),layer.id())
            index=box.findData(current)
            if index>=0:box.setCurrentIndex(index)
        self.parcel.refresh()
    def load_samples(self):
        path,_=QFileDialog.getOpenFileName(self,'Amostras de treino e validação','','Vetores (*.gpkg *.shp *.geojson)')
        if not path:return
        try:
            layer=QgsVectorLayer(path,os.path.basename(path),'ogr');region_payload(layer);QgsProject.instance().addMapLayer(layer);self.refresh();self.samples.setCurrentIndex(self.samples.findData(layer.id()))
        except Exception as exc:self.error(exc)
    def check_samples(self):
        try:
            counts=validate_samples(region_payload(QgsProject.instance().mapLayer(self.samples.currentData())))
            self.info.setText('\n'.join('{}: {} polígono(s) de treino; {} de validação.'.format(CLASSES[c][0],v['treino'],v['validacao']) for c,v in sorted(counts.items()))+'\nEstrutura conferida. A execução verificará ao menos 10 pixels válidos de treino e 5 de validação por classe.')
        except Exception as exc:self.info.setText(str(exc))
    def create_samples(self):
        layer=QgsVectorLayer('Polygon?crs=EPSG:4326','Amostras · treino e validação','memory');layer.dataProvider().addAttributes([QgsField('classe',QVariant.Int),QgsField('nome',QVariant.String),QgsField('uso',QVariant.String)]);layer.updateFields();QgsProject.instance().addMapLayer(layer);layer.startEditing();self.refresh();self.samples.setCurrentIndex(self.samples.findData(layer.id()));self.defaults()
    def defaults(self):
        layer=QgsProject.instance().mapLayer(self.samples.currentData())
        if not layer:return
        values={'classe':str(self.category.currentData()),'nome':"'"+self.category.currentText().replace("'","''")+"'",'uso':"'"+str(self.role.currentData())+"'"}
        for field,value in values.items():
            index=layer.fields().indexFromName(field)
            if index>=0:layer.setDefaultValueDefinition(index,QgsDefaultValue(value))
    def draw(self):
        layer=QgsProject.instance().mapLayer(self.samples.currentData())
        if not layer:self.create_samples();layer=QgsProject.instance().mapLayer(self.samples.currentData())
        self.defaults()
        if self.owner.iface:
            layer.startEditing();self.owner.iface.setActiveLayer(layer);self.owner.iface.actionAddFeature().trigger();self.owner.hide()
        self.info.setText('Desenhe o polígono no mapa e finalize com o botão direito. Reabra o plugin para alterar classe/finalidade. As próximas amostras recebem os valores escolhidos.')
    def save_samples(self):
        try:
            layer=QgsProject.instance().mapLayer(self.samples.currentData());region_payload(layer)
            import uuid
            folder=os.path.join(self.owner.archive_path,'amostras');os.makedirs(folder,exist_ok=True);path=os.path.join(folder,'amostras_'+uuid.uuid4().hex[:10]+'.gpkg')
            options=QgsVectorFileWriter.SaveVectorOptions();options.driverName='GPKG'
            result=QgsVectorFileWriter.writeAsVectorFormatV3(layer,path,QgsProject.instance().transformContext(),options)
            if result[0]!=QgsVectorFileWriter.WriterError.NoError:raise CatalogError(str(result))
            self.info.setText('Amostras salvas: '+path)
        except Exception as exc:self.error(exc)
    def run(self):
        try:
            parcel=self.parcel.resolve();raster=raster_snapshot(QgsProject.instance().mapLayer(self.raster.currentData()))
            samples=region_payload(QgsProject.instance().mapLayer(self.samples.currentData()))
            validate_samples(samples)
            preferred={'blue','green','red','nir08','swir16','swir22','B02','B03','B04','B08','B11','B12'}
            numbers=[i for i,key in enumerate(raster['bands']) if key in preferred]
            if len(numbers)<3:raise CatalogError('Use um Band Set com pelo menos três bandas refletivas reconhecidas. Abra Bandas e análise para prepará-lo.')
            raster['band_numbers']=[i+1 for i in numbers]
            raster['coefficients']=[raster['coefficients'][i] for i in numbers]
            raster['bands']=[raster['bands'][i] for i in numbers]
            payload=dict(raster,geometry=parcel.geometry_wkt,rect=list(parcel.rect),samples=samples)
            self.owner.queue_tab.enqueue('classification',payload)
        except Exception as exc:self.error(exc)
    def error(self,exc):self.info.setText(str(exc));QMessageBox.warning(self,'Classificação',str(exc))


class TemporalTab(QWidget):
    def __init__(self,owner):
        super().__init__(owner);self.owner=owner
        layout=QVBoxLayout(self);note=QLabel('Selecione duas ou mais imagens reais. Datas ausentes podem ser informadas na tabela (AAAA-MM-DD). O sistema compara somente os pixels válidos comuns e não reconstrói nuvens.');note.setWordWrap(True);layout.addWidget(note)
        self.parcel=ParcelPicker(owner.iface,owner.layer_box,self);layout.addWidget(self.parcel)
        self.table=QTableWidget(0,2);self.table.setHorizontalHeaderLabels(['Data · AAAA-MM-DD','Imagem / Band Set']);self.table.horizontalHeader().setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch);self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows);self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection);layout.addWidget(self.table)
        row=QHBoxLayout();refresh=QPushButton('Atualizar imagens');refresh.clicked.connect(self.refresh);run=QPushButton('Comparar datas selecionadas · NDVI/NBR');run.clicked.connect(self.run);row.addWidget(refresh);row.addWidget(run);layout.addLayout(row);self.info=QTextBrowser();self.info.setMaximumHeight(100);self.info.setText('Saída: diferenças NDVI/NBR, médias por data, área comum válida e relatório. Queda de NDVI é um indicador exploratório, não prova da causa da mudança.');layout.addWidget(self.info)
        prepare=QPushButton('Preparar Band Sets em Bandas e análise');prepare.clicked.connect(lambda:show_page(self.owner,self.owner.analysis_scroll));layout.addWidget(prepare);self.refresh()
    def refresh(self):
        self.layers=[layer for layer in QgsProject.instance().mapLayers().values() if isinstance(layer,QgsRasterLayer) and layer.bandCount()>=3 and not layer.customProperty('catalogo_layout_aux',False)];self.table.setRowCount(len(self.layers))
        for i,layer in enumerate(self.layers):
            self.table.setItem(i,0,QTableWidgetItem(str(layer.customProperty('catalogo_multiespectral_data',''))));item=QTableWidgetItem(layer.name());item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable);self.table.setItem(i,1,item)
    def run(self):
        try:
            parcel=self.parcel.resolve();images=[]
            rows=sorted({index.row() for index in self.table.selectedIndexes()})
            validate_dates([{'date':self.table.item(i,0).text().strip()} for i in rows])
            for i in sorted({index.row() for index in self.table.selectedIndexes()}):
                value=raster_snapshot(self.layers[i]);actual=value['date'];value['date']=self.table.item(i,0).text().strip();value['source_info']['date']=value['date'];value['source_info']['date_origin']='metadados do catálogo' if value['date']==actual else 'informada pelo operador';bands=value['bands']
                def find(keys):
                    for key in keys:
                        if key in bands:return bands.index(key)+1
                    raise CatalogError('Use Band Set com vermelho, NIR e SWIR2 para comparar NDVI e NBR.')
                value['index_bands']={'nir':find(('nir08','B08')),'red':find(('red','B04')),'swir':find(('swir22','B12'))};images.append(value)
            images.sort(key=lambda v:v['date']);self.owner.queue_tab.enqueue('temporal',{'images':images,'geometry':parcel.geometry_wkt,'rect':list(parcel.rect),'threshold':.2})
        except Exception as exc:self.info.setText(str(exc));QMessageBox.warning(self,'Comparação temporal',str(exc))
