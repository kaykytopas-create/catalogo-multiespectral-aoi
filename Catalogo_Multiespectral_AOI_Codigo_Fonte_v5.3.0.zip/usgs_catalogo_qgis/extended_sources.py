# SPDX-License-Identifier: GPL-2.0-or-later
"""Typed public sources: reflectance, annual classes, thermal and discovery-only."""
import copy
from datetime import date, datetime, timedelta, timezone
import json
import math
import os
import re
from urllib.parse import urlencode, urlparse, quote
from .stac import CatalogError, bbox, context_bbox, validate_cached_raster, validate_raster
from .public_http import request, PublicHttpError
from .storage import atomic_json, path_lock, receipt

MAPBIOMAS_PAGE = 'https://brasil.mapbiomas.org/iniciativas-e-produtos/cobertura-e-uso-da-terra/cobertura-30m/cobertura/'
MAPBIOMAS_BASE = 'https://storage.googleapis.com/mapbiomas-public/initiatives/brasil/collection11/lulc/coverage/brazil_coverage/brazil_coverage-col11_{}.tif'
SOURCE_INFO = {
    'modis': ('MODIS · reflectância de superfície', 'Composto de 8 dias, 500 m. Apoio regional; não substitui Landsat/Sentinel para vetorização do imóvel.'),
    'mapbiomas': ('MapBiomas · uso e cobertura anual', 'Coleção 11 · 1985–2025 · classes de 30 m. Um mapa por ano; sem DOS1, NDVI ou interpolação de classes.'),
    'goes': ('GOES-East · térmico C13', 'Uma observação por dia às 15 h UTC, ~2 km no nadir. Apoio meteorológico; sem RGB natural ou NDVI. Máximo de 31 dias por busca.'),
    'aster': ('ASTER · catálogo NASA', 'Consulta pública AST_L1T V004. O download de radiância HDF exige acesso externo Earthdata; não é importado como reflectância corrigida.'),
}


def normalize_modis(item):
    item = copy.deepcopy(item)
    props = item.setdefault('properties', {})
    props['datetime'] = props.get('datetime') or props.get('start_datetime')
    props.setdefault('platform', 'aqua' if str(item.get('id','')).startswith('MYD') else 'terra')
    item['catalog:kind'] = 'reflectance'
    item['catalog:sources'] = ['NASA MODIS / Microsoft Planetary Computer']
    mapping = {'sur_refl_b01': ('red', .645), 'sur_refl_b02': ('nir08', .8585),
               'sur_refl_b03': ('blue', .469), 'sur_refl_b04': ('green', .555),
               'sur_refl_b05': ('nir12', 1.24), 'sur_refl_b06': ('swir16', 1.64),
               'sur_refl_b07': ('swir22', 2.13)}
    assets = item.setdefault('assets', {})
    for source, (key, wave) in mapping.items():
        if source in assets:
            asset = assets.pop(source)
            asset['eo:bands'] = [{'name': source, 'common_name': key, 'center_wavelength': wave}]
            asset['raster:bands'] = [{'scale': .0001, 'offset': 0, 'nodata': -28672, 'spatial_resolution': 500}]
            assets[key] = asset
    return item


def annual_items(rect, start, end):
    bbox(rect)
    # Brazil bounding coverage only; pixels outside Brazil remain NoData.
    if rect[2] <= -74 or rect[0] >= -34 or rect[3] <= -34 or rect[1] >= 6:
        return [], ['Área fora da abrangência brasileira do MapBiomas.']
    first, last = max(1985, int(start[:4])), min(2025, int(end[:4]))
    warnings = ['Disponibilidade remota não confirmada: o portal MapBiomas informou suspensão temporária dos downloads. Use o acervo ou GeoTIFF exportado via GEE quando o acesso público estiver bloqueado.']
    if int(start[:4]) < 1985 or int(end[:4]) > 2025:
        warnings.append('MapBiomas coleção 11: série publicada 1985–2025; anos externos não são inventados.')
    items = []
    for year in range(first, last+1):
        items.append({'type': 'Feature', 'id': 'mapbiomas-col11-'+str(year),
            'collection': 'mapbiomas-brasil-col11', 'bbox': [-74,-34,-34,6],
            'properties': {'datetime': str(year)+'-01-01T00:00:00Z', 'platform': 'MapBiomas', 'year': year},
            'catalog:kind': 'categorical', 'catalog:sources': ['MapBiomas Brasil · coleção 11'],
            'catalog:availability': 'Endpoint anual a verificar no download',
            'assets': {'classes': {'href': MAPBIOMAS_BASE.format(year), 'roles': ['data'],
                'raster:bands': [{'nodata': 0, 'spatial_resolution': 30}]}}})
    return items, warnings


def s3_listing(data):
    from qgis.PyQt.QtCore import QXmlStreamReader
    if b'<!DOCTYPE' in data.upper() or b'<!ENTITY' in data.upper():
        raise CatalogError('Listagem XML com declarações externas não é aceita.')
    reader=QXmlStreamReader(data)
    keys,truncated=[],False
    while not reader.atEnd():
        reader.readNext()
        if reader.isStartElement():
            name=str(reader.name())
            if name=='Key':keys.append(str(reader.readElementText()))
            elif name=='IsTruncated':truncated=str(reader.readElementText()).lower()=='true'
    if reader.hasError():
        raise CatalogError('Listagem GOES inválida: '+reader.errorString())
    return keys,truncated


def validate_dates(start, end):
    first, last = date.fromisoformat(start), date.fromisoformat(end)
    if first > last:
        raise CatalogError('A data inicial deve ser anterior à final.')
    return first, last


class ExtendedCatalog:
    def __init__(self, cancelled=lambda: False, fetch=None):
        self.cancelled = cancelled
        self.fetch = fetch or (lambda url: request(url, cancelled=cancelled))
        self._client = None

    def spectral_client(self):
        if self._client is None:
            from .public_sources import MultiCatalog
            self._client = MultiCatalog(self.cancelled)
        return self._client

    def search(self, source, rect, start, end, cursor=None):
        first, last = validate_dates(start, end)
        bbox(rect)
        if source == 'mapbiomas':
            items, warnings = annual_items(rect, start, end)
            return {'items': items, 'cursor': None, 'warnings': warnings}
        if source == 'modis':
            page, token = self.spectral_client().search(['modis-09A1-061'], rect, start, end, cursor)
            return {'items': page, 'cursor': token, 'warnings': list(getattr(page, 'warnings', [])) + ['MODIS é composto de 8 dias; percentual de nuvens de uma cena não se aplica. Verifique os pixels e QA; resolução de 500 m.']}
        if source == 'aster':
            page = int(cursor or 1)
            if page < 1 or page > 100:
                raise CatalogError('Paginação ASTER fora do limite.')
            query = {'short_name': 'AST_L1T', 'version': '004', 'bounding_box': ','.join(map(str,rect)),
                     'temporal': start+'T00:00:00Z,'+end+'T23:59:59Z', 'page_size': 100,
                     'page_num': page, 'sort_key': '-start_date'}
            raw = json.loads(self.fetch('https://cmr.earthdata.nasa.gov/search/granules.json?'+urlencode(query)))
            entries = raw.get('feed', {}).get('entry', [])
            items = []
            for entry in entries:
                links = [v['href'] for v in entry.get('links', []) if v.get('href','').startswith('https://') and not v.get('inherited')]
                items.append({'id': entry.get('producer_granule_id') or entry.get('id'), 'collection': 'aster-l1t-004',
                    'properties': {'datetime': entry.get('time_start'), 'platform': 'ASTER Terra'},
                    'catalog:kind': 'radiance', 'catalog:requires_auth': True,
                    'catalog:sources': ['NASA CMR / LP DAAC'], 'catalog:links': links,
                    'catalog:portal': 'https://search.earthdata.nasa.gov/search?q=AST_L1T', 'assets': {}})
            return {'items': items, 'cursor': page+1 if len(entries)==100 else None,
                    'warnings': ['ASTER: consulta pública; arquivos HDF exigem Earthdata. Use Abrir portal oficial. Nenhum DOS1 aplicado sem calibração completa.']}
        if source != 'goes':
            raise CatalogError('Fonte não reconhecida.')
        if (last-first).days > 30:
            raise CatalogError('GOES: consulte até 31 dias por vez (uma observação diária às 15 h UTC).')
        lon, lat = (rect[0]+rect[2])/2, (rect[1]+rect[3])/2
        if math.cos(math.radians(lat))*math.cos(math.radians(lon+75.2)) <= .151:
            return {'items': [], 'cursor': None, 'warnings': ['Área fora do disco visível do GOES-East.']}
        items, warnings, day = [], [], first
        while day <= last:
            if self.cancelled():
                raise CatalogError('Consulta cancelada.')
            satellite = '19' if day >= date(2025,4,4) else '16'
            prefix = 'ABI-L2-CMIPF/{}/{:03d}/15/'.format(day.year,day.timetuple().tm_yday)
            url = 'https://noaa-goes'+satellite+'.s3.amazonaws.com/?'+urlencode({'list-type': 2, 'prefix': prefix, 'max-keys': 1000})
            try:
                data = self.fetch(url)
                if b'<!DOCTYPE' in data.upper() or b'<!ENTITY' in data.upper():
                    raise CatalogError('Listagem XML inválida.')
                listed,truncated = s3_listing(data)
                keys = [key for key in listed if re.search(r'_G\d+_s\d+',key) and re.search(r'M[36]C13_',key)]
                keys = sorted(key for key in keys if key.startswith(prefix) and '..' not in key)
                if not keys:
                    warnings.append(day.isoformat()+': sem observação C13 às 15 h UTC.')
                else:
                    key = keys[0]
                    match = re.search(r'_s(\d{13})(\d*)', key)
                    acquired = (datetime.strptime(match.group(1),'%Y%j%H%M%S').replace(tzinfo=timezone.utc) + timedelta(seconds=float('0.'+match.group(2)) if match.group(2) else 0)).isoformat() if match else day.isoformat()+'T15:00:00Z'
                    items.append({'id': os.path.basename(key).removesuffix('.nc'), 'collection': 'goes-east-c13',
                        'properties': {'datetime': acquired, 'platform': 'GOES-'+satellite},
                        'catalog:kind': 'thermal', 'catalog:sources': ['NOAA NODD / AWS GOES-'+satellite],
                        'assets': {'CMI': {'href': 'https://noaa-goes'+satellite+'.s3.amazonaws.com/'+quote(key), 'roles': ['data']}}})
                if truncated:
                    warnings.append(day.isoformat()+': listagem truncada; seleção diária parcial.')
            except Exception as exc:
                if self.cancelled():
                    raise
                warnings.append(day.isoformat()+': fonte indisponível — '+str(exc))
            day += timedelta(days=1)
        return {'items': items, 'cursor': None, 'warnings': warnings}

    def download(self, item, archive, progress, offline=False, product='natural'):
        if item.get('catalog:requires_auth'):
            raise CatalogError('ASTER exige download no Earthdata; use o portal oficial. Nenhuma credencial é armazenada.')
        kind = item.get('catalog:kind')
        if kind not in ('categorical','thermal'):
            from .stac import preset_keys, index_keys
            from .radiometry import band_set
            keys = band_set(item) if product == 'bandset' else (index_keys(item,product) if product in ('ndvi','nbr') else preset_keys(item,product))
            if not keys:
                raise CatalogError('Composição indisponível nesta cena.')
            result = self.spectral_client().download_scene(item, archive.scene_folder(item), archive.rect,
                        archive.target_crs, progress, keys, product if product in ('ndvi','nbr','bandset') else 'rgb', offline)
            archive.remember(item, result[1])
            return result[2]
        if product in ('ndvi','nbr','dos1'):
            raise CatalogError('Produto categórico/térmico não aceita DOS1 ou índice espectral.')
        from osgeo import gdal
        gdal.UseExceptions()
        folder = archive.scene_folder(item);os.makedirs(folder,exist_ok=True)
        target = os.path.join(folder,'classes.tif' if kind=='categorical' else 'C13_kelvin.tif')
        with path_lock(target,self.cancelled):
            if os.path.isfile(target):
                try:
                    validate_cached_raster(target,gdal,self.cancelled)
                    archive.remember(item);archive.register_files(item,[target],self.cancelled)
                    return target
                except Exception as exc:
                    if offline:
                        raise CatalogError('Raster offline inválido: '+str(exc)) from exc
            if offline:
                raise CatalogError('Produto não disponível neste recorte do acervo offline.')
            partial = target+'.part.tif'
            raw = os.path.join(folder,'observacao.nc.part')
            previous = {}
            options = {'GDAL_HTTP_CONNECTTIMEOUT':'15','GDAL_HTTP_TIMEOUT':'45',
                       'GDAL_HTTP_MAX_RETRY':'1','GDAL_DISABLE_READDIR_ON_OPEN':'EMPTY_DIR'}
            try:
                for name,value in options.items():
                    previous[name]=gdal.GetThreadLocalConfigOption(name)
                    gdal.SetThreadLocalConfigOption(name,value)
                progress('Preparando recorte original · '+item['id'])
                if kind=='categorical':
                    href=item['assets']['classes']['href']
                    if not re.fullmatch(r'https://storage\.googleapis\.com/mapbiomas-public/initiatives/brasil/collection11/lulc/coverage/brazil_coverage/brazil_coverage-col11_\d{4}\.tif',href):
                        raise CatalogError('Endereço MapBiomas não reconhecido.')
                    source='/vsicurl/'+href
                else:
                    href=item['assets']['CMI']['href']
                    if urlparse(href).hostname not in ('noaa-goes16.s3.amazonaws.com','noaa-goes19.s3.amazonaws.com'):
                        raise CatalogError('Endereço GOES não reconhecido.')
                    request(href,cancelled=self.cancelled,timeout=120,max_bytes=128*1024*1024,target=raw)
                    source='NETCDF:"'+raw+'":CMI'
                dataset=gdal.Open(source)
                if dataset is None or not dataset.GetProjection():
                    raise CatalogError('GDAL não reconheceu a georreferência deste produto; nenhuma projeção foi presumida.')
                scale,offset,raw_nodata=1.,0.,None
                if kind=='thermal':
                    from osgeo import osr
                    metadata=dataset.GetMetadata()
                    required=('perspective_point_height','longitude_of_projection_origin','semi_major_axis','semi_minor_axis','sweep_angle_axis')
                    if any('goes_imager_projection#'+key not in metadata for key in required):
                        raise CatalogError('Metadados CF incompletos para a projeção geostacionária.')
                    values={key:metadata['goes_imager_projection#'+key] for key in required}
                    if values['sweep_angle_axis'] not in ('x','y'):
                        raise CatalogError('Eixo de varredura GOES inválido.')
                    height=float(values['perspective_point_height'])
                    gt=dataset.GetGeoTransform()
                    if max(abs(gt[0]),abs(gt[3])) < 1:
                        gt=tuple(value*height for value in gt)
                    if not (3e7 < height < 4e7 and 100 < abs(gt[1]) < 10000):
                        raise CatalogError('Grade GOES não reconhecida; georreferência não presumida.')
                    sr=osr.SpatialReference()
                    sr.ImportFromProj4('+proj=geos +h={} +lon_0={} +a={} +b={} +sweep={} +units=m +no_defs'.format(
                        height,float(values['longitude_of_projection_origin']),float(values['semi_major_axis']),
                        float(values['semi_minor_axis']),values['sweep_angle_axis']))
                    source=gdal.Translate('',dataset,format='VRT')
                    source.SetGeoTransform(gt);source.SetProjection(sr.ExportToWkt())
                    band=dataset.GetRasterBand(1)
                    scale,offset=band.GetScale(),band.GetOffset()
                    raw_nodata=band.GetNoDataValue()
                    if scale is None or offset is None or raw_nodata is None:
                        raise CatalogError('Calibração Kelvin/NoData ausente no CMI.')
                result=gdal.Warp(partial,source,format='GTiff',outputBounds=context_bbox(archive.rect),
                    outputBoundsSRS='EPSG:4326',dstSRS=archive.target_crs,resampleAlg='near',
                    dstNodata=0 if kind=='categorical' else raw_nodata,warpMemoryLimit=32,
                    creationOptions=['TILED=YES','COMPRESS=DEFLATE'],
                    callback=lambda *args: 0 if self.cancelled() else 1)
                if result is None:
                    raise CatalogError('Falha ao recortar o produto.')
                result=None;dataset=None
                if kind=='thermal':
                    import numpy as np
                    packed=gdal.Open(partial)
                    quality=gdal.Open('NETCDF:"'+raw+'":DQF')
                    if quality is None or quality.RasterXSize!=source.RasterXSize or quality.RasterYSize!=source.RasterYSize:
                        raise CatalogError('Máscara DQF GOES ausente ou incompatível.')
                    quality_source=gdal.Translate('',quality,format='VRT')
                    quality_source.SetProjection(sr.ExportToWkt());quality_source.SetGeoTransform(gt)
                    out_gt=packed.GetGeoTransform()
                    quality_crop=gdal.Warp('',quality_source,format='MEM',dstSRS=packed.GetProjection(),
                        outputBounds=(out_gt[0],out_gt[3]+out_gt[5]*packed.RasterYSize,
                                      out_gt[0]+out_gt[1]*packed.RasterXSize,out_gt[3]),
                        width=packed.RasterXSize,height=packed.RasterYSize,srcNodata=quality.GetRasterBand(1).GetNoDataValue(),dstNodata=255,outputType=gdal.GDT_Byte,resampleAlg='near',
                        callback=lambda *args:0 if self.cancelled() else 1)
                    if quality_crop is None:raise CatalogError('Falha ao alinhar DQF.')
                    unpacked=target+'.unscaled.part.tif'
                    converted=gdal.GetDriverByName('GTiff').Create(unpacked,packed.RasterXSize,packed.RasterYSize,1,
                        gdal.GDT_Float32,['TILED=YES','COMPRESS=DEFLATE'])
                    converted.SetProjection(packed.GetProjection());converted.SetGeoTransform(packed.GetGeoTransform())
                    converted.SetMetadata({'UNITS':'K','SOURCE_VARIABLE':'CMI','SOURCE_CHANNEL':'13',
                                           'DOS1':'not_applicable','QUALITY':'CMI fill mask and DQF==0 (good retrieval)'})
                    output_band=converted.GetRasterBand(1);output_band.SetNoDataValue(-9999);output_band.SetUnitType('K')
                    for y in range(0,packed.RasterYSize,256):
                        if self.cancelled():raise CatalogError('Calibração térmica cancelada.')
                        data=packed.GetRasterBand(1).ReadAsArray(0,y,packed.RasterXSize,min(256,packed.RasterYSize-y))
                        qa=quality_crop.GetRasterBand(1).ReadAsArray(0,y,packed.RasterXSize,min(256,packed.RasterYSize-y))
                        data=np.where((data==raw_nodata)|(qa!=0),-9999,data.astype('float32')*scale+offset)
                        output_band.WriteArray(data,0,y)
                    converted.FlushCache();converted=None;packed=None;source=None;quality_crop=None;quality_source=None;quality=None
                    os.replace(unpacked,partial)
                validate_raster(partial,gdal,self.cancelled)
                ds=gdal.Open(partial)
                values=ds.GetRasterBand(1).ReadAsArray(buf_xsize=min(256,ds.RasterXSize),buf_ysize=min(256,ds.RasterYSize))
                import numpy as np
                if not np.any(np.isfinite(values) & (values != ds.GetRasterBand(1).GetNoDataValue())):
                    raise CatalogError('Sem pixels válidos na área consultada.')
                ds=None
                os.replace(partial,target);receipt(target,self.cancelled)
                archive.remember(item);archive.register_files(item,[target],self.cancelled)
                atomic_json(target+'.origem.json',{'source':href,'item':item,'kind':kind,'resampling':'nearest', 'dos1':False})
                return target
            except PublicHttpError:
                raise
            except Exception as exc:
                if kind == 'categorical' and any(code in str(exc) for code in ('403', '401')):
                    raise PublicHttpError('MapBiomas: acesso público bloqueado/suspenso. Use o acervo local ou exporte GeoTIFF pelo portal oficial GEE.',403) from exc
                if self.cancelled():
                    raise CatalogError('Download cancelado; arquivos concluídos preservados.') from exc
                raise CatalogError('Não foi possível preparar o produto. Confira cobertura, acesso e driver GDAL. '+str(exc)) from exc
            finally:
                source=dataset=result=ds=packed=converted=quality=quality_source=quality_crop=output_band=None
                for path in (partial,raw,target+'.unscaled.part.tif'):
                    if os.path.exists(path):
                        os.remove(path)
                for name,value in previous.items():
                    gdal.SetThreadLocalConfigOption(name,value)


def ingest_mapbiomas(paths, archive, cancelled=lambda: False, progress=lambda message: None,
                      on_ready=lambda event: None):
    """Optional fallback for annual or multi-band GeoTIFF exports from GEE.

    Years must be explicit in filenames or band descriptions. No collection
    identity or observation date is inferred from an unlabelled raster.
    """
    from osgeo import gdal
    gdal.UseExceptions()
    import numpy as np
    completed, errors = [], []
    for source in paths:
        if cancelled():
            raise CatalogError('Importação local cancelada.')
        try:
            ds = gdal.Open(source)
            if ds is None or not ds.GetProjection():
                raise CatalogError('GeoTIFF sem georreferência reconhecida.')
            for number in range(1, ds.RasterCount+1):
                if cancelled():
                    raise CatalogError('Importação local cancelada.')
                band = ds.GetRasterBand(number)
                label = band.GetDescription() or (os.path.basename(source) if ds.RasterCount==1 else '')
                match = re.findall(r'(?<!\d)(19[89]\d|20\d{2})(?!\d)',label)
                if len(set(match)) != 1:
                    errors.append(os.path.basename(source)+' / banda '+str(number)+': ano não identificado; use classification_AAAA.')
                    continue
                year = int(match[0])
                sample = band.ReadAsArray(buf_xsize=min(128,ds.RasterXSize),buf_ysize=min(128,ds.RasterYSize))
                valid = np.isfinite(sample)
                if band.GetNoDataValue() is not None:
                    valid &= sample != band.GetNoDataValue()
                values = sample[valid]
                if not len(values) or np.any((values < 0) | (values > 99) | (values != np.floor(values))):
                    raise CatalogError('Valores incompatíveis com classes discretas MapBiomas. Não é uma imagem RGB.')
                identifier = 'mapbiomas-local-'+str(year)+'-'+__import__('hashlib').sha256(os.path.realpath(source).encode()).hexdigest()[:12]
                item = {'id':identifier,'collection':'mapbiomas-local','properties':{'datetime':str(year)+'-01-01T00:00:00Z','year':year},
                        'catalog:kind':'categorical','catalog:sources':['GeoTIFF MapBiomas fornecido pelo usuário; coleção não verificada'],
                        'catalog:local_origin':os.path.basename(source),'assets':{}}
                folder = archive.scene_folder(item);os.makedirs(folder,exist_ok=True)
                target = os.path.join(folder,'classes.tif');partial=target+'.part.tif'
                with path_lock(target,cancelled):
                    try:
                        progress('Recortando classes do ano '+str(year))
                        selected = gdal.Translate('',ds,format='MEM',bandList=[number])
                        result = gdal.Warp(partial,selected,format='GTiff',outputBounds=context_bbox(archive.rect),
                            outputBoundsSRS='EPSG:4326',dstSRS=archive.target_crs,resampleAlg='near',dstNodata=0,
                            creationOptions=['TILED=YES','COMPRESS=DEFLATE'],
                            callback=lambda *args: 0 if cancelled() else 1)
                        if result is None:
                            raise CatalogError('Recorte local falhou.')
                        result=selected=None
                        validate_raster(partial,gdal,cancelled)
                        os.replace(partial,target);receipt(target,cancelled)
                        archive.remember(item);archive.register_files(item,[target],cancelled)
                        on_ready({'item':item,'path':target,'product':'original','area':archive.area_id})
                        completed.append(identifier)
                    finally:
                        if os.path.exists(partial):os.remove(partial)
            ds = None
        except Exception as exc:
            if cancelled():raise
            errors.append(os.path.basename(source)+': '+str(exc))
    return {'completed':completed,'errors':errors}
