# Validação 5.0.1

## Ambiente e verificações

271 testes aprovados, sem testes pulados, em Linux, QGIS 3.40.6-Bratislava, GDAL 3.10.3, Python 3.13.5 e NumPy 2.2.4, Qt offscreen. Incluem análise, interface, cartas e dez testes específicos de localização do acervo/fila. Compilação Python, metadados ConfigParser, Flake8 no perfil de publicação, Bandit e detect-secrets foram verificados. Os dois ZIPs foram conferidos quanto a integridade, duplicações e correspondência do código durante o empacotamento.

## Correção de abertura 5.0.1

Regressão WinError 3 reproduzida por simulação de unidade D: ausente no sistema de arquivos. O diálogo completo abriu, usou outra pasta gravável, preservou a configuração original e salvou uma tarefa na pasta alternativa. Testados também: reutilização da pasta válida sem resíduos de teste de escrita, fallback por falta de permissão, interface aberta sem local gravável, fila vazia/inalterada sem escrita na abertura, recuperação após falha transitória, preservação de tarefas quando a gravação falha, recusa de troca para pasta inválida, troca válida com filas separadas e fila corrompida preservada ao executar.

Esses cenários foram simulados no Linux; não houve acesso ao computador Windows do usuário. A correção não move ou exclui o acervo antigo. A preferência anterior só muda quando o usuário escolhe explicitamente uma pasta gravável. Se a unidade antiga for reconectada, as tarefas e imagens dessa pasta voltam a ser acessíveis.

## Classificação e dados

Foram executados treinamento reproduzível e previsões em dados sintéticos independentes, matriz de confusão com erros conhecidos, previsão indeterminada contabilizada como erro, persistência JSON e cancelamento. O ensaio completo com raster GDAL georreferenciado verifica: amostras em polígonos separados, máscara QA, calibração, classificação, áreas por classe, raster de concordância, relatório HTML, curva de assinatura e preservação das entradas.

Amostras sobrepostas ou com classes sem validação são recusadas. A ausência de calibração/QA é identificada. O resultado usa código 0 para indeterminação e 255 para ausência de observação válida. As métricas aplicam o mesmo limiar de concordância usado na entrega do raster. Não é uma avaliação da acurácia em floresta, pastagem ou agricultura reais, nem um teste de campo.

A floresta é uma implementação própria documentada com NumPy (CART/Gini, bootstrap, subespaço aleatório e limiares por quantis), não scikit-learn ou SCP. Os parâmetros padrão constam do guia, dos resultados e do modelo JSON. Não há dependência nova de pacote de aprendizado de máquina, conta, servidor ou serviço pago.

## Séries e tarefas

O fluxo temporal foi executado com duas e três datas conhecidas, verificando diferenças nulas quando os dados eram iguais, rejeição de datas repetidas e pixels válidos comuns. O código aceita duas a 60 datas; o teste não constitui ensaio de desempenho de todas essas dimensões. As diferenças ficam na grade comum suportada e não estimam o que existe sob nuvens.

A fila foi testada com persistência em disco, recuperação de estado interrompido, alteração de entradas e corrupção JSON sem sobrescrever o arquivo. Uma tarefa real QgsTask executou classificação fora da thread gráfica, gravou resultados e adicionou uma camada paletizada na thread principal. Os controles de amostras foram conferidos para treino/validação, e rasters sem metadados não foram aceitos silenciosamente.

Retomar significa repetir a etapa interrompida com as mesmas entradas verificadas, aproveitando cache de downloads. Não foi implementado checkpoint por árvore nem por linha de raster. A fila deve ser usada por uma instância QGIS de cada vez. A retomada não permite alterar um arquivo de entrada e tratá-lo como o mesmo experimento.

## Cartas-imagem editáveis

Foram geradas cartas nativas em A4 paisagem, A4 retrato e A3 paisagem, com exportação PDF e PNG. Os testes verificaram mapa e legenda como itens QGIS editáveis, área positiva/georreferenciada, SRC SIRGAS 2000 UTM 22S na área sintética, QPT salvo e a identificação de PRODES não consultado quando não havia camada.

Um ensaio adicional adicionou PRODES demonstrativo, hachura vermelha, rótulos de ano e limite verde, e exportou a carta para inspeção visual. Foi salvo um projeto QGZ e reaberto com o layout presente. Vetores auxiliares da carta são preservados como GeoPackage, sem depender da sobrevivência de uma camada de memória. Norte SVG e logomarca escolhida são copiados para a pasta da carta; estilos originais são preservados.

A inspeção visual levou ao ajuste das anotações laterais para direção vertical e ao posicionamento da escala dentro da área do mapa, evitando colisão com o rodapé. A carta usa coordenadas calculadas e campos reais/informados pelo operador. Nenhuma identidade, logomarca ou coordenada do exemplo anexado foi embutida no código público. O exemplo visual do teste é sintético, não representa um laudo ambiental real.

O botão Gerenciador de layouts foi verificado quanto ao encaminhamento à API QGIS. O Designer permanece responsável por edições finais. Legendas extensas pedem folha maior/redução de camadas em vez de serem cortadas silenciosamente. Campos desconhecidos não são inventados. A indicação de interseção PRODES se refere à camada fornecida, não a uma certificação ambiental.

## Limites e publicação

Não foram realizados: instalação Windows; execução em todas as versões QGIS; benchmark controlado contra SCP; interpretação validada de campo; prova de uma taxa mínima de acerto ambiental. Esses pontos não devem ser anunciados como concluídos. Os testes de novas análises usam dados controlados; as fontes públicas e os fluxos de acesso da 4.1 foram preservados sem uma nova consulta exaustiva de disponibilidade de todos os acervos.

A marca experimental=False configura a distribuição do software e não certifica sua interpretação temática, fundiária ou jurídica. O pacote continua compatível com QGIS 3.40–3.99 e não declara QGIS 4. As funções de análise exigem amostras adequadas e revisão do técnico. Relatórios e limiares exploratórios não são apresentados como metodologia oficial de decisão INPE.

Nenhum envio ao GitHub ou ao repositório oficial QGIS foi feito. O código-fonte correspondente deve atualizar o repositório antes da submissão do ZIP de instalação.
