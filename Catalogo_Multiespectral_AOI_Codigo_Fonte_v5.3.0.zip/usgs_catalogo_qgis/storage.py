# SPDX-License-Identifier: GPL-2.0-or-later
"""Local transactional asset index and content integrity receipts."""
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from .stac import CatalogError

_LOCKS, _GUARD = {}, threading.Lock()


def lock_key(path):
    # Resolve the directory, not the file being atomically replaced: on Windows
    # probing the destination during replacement can yield a different spelling.
    absolute = os.path.abspath(path)
    key = os.path.normcase(os.path.join(os.path.realpath(os.path.dirname(absolute)), os.path.basename(absolute)))
    if key.startswith('\\\\?\\unc\\'):
        key = '\\\\' + key[8:]
    elif key.startswith('\\\\?\\'):
        key = key[4:]
    return key


@contextmanager
def path_lock(path, cancelled=lambda: False):
    key = lock_key(path)
    with _GUARD:
        lock = _LOCKS.setdefault(key, threading.RLock())
    while not lock.acquire(timeout=.1):
        if cancelled():
            raise CatalogError('Operação cancelada enquanto aguardava o arquivo local.')
    try:
        if cancelled():
            raise CatalogError('Operação cancelada.')
        yield
    finally:
        lock.release()


def atomic_json(path, value):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    temporary = path + '.' + uuid.uuid4().hex + '.part'
    try:
        with open(temporary, 'w', encoding='utf8') as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.flush()
            os.fsync(stream.fileno())
        # Windows can briefly deny replacement while a scanner/reader holds the
        # destination. Keep the previous JSON intact and retry the atomic move.
        for attempt in range(5):
            try:
                os.replace(temporary, path)
                break
            except PermissionError as exc:
                if getattr(exc, 'winerror', None) not in (5, 32, 33) or attempt == 4:
                    raise
                time.sleep(.05 * 2**attempt)
    finally:
        if os.path.exists(temporary):
            os.remove(temporary)


def sha256(path, cancelled=lambda: False):
    value = hashlib.sha256()
    with open(path, 'rb') as stream:
        while True:
            if cancelled():
                raise CatalogError('Verificação cancelada.')
            chunk = stream.read(1024*1024)
            if not chunk:
                return value.hexdigest()
            value.update(chunk)


def receipt(path, cancelled=lambda: False, deep=False):
    """Fast reopen uses stat; deep audit always checks the stored content digest."""
    info = os.stat(path)
    if info.st_size == 0:
        raise CatalogError('Arquivo local vazio.')
    signature = [info.st_size, info.st_mtime_ns]
    old = None
    try:
        with open(path + '.validated.json', encoding='utf8') as stream:
            old = json.load(stream)
    except (OSError, ValueError):
        old = None
    if isinstance(old, dict) and old.get('stat') == signature and not deep:
        if old.get('invalid'):
            raise CatalogError('Arquivo reprovado na auditoria de integridade; recupere a banda antes de reutilizar.')
        return old
    digest = sha256(path, cancelled)
    if deep and isinstance(old, dict) and old.get('sha256') and old['sha256'] != digest:
        raise CatalogError('Integridade divergente: arquivo local foi alterado ou corrompido.')
    data = {'version': 2, 'stat': signature, 'sha256': digest,
            'verified_at': datetime.now(timezone.utc).isoformat()}
    atomic_json(path + '.validated.json', data)
    return data


class AssetIndex:
    def __init__(self, root):
        self.root = os.path.realpath(root)
        self.path = os.path.join(self.root, 'indice.sqlite')

    @contextmanager
    def connection(self):
        os.makedirs(self.root, exist_ok=True)
        db = sqlite3.connect(self.path, timeout=15)
        try:
            db.execute('PRAGMA busy_timeout=15000')
            db.execute('''CREATE TABLE IF NOT EXISTS assets (
                path TEXT PRIMARY KEY, area TEXT NOT NULL, scene TEXT NOT NULL,
                kind TEXT NOT NULL, size INTEGER NOT NULL, mtime INTEGER NOT NULL,
                sha256 TEXT NOT NULL, metadata TEXT NOT NULL, updated TEXT NOT NULL)''')
            db.execute('CREATE INDEX IF NOT EXISTS by_area_scene ON assets(area, scene)')
            yield db
            db.commit()
        finally:
            db.close()

    def relative(self, path):
        path = os.path.realpath(path)
        try:
            inside = os.path.commonpath([self.root, path]) == self.root
        except ValueError:
            inside = False  # Different Windows drives cannot share an archive root.
        if not inside:
            raise CatalogError('Arquivo fora da pasta do acervo.')
        return os.path.relpath(path, self.root)

    def register(self, path, area, scene, kind, metadata=None, cancelled=lambda: False):
        value = receipt(path, cancelled)
        with self.connection() as db:
            db.execute('INSERT OR REPLACE INTO assets VALUES (?,?,?,?,?,?,?,?,?)',
                       (self.relative(path), area, scene, kind, *value['stat'], value['sha256'],
                        json.dumps(metadata or {}, ensure_ascii=False), value['verified_at']))

    def rows(self, area=None):
        with self.connection() as db:
            db.row_factory = sqlite3.Row
            if area:
                rows=db.execute('SELECT * FROM assets WHERE area=? ORDER BY scene,kind,path',(area,))
            else:
                rows=db.execute('SELECT * FROM assets ORDER BY scene,kind,path')
            return [dict(row) for row in rows]

    def audit(self, cancelled=lambda: False, progress=lambda message: None):
        from osgeo import gdal
        from .stac import validate_raster
        results = []
        for row in self.rows():
            if cancelled():
                raise CatalogError('Verificação cancelada; arquivos existentes preservados.')
            path = os.path.join(self.root, row['path'])
            progress('Verificando ' + row['scene'] + ' · ' + row['kind'])
            try:
                self.relative(path)
                if sha256(path, cancelled) != row['sha256']:
                    raise CatalogError('SHA-256 divergente')
                validate_raster(path, gdal, cancelled)
                info=os.stat(path)
                atomic_json(path+'.validated.json',{'version':2,'stat':[info.st_size,info.st_mtime_ns],
                    'sha256':row['sha256'],'verified_at':datetime.now(timezone.utc).isoformat()})
                results.append({'path': row['path'], 'status': 'ok'})
            except Exception as exc:
                if cancelled():
                    raise
                if os.path.isfile(path):
                    info=os.stat(path)
                    atomic_json(path+'.validated.json',{'version':2,'invalid':True,
                        'stat':[info.st_size,info.st_mtime_ns],'sha256':row['sha256']})
                results.append({'path': row['path'], 'status': 'invalid', 'error': str(exc)})
        return results

    def reindex(self, cancelled=lambda: False, progress=lambda message: None):
        from .stac import validate_raster
        from osgeo import gdal
        count, errors, catalogs = 0, [], {}
        existing={row["path"]:row for row in self.rows()}
        for path in Path(self.root).glob('areas/*/cenas/*/*'):
            if cancelled():
                raise CatalogError('Indexação cancelada.')
            if path.suffix.lower() not in ('.tif', '.vrt'):
                continue
            try:
                progress('Indexando ' + path.name)
                previous=existing.get(self.relative(str(path)))
                if previous and sha256(str(path),cancelled)!=previous['sha256']:
                    raise CatalogError('Arquivo já indexado tem hash divergente; índice original preservado.')
                validate_raster(str(path), gdal, cancelled)
                area=path.parents[2].name
                if area not in catalogs:
                    try:
                        catalogs[area]=json.loads((path.parents[2]/'catalogo.json').read_text(encoding='utf8')).get('scenes',{})
                    except (OSError,ValueError):
                        catalogs[area]={}
                item=catalogs[area].get(path.parent.name,{}).get('item',{})
                metadata={'collection':item.get('collection'),'id':item.get('id'),
                          'datetime':item.get('properties',{}).get('datetime'),
                          'sources':item.get('catalog:sources',[])}
                kind='composition' if path.suffix=='.vrt' or path.name.startswith(('NDVI_','NBR_')) else 'band'
                self.register(str(path), area, path.parent.name, kind, metadata, cancelled=cancelled)
                count += 1
            except Exception as exc:
                if cancelled():
                    raise
                errors.append({'path': str(path), 'error': str(exc)})
        return {'indexed': count, 'errors': errors}
