# Guia rápido · 5.1.0

## Atualizar

No QGIS, abra Complementos → Gerenciar e instalar complementos → Instalar a partir de ZIP.
Selecione Catalogo_Multiespectral_AOI_QGIS_v5.1.0.zip. Feche o plugin antes da atualização
e reinicie o QGIS depois. O pacote Codigo_Fonte é para desenvolvimento, não para instalar.
As imagens, amostras e a fila existentes não são apagadas nem migradas.

## Configurar uma vez

Abra a aba Início, selecione o imóvel, o período e os satélites. Confira a pasta do acervo,
o modo offline, o formato da carta e o responsável técnico. Clique em Aplicar configurações
às abas. O limite é aplicado a Imagens, Classificação, Comparação temporal, Cartas-imagem,
PRODES e Situação ambiental. Feições selecionadas são respeitadas.

A opção Lembrar salva apenas satélites, modo offline, formato e responsável neste computador.
Na próxima abertura, confira os valores e clique em Aplicar. O imóvel e o período não são
memorizados para evitar reutilizar uma área ou data sem conferência. Desmarcar Lembrar e
aplicar apaga essas preferências. A pasta do acervo continua com sua preferência própria.
Nenhum atalho inicia downloads nem executa a fila automaticamente.

Os campos específicos continuam nas suas abas: UF, CAR e processos na consulta ambiental;
ano, fontes e perfil na consulta PRODES; classes e amostras na classificação; metadados e
camadas temáticas na carta. Confira esses campos antes de executar. Não se infere UF ou
identificação de propriedade a partir do nome de uma pasta.

## Classificar

1. Use o atalho Buscar e escolher imagens; selecione uma cena.
2. Use Baixar Band Set completo / conferir qualidade. Baixe o Band Set e sua QA.
3. Abra Classificação e selecione o imóvel e a imagem. Clique em Criar amostras.
4. Escolha uma classe e Treinamento; Desenhar amostra libera o mapa. Finalize com o botão
   direito, confira o formulário e reabra o plugin. Desenhe outra área da mesma classe como
   Validação independente. Repita para ao menos duas classes reconhecidas pelo técnico.
5. Clique em Conferir amostras. O resumo conta polígonos e aponta a classe incompleta.
   Não copie o mesmo polígono para treino e validação. A verificação de pixels acontece
   na execução: mínimo 10 pixels válidos de treino e 5 de validação em cada classe.
6. Classificar imóvel cria uma tarefa. Em Fila de tarefas, Executar pendentes processa
   todas as tarefas pendentes. Abra resultado mostra o relatório.

A versão 5.1 bloqueia amostras vazias, classes incompletas e sobreposição antes de enfileirar.
Depois de editar amostras, crie uma nova tarefa. Retomar não substitui as amostras congeladas
na tarefa anterior. A validação independente continua obrigatória; não é criada automaticamente.

## Comparar datas

Selecione entre duas e 60 imagens locais com vermelho, NIR e SWIR2, calibração e QA.
Use Ctrl ou Shift na tabela. Datas devem ser distintas e no formato AAAA-MM-DD.
Uma composição RGB comum não tem as bandas necessárias; use Preparar Band Sets.
Comparar datas selecionadas cria a tarefa; execute na Fila e confira o relatório.
Datas inválidas, repetidas e seleção insuficiente são rejeitadas antes de enfileirar.

## Carta-imagem

Escolha a imagem, confira os campos e gere a carta. Para RGB, use Manter composição atual.
As composições alternativas exigem Band Set; agora uma escolha incompatível gera orientação
em vez de ser ignorada. Atualizar camadas preserva as marcações das camadas temáticas.
Use Abrir designer ou Gerenciador de layouts e exporte PDF/PNG. Salve o projeto QGIS
e mantenha o acervo e as bandas acessíveis para continuar editando a carta.

## Windows e limites

Os testes fecham explicitamente rasters e arquivos temporários antes de excluí-los e
processam a destruição adiada dos layouts. Não foram desativadas as verificações de limpeza.
O processamento e os critérios de QA, independência das amostras e integridade da fila
permanecem obrigatórios. Testes sintéticos não demonstram acurácia temática no imóvel.
