# SPDX-License-Identifier: GPL-2.0-or-later
"""Editable QGIS print layouts: adaptive frame, real CRS and linked legend."""
import math
import os
import uuid
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor,QFont
from qgis.core import (QgsProject,QgsPrintLayout,QgsLayoutItemPage,QgsLayoutItemLabel,QgsLayoutItemMap,
    QgsLayoutItemLegend,QgsLegendStyle,QgsLayoutItemScaleBar,QgsLayoutPoint,QgsLayoutSize,QgsLayoutItemPicture,
    QgsLayoutItemMapGrid,QgsCoordinateReferenceSystem,QgsCoordinateTransform,QgsRectangle,QgsDistanceArea,
    QgsFillSymbol,QgsLinePatternFillSymbolLayer,QgsVectorFileWriter,QgsVectorLayer,QgsRasterLayer,
    QgsReadWriteContext,QgsLayoutExporter,Qgis)
from .stac import CatalogError
from .parcel import snapshot
from .storage import atomic_json


def nice_number(value):
    base=10**math.floor(math.log10(max(value,1e-6)))
    return next(factor*base for factor in (1,2,2.5,5,10) if factor*base>=value)


def create_layout(config, iface=None):
    project=QgsProject.instance();parcel=snapshot(config['parcel']);raster=config['raster']
    if not raster or not raster.isValid():raise CatalogError('Escolha a imagem ou classificação para a carta.')
    if config.get('preset') and not raster.customProperty('catalogo_multiespectral_band_set',''):
        raise CatalogError('Esta imagem não é um Band Set. Escolha Manter composição atual; para outra combinação, importe a composição desejada na página Imagens.')
    folder=os.path.join(config['root'],'cartas',uuid.uuid4().hex);os.makedirs(folder,exist_ok=True)
    rect=parcel.rect;zone=min(60,max(1,int((((rect[0]+rect[2])/2)+180)//6)+1));lat=(rect[1]+rect[3])/2
    epsg=(31960+zone) if lat<0 and 18<=zone<=25 else (32600 if lat>=0 else 32700)+zone
    crs=QgsCoordinateReferenceSystem('EPSG:'+str(epsg));transform=QgsCoordinateTransform(QgsCoordinateReferenceSystem('EPSG:4326'),crs,project)
    extent=transform.transformBoundingBox(QgsRectangle(*rect));extent.scale(1.18)
    clones=[];created=[];layout=None
    try:
        def vector_copy(source,title,style=None):
            dest=os.path.join(folder,'vetor_'+str(len(clones))+'.gpkg');options=QgsVectorFileWriter.SaveVectorOptions();options.driverName='GPKG'
            bounds=QgsCoordinateTransform(crs,source.crs(),project).transformBoundingBox(extent);options.filterExtent=bounds
            result=QgsVectorFileWriter.writeAsVectorFormatV3(source,dest,project.transformContext(),options)
            if result[0]!=QgsVectorFileWriter.WriterError.NoError:raise CatalogError('Falha ao preservar vetores da carta: '+str(result))
            clone=QgsVectorLayer(dest,title,'ogr')
            if not clone.isValid():raise CatalogError('Não foi possível abrir o vetor preservado.')
            clone.setRenderer((style or source.renderer()).clone());clone.setLabelsEnabled(source.labelsEnabled())
            if source.labeling():clone.setLabeling(source.labeling().clone())
            clone.setCustomProperty('catalogo_layout_aux',True);project.addMapLayer(clone,False);clones.append(clone);created.append(clone.id());return clone
        outline=parcel.outline_layer();outline.setRenderer(config['parcel'].renderer().clone())
        boundary=vector_copy(outline,'Área do imóvel');boundary.setRenderer(boundary.renderer().clone())
        from qgis.core import QgsSingleSymbolRenderer
        boundary.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple({'color':'0,0,0,0','outline_color':'#26b21b','outline_width':'.7','joinstyle':'round'})))
        overlays=[];prodes_found=None
        property_name=config.get('property') or parcel.layer_name
        effective_title=config.get('title') or 'CARTA-IMAGEM'
        if effective_title=='CARTA-IMAGEM':effective_title=('PRODES — ' if any('prodes' in layer.name().lower() for layer in config.get('overlays',[])) else 'CARTA-IMAGEM — ')+property_name
        for source in config.get('overlays',[]):
            if source.id()==config['parcel'].id():continue
            clone=vector_copy(source,source.name())
            if 'prodes' in source.name().lower():
                symbol=QgsFillSymbol.createSimple({'color':'0,0,0,0','outline_color':'#d62525','outline_width':'.25'})
                hatch=QgsLinePatternFillSymbolLayer.create({'line_color':'#d62525','line_width':'.2','distance':'1.8','angle':'45'})
                if hatch:symbol.appendSymbolLayer(hatch)
                from qgis.core import QgsSingleSymbolRenderer
                clone.setRenderer(QgsSingleSymbolRenderer(symbol))
                year_field=next((field.name() for field in clone.fields() if field.name().lower() in ('year','ano','ano_prodes')),None)
                if year_field and not clone.labelsEnabled():
                    from qgis.core import QgsPalLayerSettings,QgsVectorLayerSimpleLabeling,QgsTextFormat,QgsTextBufferSettings
                    settings=QgsPalLayerSettings();settings.fieldName=year_field;settings.placement=Qgis.LabelPlacement.Horizontal
                    text=QgsTextFormat();text.setFont(QFont('Arial',8));text.setSize(8);text.setColor(QColor('#15384c'))
                    buffer=QgsTextBufferSettings();buffer.setEnabled(True);buffer.setSize(.7);buffer.setColor(QColor('white'));text.setBuffer(buffer);settings.setFormat(text)
                    clone.setLabeling(QgsVectorLayerSimpleLabeling(settings));clone.setLabelsEnabled(True)
                from qgis.core import QgsGeometry
                parcel_geom=QgsGeometry.fromWkt(parcel.geometry_wkt);to_wgs=QgsCoordinateTransform(clone.crs(),QgsCoordinateReferenceSystem('EPSG:4326'),project)
                overlaps=[]
                for feature in clone.getFeatures():
                    geom=QgsGeometry(feature.geometry());geom.transform(to_wgs)
                    if not geom.isEmpty() and geom.intersects(parcel_geom):
                        part=geom.intersection(parcel_geom)
                        if not part.isEmpty() and part.area()>0:overlaps.append(part)
                prodes_found=bool(overlaps) or bool(prodes_found)
            if clone.featureCount()>0:overlays.append(clone)
        image=QgsRasterLayer(raster.source(),raster.name(),raster.providerType());image.setRenderer(raster.renderer().clone())
        image.setCustomProperty('catalogo_layout_aux',True);project.addMapLayer(image,False);created.append(image.id())
        if config.get('preset') and raster.customProperty('catalogo_multiespectral_band_set',''):
            from .plugin import CatalogDialog
            import json
            keys=json.loads(str(raster.customProperty('catalogo_multiespectral_band_set')))
            semantic={'natural':('red','green','blue'),'prodes':('swir16','nir08','red'),'burn':('swir22','nir08','red'),'infrared':('nir08','red','green')}
            wanted=semantic.get(config['preset'],semantic['natural']);mapping={'red':'B04','green':'B03','blue':'B02','nir08':'B08','swir16':'B11','swir22':'B12'}
            selected=tuple(k if k in keys else mapping[k] for k in wanted)
            if not set(selected)<=set(keys):raise CatalogError('Band Set não contém a composição escolhida.')
            meta=json.loads(str(raster.customProperty('catalogo_multiespectral_espectral','{}')))
            item={'collection':meta.get('collection'),'assets':{key:{'href':key+'.tif','eo:bands':[{'name':key}],'raster:bands':[{'scale':coeff[0],'offset':coeff[1]}]} for key,coeff in zip(meta.get('keys',[]),meta.get('coefficients',[]))}}
            CatalogDialog.configure_rgb(image,False,item,selected,tuple(keys.index(k)+1 for k in selected))
            composition=' / '.join(selected)
        else:composition=str(raster.customProperty('catalogo_multiespectral_bandas','Renderização atual da camada'))
        layout=QgsPrintLayout(project);layout.initializeDefaults()
        page=layout.pageCollection().page(0);page.setPageSize(config.get('paper','A4'),QgsLayoutItemPage.Orientation.Landscape if config.get('landscape',True) else QgsLayoutItemPage.Orientation.Portrait)
        width,height=page.pageSize().width(),page.pageSize().height();margin=8;side=max(68,width*.28);mapwidth=width-3*margin-side;mapheight=height-39
        base=effective_title;name=base;number=2
        while project.layoutManager().layoutByName(name):name=base+' · '+str(number);number+=1
        layout.setName(name)
        def label(text,x,y,w,h,size=9,bold=False,frame=True,center=False):
            item=QgsLayoutItemLabel(layout);item.setText(text);font=QFont('Arial',size);font.setBold(bold);item.setFont(font);item.setMargin(1.2);item.setFrameEnabled(frame)
            if center:item.setHAlign(Qt.AlignmentFlag.AlignHCenter)
            item.setVAlign(Qt.AlignmentFlag.AlignVCenter);layout.addLayoutItem(item);item.attemptMove(QgsLayoutPoint(x,y));item.attemptResize(QgsLayoutSize(w,h));return item
        label(effective_title,margin,5,width-2*margin,12,14,True,True,True)
        mapitem=QgsLayoutItemMap(layout);mapitem.setId('mapa_principal');layout.addLayoutItem(mapitem);mapitem.attemptMove(QgsLayoutPoint(margin,25));mapitem.attemptResize(QgsLayoutSize(mapwidth,mapheight));mapitem.setCrs(crs)
        mapitem.setLayers([boundary]+overlays+[image]);mapitem.setKeepLayerSet(True);mapitem.setKeepLayerStyles(True);mapitem.zoomToExtent(extent);mapitem.setScale(math.ceil(mapitem.scale()/(10**math.floor(math.log10(mapitem.scale()))/5))*(10**math.floor(math.log10(mapitem.scale()))/5));mapitem.setFrameEnabled(True)
        grid=mapitem.grid();grid.setEnabled(True);interval=nice_number(mapitem.extent().width()/4);grid.setIntervalX(interval);grid.setIntervalY(interval);grid.setAnnotationEnabled(True);grid.setAnnotationPrecision(0);grid.setAnnotationFont(QFont('Arial',7));grid.setStyle(QgsLayoutItemMapGrid.GridStyle.FrameAnnotationsOnly)
        for border in (QgsLayoutItemMapGrid.BorderSide.Left,QgsLayoutItemMapGrid.BorderSide.Right,QgsLayoutItemMapGrid.BorderSide.Top,QgsLayoutItemMapGrid.BorderSide.Bottom):grid.setAnnotationPosition(QgsLayoutItemMapGrid.AnnotationPosition.OutsideMapFrame,border)
        grid.setAnnotationDirection(QgsLayoutItemMapGrid.AnnotationDirection.Vertical,QgsLayoutItemMapGrid.BorderSide.Left)
        grid.setAnnotationDirection(QgsLayoutItemMapGrid.AnnotationDirection.VerticalDescending,QgsLayoutItemMapGrid.BorderSide.Right)
        x=width-margin-side;y=25
        label('QUADRO DE LEGENDA',x,y,side,9,11,True,True,True);y+=9
        legend=QgsLayoutItemLegend(layout);legend.setId('legenda_editavel');legend.setTitle('');legend.setLinkedMap(mapitem);legend.setAutoUpdateModel(False);legend.model().rootGroup().clear()
        for layer in [boundary]+overlays:legend.model().rootGroup().addLayer(layer)
        if raster.customProperty('catalogo_multiespectral_analise',''):legend.model().rootGroup().addLayer(image)
        legend.setStyleFont(QgsLegendStyle.Style.SymbolLabel,QFont('Arial',9));legend.setStyleFont(QgsLegendStyle.Style.Subgroup,QFont('Arial',9));layout.addLayoutItem(legend);legend.attemptMove(QgsLayoutPoint(x,y));legend.attemptResize(QgsLayoutSize(side,25));legend.adjustBoxSize()
        y+=max(25,legend.sizeWithUnits().height())+2
        if legend.sizeWithUnits().height()>55:raise CatalogError('Legenda extensa para a folha. Use A3 ou reduza as camadas da carta.')
        measure=QgsDistanceArea();measure.setSourceCrs(QgsCoordinateReferenceSystem('EPSG:4326'),project.transformContext());measure.setEllipsoid('GRS80')
        from qgis.core import QgsGeometry
        area=measure.measureArea(QgsGeometry.fromWkt(parcel.geometry_wkt))/10000
        status='PRODES não consultado nesta carta' if prodes_found is None else ('Sobreposição com PRODES na camada selecionada' if prodes_found else 'Sem sobreposição na camada PRODES selecionada')
        if config.get('plain') and prodes_found is None:status='Imagem e limite fornecidos pelo usuário'
        fields=[('Propriedade',property_name),('Detentor',config.get('owner','Não informado')),('Responsável técnico',config.get('technician','Não informado')),('Processamento',config.get('processor','Não informado')),('Município / UF',config.get('municipality','Não informado'))]
        remaining=height-8-y;rowheight=min(12,max(9,(remaining-45)/len(fields)))
        label(status,x,y,side,12,8,True);y+=12
        for key,value in fields:label(key+':\n'+(value or 'Não informado'),x,y,side,rowheight,8);y+=rowheight
        label('Área do imóvel: '+format(area,'.4f').replace('.',',')+' ha\nEscala 1:'+format(mapitem.scale(),',.0f').replace(',','.'),x,y,side,13,8);y+=13
        acquired=config.get('date') or str(raster.customProperty('catalogo_multiespectral_periodo','')) or str(raster.customProperty('catalogo_multiespectral_data','')) or 'Não informada'
        label('Imagem: '+acquired+'\nBandas: '+composition,x,y,side,13,8);y+=13
        label(crs.description()+'\nCoordenadas UTM em metros · '+crs.authid(),x,y,side,13,7);y+=13
        if y>height-7:raise CatalogError('Conteúdo excede a folha. Use A3 ou reduza a legenda.')
        if config.get('logo') and os.path.isfile(config['logo']) and y+15<height-7:
            import shutil
            logo_copy=os.path.join(folder,'logo'+os.path.splitext(config['logo'])[1]);shutil.copyfile(config['logo'],logo_copy)
            logo=QgsLayoutItemPicture(layout);layout.addLayoutItem(logo);logo.attemptMove(QgsLayoutPoint(x,y+1));logo.attemptResize(QgsLayoutSize(side, min(25,height-y-8)));logo.setPicturePath(logo_copy)
        import shutil
        shutil.copyfile(os.path.join(os.path.dirname(__file__),'north.svg'),os.path.join(folder,'north.svg'))
        arrow=QgsLayoutItemPicture(layout);layout.addLayoutItem(arrow);arrow.attemptMove(QgsLayoutPoint(margin+mapwidth-15,28));arrow.attemptResize(QgsLayoutSize(10,18));arrow.setPicturePath(os.path.join(folder,'north.svg'));arrow.setLinkedMap(mapitem);arrow.setNorthMode(QgsLayoutItemPicture.NorthMode.GridNorth)
        scale=QgsLayoutItemScaleBar(layout);scale.setStyle('Single Box');scale.setLinkedMap(mapitem);scale.setUnits(Qgis.DistanceUnit.Meters);scale.setUnitLabel('m');scale.setNumberOfSegments(3);scale.setNumberOfSegmentsLeft(0);scale.setUnitsPerSegment(nice_number(mapitem.extent().width()/15));scale.setFont(QFont('Arial',7));scale.setHeight(2);scale.setLabelBarSpace(.8);scale.setBoxContentSpace(.8);scale.setBackgroundEnabled(True);scale.setBackgroundColor(QColor('white'));layout.addLayoutItem(scale);scale.attemptMove(QgsLayoutPoint(margin+3,25+mapheight-10))
        label('Fonte: '+raster.name()+' · Carta editável; conferir dados, datas e interpretação.',margin,height-6,width-2*margin,4,6,False,False)
        if not project.layoutManager().addLayout(layout):raise CatalogError('Não foi possível adicionar o layout ao projeto.')
        template=os.path.join(folder,'carta_editavel.qpt')
        if not layout.saveAsTemplate(template,QgsReadWriteContext()):raise CatalogError('Falha ao salvar o modelo editável.')
        atomic_json(os.path.join(folder,'carta.json'),{'layout':name,'template':template,'crs':crs.authid(),'area_ha':area,'scale':mapitem.scale(),'raster':raster.source(),'date':acquired,'bands':composition,'status':status,'layers':[layer.name() for layer in overlays]})
        if iface:iface.openLayoutDesigner(layout)
        return {'layout':layout,'folder':folder,'template':template,'area_ha':area}
    except Exception:
        if layout and layout in project.layoutManager().layouts():project.layoutManager().removeLayout(layout)
        for identity in created:project.removeMapLayer(identity)
        raise


def export_layout(layout,path):
    exporter=QgsLayoutExporter(layout)
    if path.lower().endswith('.pdf'):
        settings=QgsLayoutExporter.PdfExportSettings();settings.dpi=300;code=exporter.exportToPdf(path,settings)
    else:
        settings=QgsLayoutExporter.ImageExportSettings();settings.dpi=300;code=exporter.exportToImage(path,settings)
    if code!=QgsLayoutExporter.ExportResult.Success:raise CatalogError('Falha na exportação da carta: '+str(code))
