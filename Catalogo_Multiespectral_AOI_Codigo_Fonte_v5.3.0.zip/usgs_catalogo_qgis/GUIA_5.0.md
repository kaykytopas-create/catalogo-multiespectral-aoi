# Guia 5.0 · classificação, séries e cartas editáveis

## Instalação e dados

Instale o ZIP QGIS da versão 5.0.1 e reabra o plugin. Requisitos: QGIS 3.40–3.99, GDAL e NumPy fornecidos pelo QGIS. O classificador local não exige conta, internet, scikit-learn, IA generativa ou instalação automática de dependências. As fontes de imagens sem login da 4.1 continuam disponíveis.

As novas abas são Classificação, Comparação temporal, Cartas-imagem e Fila de tarefas. A interface usa rolagem e as abas podem ser percorridas pelas setas do cabeçalho em telas pequenas.

## Classificar o imóvel

1. Em Imagens, escolha o limite e uma cena adequada. Confira a prévia. Na aba Bandas e análise, baixe o Band Set completo; nesta versão são preservados data, calibração e QA. Acervos anteriores podem precisar reimportar o Band Set: as bandas válidas são reutilizadas e apenas arquivos faltantes são adquiridos.
2. Em Classificação, atualize as camadas, escolha o imóvel e o Band Set. Criar amostras prepara uma camada poligonal em edição com classe, nome e uso.
3. Escolha a cobertura da próxima amostra e sua finalidade: Treinamento ou Validação independente. Use Desenhar amostra. O plugin se oculta para liberar o mapa; finalize o polígono com o botão direito, confira o formulário e reabra o plugin pelo ícone. Os campos recebem os padrões escolhidos.
4. Desenhe exemplos representativos de pelo menos duas classes. Cada classe usada precisa de polígonos separados para treino e validação, com ao menos 10 pixels válidos de treino e 5 de validação. Evite regiões encostadas e semelhantes: separar os polígonos não elimina toda a correlação espacial. O sistema rejeita sobreposição e pixels compartilhados entre treino e validação.
5. Classificar imóvel salva a tarefa na fila. Em Fila de tarefas, use Executar pendentes. A classificação é adicionada ao QGIS ao concluir. Selecione a tarefa e Abra resultado para ver o relatório.
6. Salvar amostras no acervo grava um GeoPackage. Carregar amostras permite reutilizar um arquivo com classe (inteiro de 1 a 5) e uso (treino ou validacao). Reavalie sua adequação para outro sensor, estação, região ou processamento.

Classes disponíveis: 1 floresta/cobertura arbórea; 2 pastagem; 3 agricultura; 4 água; 5 solo exposto. O nome da classe é um rótulo de cobertura espectral. Não comprova floresta primária, consolidação legal, autoria ou legalidade de uma intervenção. Não atribua uma classe que não possa reconhecer nas amostras.

## Método e resultados

Random Forest local com árvores CART, Gini, bootstrap, seleção aleatória de atributos e busca de limiares por quantis. Implementação própria com NumPy, não é o motor do SCP nem uma cópia do scikit-learn. Padrões: 48 árvores, semente 42, profundidade máxima 12, mínimo de quatro amostras por folha. Cada árvore usa até 5.000 amostras bootstrap; treino e validação usam até 2.000 pixels válidos por classe, escolhidos de maneira reproduzível. A previsão é processada por blocos.

O sistema prioriza bandas comuns refletivas (azul, verde, vermelho, NIR, SWIR1 e SWIR2), disponíveis no raster escolhido, com escala/offset arquivados. Reprojeta o recorte para UTM local, usa o limite real do imóvel e respeita máscaras de nuvem, sombra e preenchimento. Raster sem calibração ou QA não é aceito silenciosamente.

Arquivos gerados: classificacao.tif, concordancia_arvores.tif, modelo_rf.json, resultado.json e relatorio.html. O modelo JSON contém a árvore e seus parâmetros sem código executável. As assinaturas das amostras de treino são apresentadas em curvas e tabela de reflectância média.

Na classificação, 0 significa indeterminado por concordância abaixo de 60 por cento; 255 é NoData por ausência de observação válida/fora do limite. Os dois casos são contabilizados separadamente. A concordância das árvores não é probabilidade calibrada. A mesma regra de indeterminação é aplicada à validação, contando a falta de reconhecimento como erro da classe de referência.

O relatório inclui matriz de confusão (linhas referência, colunas previsão), precisão, revocação e F1 por classe, acurácia global nas amostras e áreas cartográficas por classe em hectares. As áreas seguem os centros dos pixels da grade UTM e podem divergir da área vetorial/geodésica por resolução e bordas. Pixels em polígonos são correlacionados: a validação não equivale a uma estimativa probabilística de acurácia de toda a propriedade. Não existe garantia de 80 por cento ou outra taxa.

## Comparação temporal

Selecione de duas a 60 imagens locais com bandas vermelho, NIR e SWIR2, normalmente Band Sets. Selecione as linhas na tabela usando Ctrl ou Shift. Datas ausentes podem ser preenchidas como AAAA-MM-DD; datas alteradas são registradas como informadas pelo operador. Não são aceitas datas repetidas ou inválidas.

A tarefa alinha os dados em uma grade comum na resolução suportada mais grosseira dos produtos, aplica calibração/QA e usa apenas pixels válidos comuns a todas as datas. Gera delta NDVI e delta NBR entre a primeira e a última, médias e curvas por data, área comum observada e área com queda de NDVI superior a 0,20. O limiar é exploratório, não um critério oficial INPE. Variações podem decorrer de sazonalidade, manejo, atmosfera ou sensor. Não determina causa ou dia da mudança e não preenche nuvens com pixels de outra época.

## Conferir qualidade

Em Bandas e análise, selecione uma cena em Imagens e use Conferir nuvens, sombras e cobertura no imóvel. A tarefa consulta/usa a QA e informa fração válida, clara e de nuvens no limite escolhido. A máscara não é garantia de nitidez ou ausência de falhas. A triagem automática de downloads continua usando os critérios anteriores sem relaxá-los.

## Fila e retomada

A fila fica no arquivo fila_tarefas.json dentro do acervo. Cada tarefa preserva parâmetros, geometria, amostras e entradas. Executar pendentes processa uma tarefa por vez em QgsTask; Cancelar pede encerramento cooperativo. Retomar selecionada repete a etapa interrompida, reutilizando downloads válidos. Não é uma continuação exata da árvore ou da linha raster em que houve parada.

Se bandas ou QA mudarem, a retomada é recusada e uma nova tarefa deve ser criada. Entradas e resultados têm registros de integridade. Uma fila corrompida é sinalizada sem ser apagada. Não execute simultaneamente a mesma fila em diferentes instâncias QGIS.

Na aba Imagens, Adicionar comando à fila aceita um plano de download já descrito no campo de comando. A opção de importar no QGIS é respeitada durante a execução. Investigações PRODES continuam na aba própria. A classificação exige amostras e usa a aba Classificação; ordens de download não disparam treinamento silenciosamente. O tempo exibido é o decorrido, não uma promessa de duração.

## Carta-imagem configurada e editável

1. Abra Cartas-imagem, atualize as camadas e escolha o imóvel e a imagem/classificação.
2. Escolha manter a renderização atual ou uma composição pronta de um Band Set (natural, PRODES, cicatriz ou infravermelho vegetação).
3. Marque os vetores que devem aparecer e entrar na legenda. Camadas com PRODES no nome vêm marcadas; confira a fonte e os dados. O plugin não inventa uma consulta PRODES quando uma camada não foi fornecida.
4. Confira título, propriedade, detentor, responsável técnico, processamento, município e data. Campos reconhecidos da camada podem preencher valores vazios; informações desconhecidas ficam como não informadas. A logomarca é opcional e deve ser escolhida pelo usuário.
5. Gere a carta. Ela abre no Designer de Layout e aparece no Gerenciador de layouts, acessível também pelo botão da aba. Título, textos, mapa, legenda, norte, escala, estilos e posições permanecem editáveis.
6. Exporte PDF ou PNG a 300 DPI. O modelo editável carta_editavel.qpt e vetores auxiliares GeoPackage ficam no acervo/cartas. Salve o projeto QGIS para preservar o layout e suas referências. Mantenha juntos o projeto, as bandas e o acervo ao transferir para outro computador.

O desenho segue a organização da referência do autor: faixa de título, mapa principal à esquerda e legenda/identificação à direita. Inclui limite verde, PRODES hachurado em vermelho, anos quando há campo reconhecido, área geodésica, escala calculada, norte da grade e coordenadas UTM em metros. A folha pode ser A4/A3, paisagem/retrato. No Brasil, quando aplicável, o SRC da carta é SIRGAS 2000 UTM; fora dessa regra é UTM WGS84 e o texto reflete o SRC real. Nenhuma coordenada é copiada do exemplo.

Os vetores e estilos da carta são cópias de trabalho e não substituem o estilo das camadas originais. A legenda se vincula às camadas selecionadas. Legenda que excede o quadro pede folha maior ou menos camadas, em vez de entregar conteúdo cortado. PRODES sem consulta é identificado; a ausência de interseção na camada selecionada não certifica inexistência de restrições.

## Limites desta entrega

Testada em QGIS 3.40.6/Linux. Não houve execução no Windows, ensaio em todas as versões QGIS, comparação controlada de desempenho com SCP ou validação temática de campo. Os testes computacionais não substituem a revisão do técnico e a amostragem adequada de cada caso. Os fluxos de investigação PRODES e situação ambiental anteriores permanecem como apoio, sem certificação jurídica ou fundiária.

## Acervo indisponível — correção 5.0.1

Se a unidade configurada (por exemplo, D:) não existir ou estiver sem permissão, o plugin abre usando uma pasta local alternativa gravável, se disponível, e informa isso em Imagens. A preferência original é preservada para a próxima abertura; nenhum arquivo antigo é movido. Use Imagens → Escolher pasta para fixar outra localização ou reencontrar seu acervo após reconectar a unidade. A fila e as imagens pertencem a cada pasta: uma pasta alternativa pode estar vazia, o que não significa que seu acervo antigo foi excluído.

Se nenhuma pasta permitir gravação, a interface continua acessível e as tentativas de salvar exibem a falha. Verifique permissões e escolha uma pasta válida. Uma fila corrompida é preservada para recuperação; não é substituída por uma fila vazia.
