# Catálogo Multiespectral 5.3.0

Interface compacta baseada no fluxo da versão 3.5.3. QGIS 3.40–3.99.

- Imagens: busca, NASA HLS, opções de bandas RGB e índices na mesma página.
- Situação fundiária e Analisar PRODES: abas separadas, próximas entre si.
- Carta-imagem: composição editável existente, sem novo algoritmo.

As telas secundárias só são criadas quando abertas. Não há aba separada de bandas,
fila, classificação, configuração ou comparação temporal nesta interface.
Módulos antigos continuam no código para compatibilidade e testes, sem carregamento
automático pela interface compacta. Documentos de versões anteriores são históricos.

Consulte GUIA_5.3.0.md para uso e VALIDACAO_5.3.0.md para resultados e limitações.
Pacote instalável: Catalogo_Multiespectral_AOI_QGIS_v5.3.0.zip.
Instalação manual em Complementos > Gerenciar e instalar complementos > Instalar a partir do ZIP.
Esta entrega não instala ou ativa o complemento automaticamente.

Licença GPL-2.0-or-later. Autor: Kayky Pessoa de Araujo.
