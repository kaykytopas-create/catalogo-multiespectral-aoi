# SPDX-License-Identifier: GPL-2.0-or-later
"""Simplified workflows with restored PRODES and land-status interfaces."""
from qgis.PyQt.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QPushButton,QStackedWidget,QScrollArea,
    QLabel,QComboBox,QGroupBox,QFormLayout,QDoubleSpinBox)
from qgis.core import QgsProject,QgsRasterLayer
from .plugin import CatalogDialog
from .analysis_ui import TemporalTab,raster_snapshot
from .spectral import INDEX_DEFINITIONS,band_pair
from .preflight import validate_dates
from .parcel import snapshot
from .stac import CatalogError


def image_payload(layer,index):
    value=raster_snapshot(layer)
    try:value['pair']=band_pair(value['bands'],index)
    except ValueError:raise CatalogError('A imagem '+layer.name()+' não possui as bandas para '+index.upper()+'. Baixe um Band Set completo.')
    # Sentinel Band Sets may be VRTs at 10 m although SWIR is natively 20 m.
    if value['source_info']['collection'].startswith('sentinel-2') and any(value['bands'][n-1] in ('B11','B12','swir16','swir22') for n in value['pair']):
        value['resolution']=max(20,value['resolution'])
    return value


class WaterTemporalTab(TemporalTab):
    def __init__(self,owner):
        super().__init__(owner)
        self.layout().itemAt(0).widget().setText('Escolha o imóvel e duas ou mais datas com Ctrl. Selecione o que deseja comparar e clique em Comparar. O processamento usa somente pixels válidos comuns.')
        self.index=QComboBox()
        for key in ('ndwi','mndwi','ndmi','ndti','ndvi','nbr'):self.index.addItem(INDEX_DEFINITIONS[key][0],key)
        self.threshold=QDoubleSpinBox();self.threshold.setRange(-1,1);self.threshold.setDecimals(2);self.threshold.setSingleStep(.05)
        form=QFormLayout();form.addRow('O que comparar:',self.index);form.addRow('Limiar exploratório de água (índice >):',self.threshold)
        self.layout().insertLayout(2,form)
        self.index.currentIndexChanged.connect(self.explain);self.explain()
        for button in self.findChildren(QPushButton):
            if button.text().startswith('Comparar datas'):button.setText('Comparar datas selecionadas')
    def explain(self):
        key=self.index.currentData();self.threshold.setEnabled(key in ('ndwi','mndwi'))
        self.info.setText(INDEX_DEFINITIONS[key][3]+' Resultado: mapa de diferença, relatório e tabela CSV.')
    def run(self):
        try:
            parcel=self.parcel.resolve();rows=sorted({i.row() for i in self.table.selectedIndexes()})
            validate_dates([{'date':self.table.item(i,0).text().strip()} for i in rows])
            images=[];index=self.index.currentData()
            for i in rows:
                value=image_payload(self.layers[i],index);date=self.table.item(i,0).text().strip()
                value['source_info']['date_origin']='metadados do catálogo' if date==value['date'] else 'informada pelo operador'
                value['date']=date;value['source_info']['date']=date;images.append(value)
            images.sort(key=lambda x:x['date'])
            payload={'images':images,'index':index,'geometry':parcel.geometry_wkt,'rect':list(parcel.rect),'water_threshold':self.threshold.value(),'mode':'temporal'}
            if self.owner.queue_tab.enqueue('temporal_index',payload):self.owner.queue_tab.start()
        except Exception as exc:self.info.setText(str(exc))


class SimpleCatalogDialog(CatalogDialog):
    def __init__(self,iface,parent=None):
        super().__init__(iface,parent)
        self.simple_mode=True;self.hydro_job=None;self.allowed_queue_actions={'temporal_index','spectral'}
        self.setWindowTitle('Catálogo Multiespectral 5.3.1 · Bandas, água, PRODES e cartas')
        while self.tabs.count():self.tabs.removeTab(0)
        self.command_box.hide();self.sync_button.hide()
        for group in self.analysis_scroll.findChildren(QGroupBox):
            if group.title().startswith('Atalhos de composição'):
                group.setTitle('Atalhos de composição · somente selecionar bandas')
        self.false_color.setText('Vegetação / umidade')
        idx=self.cartography_tab.preset.findData('prodes')
        if idx>=0:self.cartography_tab.preset.setItemText(idx,'Vegetação / umidade · SWIR1/NIR/vermelho')
        self.tabs.setUsesScrollButtons(True)
        bands=QWidget();layout=QVBoxLayout(bands);row=QHBoxLayout()
        self.steps=QStackedWidget()
        for i,(title,page) in enumerate([('1. Buscar imagens',self.imagery_page),('2. Bandas e água',self.analysis_scroll),('3. Acervo local',self.archive_tab)]):
            self.steps.addWidget(page);button=QPushButton(title);button.clicked.connect(lambda checked=False,n=i:self.show_step(n));row.addWidget(button)
        layout.addLayout(row);layout.addWidget(self.steps)
        self.imagery_page.layout().removeWidget(self.info);layout.addWidget(self.info)
        self.tabs.addTab(bands,'Bandas e análise')
        self.temporal_tab=WaterTemporalTab(self)
        self.temporal_tab.layout().addWidget(QLabel('Andamento e resultados das análises:'))
        self.queue_tab.setMinimumHeight(190);self.temporal_tab.layout().addWidget(self.queue_tab)
        for title,tab in [('Comparação temporal',self.temporal_tab),('Carta-imagem',self.cartography_tab)]:
            scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(tab);self.tabs.addTab(scroll,title)
        self.tabs.addTab(self.environmental_scroll,'Situação fundiária')
        self.tabs.addTab(self.prodes_scroll,'Analisar PRODES')
        # Keep initial choices shared; a user may choose another parcel explicitly.
        self.layer_box.currentIndexChanged.connect(self.share_parcel)
        self.tabs.currentChanged.connect(self.refresh_current)
        self.share_parcel()
        content=self.analysis_scroll.widget().layout()
        content.insertWidget(0,self.local_analysis_box())
        content.insertWidget(1,self.water_source_box())
        content.removeWidget(self.bandset_button);content.insertWidget(0,self.bandset_button)
        self.bandset_button.setText('Imagem da busca → baixar Band Set completo (recomendado)')
        apply=QPushButton('Prévia e importar a opção de bandas escolhida')
        apply.clicked.connect(self.import_scene)
        for n in range(content.count()):
            widget=content.itemAt(n).widget()
            if isinstance(widget,QGroupBox) and widget.title().startswith('Composição RGB'):
                content.insertWidget(n+1,apply);break
        for label in self.analysis_scroll.findChildren(QLabel):
            label.setText(label.text().replace('em Imagens','em 1. Buscar imagens'))
        self.queue_tab.refresh();self.refresh_local()
        for button in self.imagery_page.findChildren(QPushButton):
            if button.text().startswith('Composições e índices'):
                button.clicked.disconnect();button.clicked.connect(lambda:self.show_step(1))
        self.info.setText('Escolha o imóvel e o período; busque e selecione uma cena. Depois abra 2. Bandas e água. Downloads ficam no acervo.')

    def show_step(self,index):
        self.tabs.setCurrentIndex(0);self.steps.setCurrentIndex(index)
        if index==1:self.refresh_local()
    def show_queue(self):self.tabs.setCurrentIndex(1)
    def show_prodes(self):
        self.tabs.setCurrentWidget(self.prodes_scroll)
        self.show();self.raise_();self.activateWindow()
    def share_parcel(self):
        identity=self.layer_box.currentData()
        for tab in (self.temporal_tab,self.cartography_tab):
            tab.parcel.refresh();idx=tab.parcel.combo.findData(identity)
            if idx>=0:tab.parcel.combo.setCurrentIndex(idx);tab.parcel._explicit=True
        for widget,combo in ((self.environmental_tab,self.environmental_tab.parcel),(self.prodes_dialog,self.prodes_dialog.property_box)):
            widget.refresh_layers();idx=combo.findData(identity)
            if idx>=0:combo.setCurrentIndex(idx)
    def refresh_current(self,index):
        if index==1:self.temporal_tab.refresh()
        elif index==2:self.cartography_tab.refresh()
        elif index==3:self.environmental_tab.refresh_layers()
    def choose_analysis_preset(self,preset):
        if self.job:
            return
        index = self.preset.findData(preset)
        if index < 0:
            self.info.setText('Selecione uma cena em 1. Buscar imagens primeiro.')
            return
        self.preset.setCurrentIndex(index)
        self.show_step(1)
        self.info.setText('Bandas selecionadas. Confira a composição e clique em Prévia e importar para baixar.')
    def selection_changed(self):
        super().selection_changed();self.false_color.setText('Vegetação / umidade')
    def workers(self):return super().workers()+([self.hydro_job] if getattr(self,'hydro_job',None) else [])

    def local_analysis_box(self):
        box=QGroupBox('Água e vegetação · analisar uma imagem já baixada');form=QFormLayout(box)
        self.local_raster=QComboBox();self.local_index=QComboBox()
        for key in ('ndwi','mndwi','ndmi','ndti','ndvi','nbr'):self.local_index.addItem(INDEX_DEFINITIONS[key][0],key)
        form.addRow('Band Set no projeto:',self.local_raster);form.addRow('Índice:',self.local_index)
        self.local_note=QLabel();self.local_note.setWordWrap(True);form.addRow(self.local_note)
        self.local_index.currentIndexChanged.connect(lambda:self.local_note.setText(INDEX_DEFINITIONS[self.local_index.currentData()][3]))
        self.local_note.setText(INDEX_DEFINITIONS['ndwi'][3])
        row=QHBoxLayout();refresh=QPushButton('Atualizar imagens');refresh.clicked.connect(self.refresh_local);run=QPushButton('Calcular índice e abrir no QGIS');run.clicked.connect(self.run_local)
        row.addWidget(refresh);row.addWidget(run);form.addRow(row);return box
    def refresh_local(self):
        current=self.local_raster.currentData();self.local_raster.clear()
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer,QgsRasterLayer) and layer.customProperty('catalogo_multiespectral_espectral','') and not layer.customProperty('catalogo_layout_aux',False):self.local_raster.addItem(layer.name(),layer.id())
        idx=self.local_raster.findData(current)
        if idx>=0:self.local_raster.setCurrentIndex(idx)
    def run_local(self):
        try:
            parcel=snapshot(QgsProject.instance().mapLayer(self.layer_box.currentData()));key=self.local_index.currentData()
            image=image_payload(QgsProject.instance().mapLayer(self.local_raster.currentData()),key)
            payload={'images':[image],'index':key,'geometry':parcel.geometry_wkt,'rect':list(parcel.rect),'mode':'single'}
            if self.queue_tab.enqueue('spectral',payload):self.queue_tab.start()
        except Exception as exc:self.local_note.setText(str(exc))

    def water_source_box(self):
        from .jrc_water import PRODUCTS
        box=QGroupBox('Nova fonte do acervo · água histórica JRC');form=QFormLayout(box)
        self.water_product=QComboBox()
        for key,title in PRODUCTS.items():self.water_product.addItem(title,key)
        form.addRow('Variável histórica:',self.water_product)
        self.water_note=QLabel('EC JRC/Google · dados agregados de 1984–2024, cerca de 30 m. Não são imagens atuais nem bandas para índices. O recorte usa o imóvel escolhido em Buscar imagens.');self.water_note.setWordWrap(True);form.addRow(self.water_note)
        row=QHBoxLayout();self.water_download=QPushButton('Baixar recorte e adicionar ao QGIS');self.water_download.clicked.connect(self.download_water)
        cancel=QPushButton('Cancelar download');cancel.clicked.connect(lambda:self.hydro_job.cancel() if self.hydro_job else None)
        row.addWidget(self.water_download);row.addWidget(cancel);form.addRow(row)
        links=QLabel('<a href="https://global-surface-water.appspot.com/download">JRC: dados e metodologia</a> · <a href="https://browser.dataspace.copernicus.eu/">Copernicus Browser</a> · <a href="https://earthexplorer.usgs.gov/">USGS EarthExplorer</a>')
        links.setOpenExternalLinks(True);links.setWordWrap(True);form.addRow(links)
        note=QLabel('Copernicus e USGS são portais externos; podem exigir cadastro. A busca integrada continua usando Microsoft, INPE e AWS.');note.setWordWrap(True);form.addRow(note)
        return box
    def download_water(self):
        from .jrc_water import JrcWorker
        try:
            if self.hydro_job:return
            parcel=snapshot(QgsProject.instance().mapLayer(self.layer_box.currentData()))
            self.hydro_job=JrcWorker(self.archive_path,list(parcel.rect),self.water_product.currentData(),self.offline.isChecked())
            self.hydro_job.status.connect(self.water_note.setText);self.hydro_job.failed.connect(self.water_note.setText)
            self.hydro_job.result.connect(self.got_water);self.hydro_job.done.connect(self.water_finished)
            self.water_download.setEnabled(False);self.hydro_job.start()
        except Exception as exc:self.water_note.setText(str(exc));self.water_finished()
    def water_finished(self):self.hydro_job=None;self.water_download.setEnabled(True)
    def got_water(self,result):
        from .jrc_water import style
        layer=QgsRasterLayer(result['path'],result['name'],'gdal')
        if not layer.isValid():self.water_note.setText('O recorte não pôde ser aberto.');return
        layer.setCustomProperty('catalogo_multiespectral_periodo',result['period']);layer.setCustomProperty('catalogo_multiespectral_bandas',result['product']+' · EC JRC/Google')
        style(layer,result['product']);layer.saveNamedStyle(result['path']+'.qml');QgsProject.instance().addMapLayer(layer)
        self.water_note.setText('Recorte salvo no acervo e adicionado ao QGIS. '+result['note'])
