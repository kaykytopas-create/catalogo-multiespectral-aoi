# Correção 5.3.1 — 26/11/2026

## Causa reproduzida

Uma consulta ao Microsoft Planetary Computer com landsat-c2-l2, sentinel-2-l2a,
hls2-l30 e hls2-s30 retornou HTTP 400:
Cross-collection searches require all collections to use the same backend.
Isso descartava o grupo Microsoft/USGS/NASA, enquanto INPE e AWS eram independentes.
Não havia no código um corte fixo em 1990. O desaparecimento da fonte Landsat da
Microsoft explica a perda de parte do histórico. A disponibilidade varia por imóvel.

## Correções

- Requisições e cursores independentes para cada coleção Microsoft; falha isolada
  não descarta resultados das demais coleções. Aplicado também às consultas de apoio.
- Busca por ano/fonte, datas respeitadas, retomada por cursor, até seis páginas por
  etapa e orçamento de 20 segundos entre requisições (uma chamada já iniciada pode
  aguardar o timeout HTTP de até 45 segundos). Sem ampliar nuvens silenciosamente.
- Primeira página de cada ano/fonte tem prioridade sobre páginas seguintes. Falhas
  são repetidas uma vez e permanecem marcadas como falha se não houver recuperação.
- Suavização voltou à página Imagens; estava em controles ocultos na versão compacta.
- Contraste automático amostrado em segundo plano, com intervalo físico comum em
  cor natural e exclusão de preenchimento/saturação Landsat do cálculo de contraste.
- Mantidos downloads sequenciais, quatro abas, carregamento sob demanda e cancelamento.

## Validação

314 testes passaram no QGIS 3.44.7/Python 3.12, Windows, processo e configurações
isolados. Sem falhas, erros ou ignorados. Incluem regressão de consulta entre backends,
paginação independente, múltiplos anos, retomada, falha/repetição, cancelamento,
suavização, preservação dos pixels e contraste sem saturação.
O teste antigo de fechamento foi sincronizado por eventos: antes dependia de o worker
começar antes do cancelamento, o que tornava a asserção dependente do escalonamento.
Temporários de teste foram direcionados a uma pasta curta do workspace para evitar
o limite de caminho Windows e o caractere # no caminho temporário do sandbox.
Bandit padrão: zero apontamentos/erros. Flake8: zero nas regras
F,E711,E712,E713,E714,E721,E722,E731,E741,E742,E743,E9.
ZIPs verificados por CRC, sintaxe, metadados e equivalência do conteúdo do plugin.

Consultas reais pelo cliente QGIS na área de teste [-50,-7,-49.99,-6.99] WGS84:
- 1985: 3 cenas Landsat/USGS pela Microsoft; INPE retornou zero nessa área/ano.
- 2023: 30 Landsat, 29 Sentinel Microsoft, 11 HLS L30, 14 HLS S30, 39 INPE;
  AWS retornou 17 na primeira página, com paginação ainda disponível.
Contagens por fonte precedem deduplicação e o filtro opcional de Landsat 7 da interface.
Não são contagens garantidas para outro imóvel ou para futuras atualizações dos catálogos.
Uma cena real de 1985 foi baixada e composta em RGB (147 x 89 pixels), sem erros,
com estilo de contraste automático e suavização aplicado em processo separado.

Não houve instalação no perfil, alteração do projeto aberto ou transferência do acervo.
Esta correção não reproduz nem certifica a eliminação de todas as possíveis quedas nativas
do QGIS. experimental=False é mantido; não significa homologação pelo repositório QGIS.

Referências técnicas:
https://planetarycomputer.microsoft.com/docs/changelogs/history
https://www.usgs.gov/landsat-missions/landsat-collection-2-level-2-science-products
