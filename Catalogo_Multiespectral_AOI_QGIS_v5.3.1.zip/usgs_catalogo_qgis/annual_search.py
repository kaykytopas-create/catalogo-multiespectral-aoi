# SPDX-License-Identifier: GPL-2.0-or-later
"""Bounded year/source discovery, with explicit incomplete and failed searches."""
import copy
import time
from datetime import date
from .stac import CatalogError,search_payload
from .public_sources import SearchResults,merge_scenes


def search_years(client,collections,rect,start,end,next_link=None,progress=lambda message:None):
    search_payload(collections,rect,start,end)
    first,last=date.fromisoformat(start),date.fromisoformat(end)
    if first>last:raise CatalogError('Período de pesquisa inválido.')
    if last.year-first.year>100:raise CatalogError('Pesquise até 100 anos por vez.')
    signature=[list(collections),list(rect),start,end]
    if next_link is None:
        queue=[];report={}
        for year in range(first.year,last.year+1):
            begin=max(start,f'{year:04d}-01-01');finish=min(end,f'{year:04d}-12-31')
            for source in client.streams(collections):
                key=f'{year}|{source}'
                queue.append({'key':key,'source':source,'start':begin,'end':finish,'link':None,'retry':0})
                report[key]={'year':year,'source':source,'count':0,'state':'pending'}
        state={'catalog:annual':1,'signature':signature,'queue':queue,'report':report}
    else:
        if next_link.get('catalog:annual')!=1 or next_link.get('signature')!=signature:
            raise CatalogError('O período ou a área mudou; refaça a busca.')
        state=copy.deepcopy(next_link)
    items=[];started=time.monotonic()
    # Each click advances at most six catalog pages, never downloading imagery.
    for _ in range(6):
        if client.cancelled():raise CatalogError('Operação cancelada.')
        if not state['queue'] or (time.monotonic()-started>20):break
        task=state['queue'].pop(0);entry=state['report'][task['key']]
        progress(f"Buscando {entry['year']} · {task['source']}…")
        try:
            page,nxt=client.search_stream(task['source'],collections,rect,task['start'],task['end'],task['link'])
            # Guard against a service ignoring temporal constraints.
            page=[i for i in page if task['start']<=str(i.get('properties',{}).get('datetime',''))[:10]<=task['end']]
            items.extend(page);entry['count']+=len(page);entry.pop('error',None)
            entry['state']='partial' if nxt else 'complete'
            if nxt:
                if nxt==task['link']:raise CatalogError('A fonte repetiu o cursor de paginação.')
                state['queue'].append(dict(task,link=nxt,retry=0))
        except Exception as exc:
            if client.cancelled():raise CatalogError('Operação cancelada.') from exc
            entry['state']='failed';entry['error']=str(exc)
            if task['retry']==0:state['queue'].append(dict(task,retry=1))
    warnings=[f"{r['year']} · {r['source']}: {r['error']}" for r in state['report'].values() if r.get('error')]
    result=SearchResults(merge_scenes(items),warnings)
    result.year_report=state['report']
    result.remaining=len(state['queue'])
    return result,state if state['queue'] else None
