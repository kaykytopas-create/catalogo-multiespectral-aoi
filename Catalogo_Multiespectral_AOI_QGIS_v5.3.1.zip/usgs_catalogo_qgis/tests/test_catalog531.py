# SPDX-License-Identifier: GPL-2.0-or-later
import unittest
import tempfile
from unittest.mock import Mock,patch
import numpy as np
from osgeo import gdal
from qgis.core import QgsRasterLayer
from usgs_catalogo_qgis.public_sources import MultiCatalog
from usgs_catalogo_qgis.stac import CatalogError
from usgs_catalogo_qgis.light_ui import LightCatalogDialog
from usgs_catalogo_qgis.plugin import CatalogDialog,Job
from usgs_catalogo_qgis.display_prepare import prepare_display
from usgs_catalogo_qgis.tests.test_presets_quality import scene

RECT=[-50,-7,-49.99,-6.99]


def item(year,identifier='scene'):
    return {'id':identifier,'collection':'landsat-c2-l2','properties':{'datetime':f'{year}-06-01T00:00:00Z','eo:cloud_cover':1}}


class Catalog531Tests(unittest.TestCase):
    def test_cross_backend_search_is_never_sent_and_cursors_are_independent(self):
        client=MultiCatalog();calls=[]
        def request(url,payload=None):
            calls.append((url,payload))
            self.assertEqual(len(payload['collections']),1)
            collection=payload['collections'][0]
            if collection=='hls2-s30':raise CatalogError('collection unavailable')
            links=[] if payload.get('token') else [{'rel':'next','href':url,'method':'POST','merge':True,'body':{'token':collection}}]
            return {'type':'FeatureCollection','features':[],'links':links}
        client.json_request=request
        with patch.object(client,'search_inpe',return_value=([],None)):
            result,token=client.search(['landsat-c2-l2','sentinel-2-l2a','hls2-s30'],RECT,'2023-01-01','2023-12-31')
            self.assertEqual(len(token['streams']),2);self.assertIn('hls2-s30',result.warnings[0])
            _,end=client.search(['landsat-c2-l2','sentinel-2-l2a','hls2-s30'],RECT,'2023-01-01','2023-12-31',token)
            self.assertIsNone(end)
        self.assertEqual(len(calls),5)

    def test_year_intervals_and_bounded_resumable_paging(self):
        client=MultiCatalog();client.streams=lambda collections:['pc:landsat-c2-l2']
        calls=[]
        def query(source,collections,rect,start,end,link):
            calls.append((start,end,link))
            return [item(start[:4],start)],None
        client.search_stream=query
        result,token=client.search_years(['landsat-c2-l2'],RECT,'1982-05-01','1990-06-02')
        self.assertEqual(len(calls),6);self.assertIsNotNone(token)
        self.assertEqual(calls[0][:2],('1982-05-01','1982-12-31'))
        more,token=client.search_years(['landsat-c2-l2'],RECT,'1982-05-01','1990-06-02',token)
        self.assertIsNone(token);self.assertEqual(len(result)+len(more),9)
        self.assertEqual(calls[-1][:2],('1990-01-01','1990-06-02'))

    def test_pagination_does_not_starve_other_years(self):
        client=MultiCatalog();client.streams=lambda collections:['pc:landsat-c2-l2']
        calls=[]
        def query(source,collections,rect,start,end,link):
            calls.append((start,link))
            return [item(start[:4],start+str(link))],None if link else {'cursor':'second'}
        client.search_stream=query
        result,token=client.search_years(['landsat-c2-l2'],RECT,'1985-01-01','1986-12-31')
        self.assertIsNone(token);self.assertEqual(len(result),4)
        self.assertEqual([v[0][:4] for v in calls[:2]],['1985','1986'])

    def test_failures_retry_once_and_never_mean_no_images(self):
        client=MultiCatalog();client.streams=lambda collections:['pc:landsat-c2-l2']
        client.search_stream=Mock(side_effect=CatalogError('HTTP 503'))
        result,token=client.search_years(['landsat-c2-l2'],RECT,'1985-01-01','1985-12-31')
        self.assertIsNone(token);self.assertEqual(client.search_stream.call_count,2)
        self.assertEqual(next(iter(result.year_report.values()))['state'],'failed')
        self.assertIn('503',result.warnings[0])

    def test_wrong_year_and_changed_query_are_rejected(self):
        client=MultiCatalog();client.streams=lambda collections:['pc:landsat-c2-l2']
        client.search_stream=Mock(return_value=([item(2023)],None))
        result,token=client.search_years(['landsat-c2-l2'],RECT,'1985-01-01','1992-12-31')
        self.assertEqual(result,[])
        with self.assertRaises(CatalogError):client.search_years(['landsat-c2-l2'],RECT,'1986-01-01','1992-12-31',token)
        client.cancelled=lambda:True
        with self.assertRaisesRegex(CatalogError,'cancelada'):client.search_years(['landsat-c2-l2'],RECT,'1985-01-01','1985-12-31')

    def test_compact_controls_visible_and_year_job_routes_to_discovery(self):
        dialog=LightCatalogDialog(None)
        try:
            self.assertTrue(dialog.imagery_page.isAncestorOf(dialog.smooth_rgb))
            self.assertTrue(dialog.imagery_page.isAncestorOf(dialog.auto_display))
            self.assertTrue(dialog.auto_display.isChecked())
            with patch.object(dialog,'import_scene') as download:
                dialog.smooth_rgb.setChecked(True);dialog.auto_display.setChecked(False)
                download.assert_not_called()
        finally:dialog.close()
        job=Job('search',yearwise=True,collections=['landsat-c2-l2'],rect=RECT,start='1985-01-01',end='1985-12-31')
        with patch('usgs_catalogo_qgis.plugin.PublicCatalog.search_years',return_value=([],None)) as search:
            job.work();search.assert_called_once()

    def test_automatic_natural_color_preserves_pixels_and_common_physical_limits(self):
        with tempfile.TemporaryDirectory() as root:
            path=root+'/rgb.tif'
            ds=gdal.GetDriverByName('GTiff').Create(path,20,20,3,gdal.GDT_UInt16)
            ds.SetGeoTransform((-50,.001,0,-7,0,-.001));ds.SetProjection('EPSG:4326')
            arrays=[]
            for n in (1,2,3):
                data=(np.arange(400).reshape(20,20)+8000+n*200).astype('uint16');data[0,0]=0;data[1:4,:]=65535;arrays.append(data)
                band=ds.GetRasterBand(n);band.WriteArray(data);band.SetNoDataValue(0)
            band=None;ds=None
            raw=scene();raw['collection']='landsat-c2-l2'
            prepared=prepare_display(path,item=raw,keys=('red','green','blue'))
            self.assertTrue(prepared['automatic'])
            self.assertEqual(prepared['limits']['1'],prepared['limits']['3'])
            self.assertLess(prepared['limits']['1'][1],10000)
            layer=QgsRasterLayer(path,'test','gdal')
            CatalogDialog.configure_rgb(layer,True,raw,('red','green','blue'),prepared_limits=prepared['limits'],automatic=True)
            self.assertIsNotNone(layer.resampleFilter().zoomedInResampler())
            self.assertAlmostEqual(layer.renderer().redContrastEnhancement().minimumValue(),prepared['limits']['1'][0])
            layer=None;ds=gdal.Open(path)
            for n in (1,2,3):np.testing.assert_array_equal(ds.GetRasterBand(n).ReadAsArray(),arrays[n-1])
            ds=None
