# Publicação 5.3.1

Metadados e documentação atualizados. experimental=False. Validação local em VALIDACAO_5.3.1.md; nenhum envio ao repositório realizado.
