# Catálogo Multiespectral 5.3.1

Busca de imagens por ano, com consultas independentes para Landsat/USGS, Sentinel-2,
NASA HLS via Microsoft, INPE e AWS. Corrige a rejeição HTTP 400 por mistura de backends.
Bandas, suavização e tratamento automático de contraste na primeira página.
Mantém quatro abas compactas: Imagens, Situação fundiária, Analisar PRODES e Carta-imagem.

QGIS 3.40–3.99; GPL-2.0-or-later. Autor: Kayky Pessoa de Araujo.
Leia GUIA_5.3.1.md e VALIDACAO_5.3.1.md. Documentos de outras versões são históricos.
