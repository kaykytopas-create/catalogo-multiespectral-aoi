# Catálogo Multiespectral 5.3.1 — uso

Instale Catalogo_Multiespectral_AOI_QGIS_v5.3.1.zip pelo menu Complementos >
Gerenciar e instalar complementos > Instalar a partir do ZIP. O ZIP de código-fonte
é destinado à manutenção. Esta entrega não instala nem reativa automaticamente o plugin.

Na página Imagens:
1. Escolha o limite do imóvel e confira a pasta do acervo.
2. Marque Landsat, Sentinel-2 e NASA HLS conforme a pesquisa desejada.
3. Em Ir para o ano, selecione o ano solicitado. Para vários anos, ajuste De/até.
4. Clique em Buscar imagens. A consulta separa cada ano e cada catálogo, sem misturar
   coleções da Microsoft numa requisição incompatível.
5. Quando aparecer Busca parcial, clique em Continuar busca por ano / próximas cenas.
   Cada etapa consulta até seis páginas de catálogo, em segundo plano, com cancelamento.
   Intervalos extensos exigem mais etapas. A busca não baixa todas as imagens.
6. O rodapé mostra anos encontrados e consultas pendentes. Passe o mouse sobre ele
   para ver o resultado por ano/fonte. Falha de fonte não significa ausência de imagens.
7. Selecione uma cena e escolha Opção de bandas na mesma página.
8. Marque Suavizar pixels na visualização RGB, se desejar. Tratamento automático de
   contraste RGB já vem marcado. Clique em Prévia e importar para aplicar à nova composição.

A suavização atua na exibição e nas cartas que usam essa camada. O tratamento estima
os percentis 2 e 98 de uma amostra de até 512 x 512 pixels por banda em segundo plano.
Cor natural usa um intervalo comum de reflectância nos três canais, preservando a
relação entre as cores. Outras composições usam contraste por canal. Valores NoData
e DN Landsat fora da faixa válida 1–65455 não entram no cálculo automático.
Desmarcar o tratamento mantém a apresentação padrão: intervalo fixo em cor natural
e contraste usual nas outras combinações. As bandas originais e os índices não são
reescritos por essas opções. Não há remoção artificial de nuvens nem aumento de resolução.

O filtro de nuvens da cena permanece abaixo de 20 por cento. A ocultação de Landsat 7
SLC-off continua opcional. Ausência de imagens sob esses filtros não prova ausência
no catálogo completo. NASA e Sentinel não possuem imagens dos anos 1980; para esses
anos, mantenha Landsat selecionado. AOI significa área de interesse, não uma fonte.

Situação fundiária, Analisar PRODES e Carta-imagem permanecem nas outras três abas.
