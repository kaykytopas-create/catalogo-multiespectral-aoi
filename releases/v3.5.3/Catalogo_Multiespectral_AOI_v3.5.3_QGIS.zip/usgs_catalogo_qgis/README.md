## Atualização 3.5.3

Botão de prévia/importação maior, destacado e sempre visível no rodapé da aba de imagens. Atalho Alt+I, controles com rolagem e tamanho inicial adaptado à tela. A confirmação da prévia permanece antes da importação.

# Correção 3.5.2 — apontamentos Flake8

Corrigidos os seis itens de qualidade apresentados pelo verificador de publicação: quatro E731 (funções de formatação), um F811 (importação duplicada) e um E741 (nome de variável ambíguo). Também removidas importações sem uso. Nenhuma regra foi ocultada por comentário de supressão ou configuração do verificador. Leia [VALIDACAO_3.5.2.md](VALIDACAO_3.5.2.md).

# Correção 3.5.1 — validação para publicação

Corrigidos os quatro apontamentos de compatibilidade Qt/QGIS, os dois alertas de exceções silenciosas e a chave pública DataJud embutida. A consulta judicial obtém a chave no portal oficial CNJ ou usa o valor informado na sessão, sem persistência. 205 testes passaram no QGIS 3.34.4; Bandit e detect-secrets sem apontamentos na verificação local. Leia [VALIDACAO_3.5.1.md](VALIDACAO_3.5.1.md). Reenvie o ZIP 3.5.1 ao verificador do repositório.

# Catálogo Multiespectral AOI 3.5 — consulta ambiental e fundiária

Nova aba separada para situação do CAR, embargos, processos associados, consulta judicial por número CNJ e registros fundiários do acervo ITERPA para o Pará. Consultas em paralelo com orçamento de cinco minutos, relatório HTML, evidências JSON/CSV e exportação PDF. Leia [GUIA_3.5.md](GUIA_3.5.md), [VALIDACAO_3.5.md](VALIDACAO_3.5.md) e [PUBLICACAO.md](PUBLICACAO.md). Versão experimental: não certifica domínio, regularidade ou ausência de todos os processos públicos.

**English:** A separate public environmental and land-tenure screening tab complements the imagery catalog. SICAR, IBAMA, ICMBio, SEMAS/PA and exact-number CNJ/DataJud queries are bounded by a five-minute consultation budget. ITERPA land layers cover Para only. Read-only requests, traceable partial results, brief reports and PDF export; no general legal or ownership clearance.

# Catálogo Multiespectral AOI 3.4 — USGS e INPE/Brazil Data Cube

Nova fonte pública Landsat Collection 2 Level-2, sem conta, integrada ao catálogo manual, aos comandos de download e à aquisição da investigação PRODES. Unifica espelhos do mesmo produto, tenta outra hospedagem quando uma banda falha e preserva origem e avisos de consulta parcial. Leia [GUIA_3.4.md](GUIA_3.4.md) e [VALIDACAO_3.4.md](VALIDACAO_3.4.md). Versão experimental; disponibilidade anual e resolução continuam limitadas pelos dados existentes.

# Catálogo Multiespectral AOI 3.3 — qualidade e alternativas anuais

Cor natural com contraste radiométrico comum, seleção automática com QA no imóvel e tentativas de datas alternativas do mesmo ano. Argumentação por UUID para revisão temporal, temática e espacial e ferramenta de avaliação da meta de acurácia. Leia [GUIA_3.3.md](GUIA_3.3.md) e [VALIDACAO_3.3.md](VALIDACAO_3.3.md). Não promete imagens ausentes na fonte nem relaxa critérios. Preparada localmente; versão experimental.

# Catálogo Multiespectral AOI 3.2 — execução por comandos

O comando agora inicia a aquisição e pode adicionar cada raster concluído ao QGIS ou salvar somente no acervo, respeitando período, composição e filtro de nuvens. Use **Executar comando**. Leia [GUIA_3.2.md](GUIA_3.2.md) e [VALIDACAO_3.2.md](VALIDACAO_3.2.md). Versão experimental, preparada localmente; não publicada por esta atualização.

# Catálogo Multiespectral AOI 3.1 — imagens e investigação PRODES

O botão principal abre novamente o catálogo manual, com bandas e prévia georreferenciada. A investigação PRODES está disponível pelo botão superior e pelo menu Raster. Comandos de tarefa permitem preparar buscas/downloads ou iniciar investigação, sem depender do Ollama. Leia [GUIA_3.1.md](GUIA_3.1.md) para os comandos aceitos e os limites de qualidade.

# Catálogo Multiespectral AOI — Investigação Ambiental 3.0 experimental

**Nova central de investigação:** planeja por polígono, seleciona cenas pela QA local, busca datas intermediárias com orçamento, organiza hipóteses e orientação oficial, produz cartas UTM com contraste comparável e gera o pacote automaticamente. Interpretação visual opcional via modelo multimodal Ollama local; não inclui pesos nem precisão temática validada. Consulte [o guia 3.0](GUIA_3.0.md).

**Argumentação 2.3.2:** justificativa por polígono com áreas, proporção da consolidada, datas úteis, amostra, lacunas, limites da mudança de data, possíveis incêndios e fundamento técnico/legal. Preserva os resultados calculados e diferencia indicação documental de divergência demonstrada pelas imagens.

**Correção anterior 2.3.1:** o botão de análise agora pesquisa o histórico anterior e posterior. A comparação manual é identificada separadamente. O relatório informa quando o histórico não foi pesquisado e preserva a proporção dos mapas no PDF.

**New in 2.3 experimental:** automatic two-vector workflow, historical before/after evidence (1985 by default through Y+2), candidate observation intervals for date review, exploratory NBR/dNBR disturbance and recovery screening, readable per-polygon recommendations and actual embedded maps in PDF/HTML. See [the 2.3 guide](GUIA_2.3.md). Independent thematic validation is still required; first observed change is not proof of first clearance or fire causation.

**Introduced in 2.2 experimental:** first-stage automatic Landsat acquisition and maps, Y/Y−1/Y−2 per PRODES year, local archive reuse, technical consolidated-area overlap and preliminary contestability. See [the 2.2 guide](GUIA_2.2.md).

**Introduced in 2.1 experimental:** automatic calibrated NDVI/NDMI screening of three dates inside parcel/PRODES intersections; local cloud, shadow and saturation masks; conservative coverage rules; independent agree/disagree review; technical/legal context and PDF/PNG/GeoPackage export. This is an explainable rule engine, not trained AI or an official false-PRODES/legal decision. QGIS 3.34.4 worker processing and full report export passed with synthetic imagery; classification accuracy has not been measured. See [the automatic analysis guide](GUIA_2.1.md).

**English summary:** Search anonymous Landsat Collection 2 Level-2 and Sentinel-2 Level-2A scenes by a parcel polygon, filter scene cloud cover below 20%, preview imagery with the parcel boundary, select RGB bands, calculate NDVI and maintain a local offline archive. No account is required. QGIS 3.22–3.99, GDAL Python and NumPy are required. New downloads need internet. Experimental release; see [publication preparation](PUBLICACAO.md).

Pesquisa imagens Landsat USGS Collection 2 Level-2 e Sentinel-2 Level-2A sem conta. Usa o STAC público do Microsoft Planetary Computer, recorta o imóvel com entorno, permite escolher bandas RGB e calcular NDVI. Agora inclui prévia georreferenciada e acervo permanente para uso offline.

## Instalação

No QGIS 3.22 a 3.99: **Complementos → Gerenciar e Instalar Complementos → Instalar a partir de ZIP**. Abra pelo menu **Raster → Catálogo Multiespectral**. O pacote não declara compatibilidade com QGIS 4.

## Conferir a imagem antes de importar

1. Adicione o limite do imóvel como camada poligonal com SRC definido e selecione essa camada no plugin.
2. Escolha Landsat, Sentinel-2 ou ambos e um ano ou período. **Todo o histórico (1982–hoje)** consulta o arquivo histórico disponível para a área.
3. Clique em **Buscar imagens com nuvens < 20%**. As miniaturas são da cena inteira; não use essas miniaturas para verificar alinhamento.
4. Selecione a cena e as bandas R/G/B. **PRODES — INPE** usa SWIR1–NIR–vermelho, na ordem R/G/B (Landsat 4/5/7: 5–4–3; Landsat 8/9: 6–5–4; Sentinel-2: 11–8–4). O botão mostra a combinação correspondente ao satélite da cena selecionada. A seleção manual de bandas continua disponível. **Cor natural** usa vermelho–verde–azul.
5. Clique em **Ver prévia no mapa e importar RGB**. O plugin prepara os recortes locais e abre uma janela ampla com os pixels georreferenciados e o **limite real do imóvel em azul**, sem preenchimento.
6. Use a roda do mouse para zoom, arraste para mover e use **Enquadrar área** para voltar. É possível ocultar o limite. Em **Comparar com**, escolha outra camada raster do projeto e reduza a opacidade da cena para comparar alinhamento. No modo offline, essa lista oferece apenas arquivos raster locais.
7. Clique em **Importar esta composição** para adicionar uma camada ao projeto, ou **Voltar para escolher outra cena**. Voltar não descarta as bandas baixadas; a próxima abertura as reutiliza.

A prévia usa o SRC do raster e transforma o limite do imóvel para esse SRC. Ela permite inspeção visual, mas não detecta nem corrige automaticamente deslocamentos. As bandas preservam os valores dos recortes; o contraste RGB é apenas visual, com corte de 2% a 98%. As cores variam conforme a cena e seu contraste.

A composição principal segue as bandas documentadas na [nota técnica do INPE para o PRODES Amazônia](https://www.terrabrasilis.dpi.inpe.br/download/terrabrasilis/technicalnotes/nota_tecnica_nao_floresta.pdf). O preset anterior já usava essas bandas; esta versão explicita o nome e a combinação de cada sensor. O preset não reproduz toda a metodologia de classificação do PRODES nem garante cores idênticas às de outra cena.

## Recorte mais largo e qualidade visual

O entorno tem largura mínima de quatro vezes a largura da caixa do imóvel e altura de 2,4 vezes. Para imóveis estreitos e compridos, a largura aumenta até uma proporção aproximada de pelo menos 1,6:1 em distância no terreno. O imóvel continua centralizado e inteiro; o raster passa a ter formato horizontal. A janela da prévia também ficou mais larga, respeitando o espaço da tela.

**Suavizar pixels na visualização RGB** vem ativado: usa interpolação cúbica ao aproximar e bilinear ao afastar. O efeito acompanha a camada RGB importada e melhora a aparência no mapa; desmarque para inspecionar os pixels sem suavização. Isso não cria detalhes novos, não altera os arquivos das bandas e não muda o cálculo do NDVI. O contorno do imóvel continua georreferenciado.

As composições usam a melhor resolução de grade entre as bandas selecionadas, evitando uma grade de resolução média quando as bandas têm resoluções diferentes. Bandas mais grossas continuam com seu limite de detalhe original. Os GeoTIFFs locais são recortes das bandas, e não imagens JPEG de prévia.

Para obter o **novo recorte horizontal**, baixe a composição ou atualize a área novamente com internet. O cache é separado pelo perfil de recorte para não reutilizar uma imagem estreita como se fosse a nova. Os arquivos anteriores ficam preservados. Em modo offline, se ainda não existir catálogo do novo recorte, o plugin abre o acervo anterior e informa que o enquadramento largo exige atualização. Se já existir um catálogo novo, as cenas dele são usadas e as bandas ausentes precisam ser baixadas com internet.

## Melhorias de velocidade

- Até três bandas são recortadas em paralelo, com datasets e configurações GDAL separados por tarefa. Em versões do GDAL sem configuração por thread, o download continua sequencial.
- Bandas locais, composições VRT e limites de contraste já calculados são reutilizados. O contraste é recalculado se os arquivos do recorte mudarem.
- O corte visual de 2% a 98% usa uma amostra de 65.536 pixels, reduzindo o trabalho para abrir a prévia. Isso não reduz a resolução nem altera os valores das bandas; pode mudar ligeiramente o contraste exibido.
- Requisições HTTP usam leitura de intervalos e multiplexação quando suportadas. As tarefas compartilham o token de acesso anônimo, evitando pedidos repetidos.
- A remoção de cenas repetidas na busca usa um índice por identificador.

O ganho depende da conexão, do servidor, do tamanho da área e da versão do GDAL. Não foi medido em uma instalação real do QGIS neste ambiente.

## Acervo offline e atualização de novas cenas

1. Escolha uma pasta em **Acervo permanente → Escolher pasta**. Por padrão, usa `Catalogo_Multiespectral_Acervo` na pasta Documentos. A escolha fica salva nas configurações do QGIS.
2. Com internet, escolha a área, os satélites e o período. Para baixar o arquivo histórico completo da área, escolha **Todo o histórico (1982–hoje)**.
3. Clique em **Baixar / atualizar todas as cenas do período**. A rotina percorre todas as páginas do catálogo e salva os recortes de todas as bandas espectrais de cada cena elegível, para permitir mudar composições e calcular NDVI depois, sem rede. Não adiciona automaticamente todas essas cenas ao projeto.
4. O painel mostra **Completo**, **Parcial** ou **Não baixado**. Cenas só pesquisadas podem constar no catálogo sem bandas baixadas. Para uma cena individual, basta abrir sua prévia: só as bandas da composição escolhida são baixadas.
5. Depois, marque **Modo offline — usar apenas o acervo local** e clique em **Buscar no acervo local**. Use a mesma área, SRC e pasta, selecionando o período que deseja consultar. Prévia, RGB e NDVI usam os arquivos já baixados. Bandas ausentes geram um aviso; o modo offline não faz download automaticamente.
6. Para novas imagens, desmarque offline, selecione novamente o período a atualizar e clique em **Baixar / atualizar todas as cenas do período**. A rotina consulta o catálogo novamente, incorpora novas cenas e tenta completar bandas que falharam. Arquivos completos são reutilizados, sem baixar tudo outra vez. Para incluir datas recentes, o período deve chegar até hoje.

**O acervo é da área selecionada e de seu entorno, não de todo o planeta nem de cenas inteiras.** Continua valendo o filtro de nuvens **estritamente menor que 20%** no metadado da cena inteira. Isso não garante ausência de nuvens dentro do imóvel. Cenas sem o metadado ficam fora da busca. A primeira sincronização pode demorar e ocupar bastante espaço, especialmente com décadas de imagens; é possível trabalhar por ano e cancelar a tarefa.

Downloads interrompidos não contam como completos. Os arquivos concluídos permanecem, e uma nova atualização pode retomar as bandas faltantes. A pasta externa de acervo não é apagada ao atualizar ou reinstalar o plugin. Não mova ou exclua essa pasta se um projeto do QGIS depender dela; faça cópia de segurança quando necessário. Imóveis com caixa envolvente ou SRC diferentes recebem acervos separados para evitar reutilizar um recorte errado.

As miniaturas online que foram vistas também são guardadas quando possível. Uma cena recém-sincronizada pode não ter miniatura, mas suas bandas completas permitem abrir a prévia georreferenciada offline. Referências XYZ/WMS não são oferecidas dentro da prévia offline; camadas online já presentes no projeto principal são gerenciadas pelo próprio QGIS.

## Composições da mesma data e NDVI

Falsa cor e cor natural da mesma data podem coexistir, cada uma como **uma camada RGB com três bandas internas**. Reimportar a mesma cena, área e combinação de bandas substitui apenas aquela composição. As bandas de apoio não viram camadas separadas no painel.

**Calcular NDVI da cena** usa NIR e vermelho: Landsat 4/5/7, bandas 4 e 3; Landsat 8/9, bandas 5 e 4; Sentinel-2, B08 e B04. O índice aplica `(NIR − vermelho) / (NIR + vermelho)` e é aberto em prévia com uma rampa de −1 a +1 antes da importação.

Para Landsat Collection 2, aplica escala 0,0000275 e deslocamento −0,2 antes do cálculo; para Sentinel-2, lê `raster:bands` quando disponível, com escala padrão 0,0001. Pixels sem dados ou índices fora do intervalo físico são tratados como NoData. O NDVI é salvo como GeoTIFF Float32 no acervo. Os recortes Landsat/Sentinel preservam os valores originais; as composições RGB usam VRT local. O NDVI complementa a interpretação e não classifica automaticamente desmatamento, nuvens ou sombras.

## Armazenamento e dependências

A imagem só é adicionada ao projeto após confirmação na prévia. Os dados são permanentes no acervo local e podem sustentar o projeto após reiniciar o QGIS. Para um arquivo independente, exporte a composição RGB em GeoTIFF. Remover uma camada do painel não remove as bandas do acervo.

Requer GDAL Python e NumPy, presentes nas instalações usuais do QGIS. A busca e os novos downloads dependem do Microsoft Planetary Computer e de internet. Landsat provém da USGS/NASA; Sentinel-2, ESA/Copernicus. A disponibilidade histórica depende da área e do catálogo.

## Validação desta versão

36 testes locais passaram, incluindo: persistência do catálogo, separação de áreas/SRC, filtro de nuvens/datas, paginação completa, atualização incremental, reaproveitamento entre composições, recusa de rede em modo offline, retomada de downloads com falha cálculo numérico de NDVI com NoData, bandas PRODES por sensor, recortes em três tarefas com configurações isoladas e compartilhamento do token entre tarefas, recorte horizontal para imóveis estreitos e compatibilidade offline com acervos anteriores e validação dos metadados/pacote de publicação e transporte de rede (HTTPS, redirecionamentos, erros e cancelamento). Os testes de recorte simulam o GDAL; este ambiente não tem QGIS/GDAL instalado. A aparência da janela, a sobreposição de geometrias e a importação de cenas reais ainda precisam ser conferidas no QGIS.

**Créditos:** Kayky Pessoa de Araujo (autor); OpenAI Codex (colaboração no desenvolvimento); USGS/NASA (Landsat); ESA/Copernicus (Sentinel-2); Microsoft Planetary Computer (catálogo, prévias e hospedagem).

## Licença e contribuição

Copyright (C) 2026 Kayky Pessoa de Araujo. Código e ícone distribuídos sob **GPL-2.0-or-later**: veja [LICENSE](LICENSE) e [NOTICE](NOTICE). A colaboração de OpenAI Codex e as fontes de dados estão creditadas; o plugin é independente das instituições mencionadas.

Esta versão prepara a publicação. O e-mail do autor e os links do projeto estão configurados. O código precisa ser colocado no repositório público e a execução real no QGIS conferida antes da submissão. Consulte [PUBLICACAO.md](PUBLICACAO.md), [CONTRIBUTING.md](CONTRIBUTING.md) e [CHANGELOG.md](CHANGELOG.md). O ZIP não contém dados de clientes, imagens baixadas ou credenciais.

Projeto público: https://github.com/kaykytopas-create/catalogo-multiespectral-aoi

Relatos de problemas: https://github.com/kaykytopas-create/catalogo-multiespectral-aoi/issues

## Segurança (desde a versão 0.9.2)

Consultas STAC e assinaturas temporárias usam QgsNetworkAccessManager, respeitando a configuração de rede do QGIS. Endereços externos ao serviço autorizado e redirecionamentos são recusados. Erros de cache são registrados sem incluir URLs assinadas. Bandit 1.9.4 e detect-secrets 1.5.0 foram executados no pacote completo, sem ocorrências. Essa verificação local não substitui a avaliação do repositório QGIS.

## Ajustes Qt6 da versão 0.9.3

As 22 ocorrências de enumerações e execução de diálogo apontadas pelo repositório foram corrigidas; QAction usa uma importação compatível com Qt5 e Qt6. As referências Qt foram conferidas com PyQt5 5.15.11 e PyQt6 6.11.0. Os testes de transporte usam objetos simulados com enumerações apenas no formato novo. O plugin continua declarado para QGIS 3.22–3.99; a interface e o processamento completo precisam de validação no QGIS antes de declarar suporte ao QGIS 4.


## Novidades 0.10.0 — composições e qualidade

Escolha uma cena e abra **Opção de bandas**. PRODES continua como padrão. As três caixas de R, G e B permitem ajustar manualmente a composição; NDVI e NBR usam as respectivas bandas automaticamente.

| Opção | Landsat 4/5/7 (R–G–B) | Landsat 8/9 (R–G–B) | Sentinel-2 (R–G–B) |
|---|---|---|---|
| Cor natural | 3–2–1 | 4–3–2 | 4–3–2 |
| Infravermelho — vegetação | 4–3–2 | 5–4–3 | 8–4–3 |
| Análise de vegetação / PRODES | 5–4–3 | 6–5–4 | 11–8–4 |
| Infravermelho de ondas curtas | 7–4–3 | 7–5–4 | 12–8–4 |
| Agricultura | 7–5–1 | 7–6–2 | 12–11–2 |
| Terra / água | 4–5–3 | 5–6–4 | 8–11–4 |

NBR = (NIR − SWIR2) / (NIR + SWIR2), com escala e offset da reflectância, saída Float32 e NoData −9999. É um índice, não uma composição RGB nem uma classificação automática de queimadas. A paleta é contínua; as cores podem diferir do LandViewer.

**Qualidade:** os arquivos continuam na resolução das bandas de origem e conservam os valores radiométricos. O RGB usa a banda de melhor resolução para a grade do VRT; por exemplo, SWIR de 20 m do Sentinel-2 não ganha detalhes de 10 m por estar na mesma grade. O contraste tem amostragem ampliada e a suavização é exclusivamente visual.

**Pixels ausentes:** os novos downloads são lidos integralmente antes de entrar no cache, com tentativas adicionais para falhas HTTP e tratamento explícito de NoData. Se uma banda antiga estiver corrompida, ela é recusada offline e recuperada com rede. Para refazer uma cena mesmo com cache legível, marque **Baixar novamente as bandas desta cena** antes de importar. Essa opção requer internet.

Cenas Landsat 7 posteriores a maio de 2003 têm lacunas reais SLC-off. O plugin as identifica e permite ocultá-las na busca. Áreas fora da cobertura, lacunas do sensor e observações ausentes permanecem NoData. Nenhum pixel é inventado, interpolado para preencher falhas ou copiado de outra data. Sem uma amostra da cena com o defeito, não é possível confirmar a causa específica relatada.

Referências: https://eos.com/make-an-analysis/vegetation-analysis/ ; https://eos.com/make-an-analysis/shortwave-infrared/ ; https://www.usgs.gov/landsat-missions/landsat-normalized-burn-ratio ; https://www.usgs.gov/faqs/what-landsat-7-etm-slc-data
