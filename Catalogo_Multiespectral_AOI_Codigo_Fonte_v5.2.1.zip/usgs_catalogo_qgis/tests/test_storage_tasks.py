# SPDX-License-Identifier: GPL-2.0-or-later
import os
from pathlib import Path
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from usgs_catalogo_qgis.storage import AssetIndex,receipt,sha256
from usgs_catalogo_qgis.archive import LocalArchive
from usgs_catalogo_qgis.stac import CatalogError


def raster(path):
    from osgeo import gdal,osr
    import numpy as np
    ds=gdal.GetDriverByName('GTiff').Create(path,32,32,1,gdal.GDT_UInt16)
    sr=osr.SpatialReference();sr.ImportFromEPSG(4326)
    ds.SetProjection(sr.ExportToWkt());ds.SetGeoTransform((-55,.001,0,-12,0,-.001))
    ds.GetRasterBand(1).WriteArray(np.full((32,32),100,dtype='uint16'));ds=None


class StorageTests(unittest.TestCase):
    def test_windows_long_path_prefix_uses_the_same_lock(self):
        from unittest.mock import patch
        from usgs_catalogo_qgis.storage import lock_key
        if os.name!='nt':
            self.assertEqual(lock_key('/tmp/a/../b.json'),lock_key('/tmp/b.json'))
            return
        for normal,extended in [('C:\\catalogo','\\\\?\\C:\\catalogo'),('\\\\server\\share','\\\\?\\UNC\\server\\share')]:
            with patch('usgs_catalogo_qgis.storage.os.path.realpath',return_value=normal):a=lock_key('catalogo.json')
            with patch('usgs_catalogo_qgis.storage.os.path.realpath',return_value=extended):b=lock_key('catalogo.json')
            self.assertEqual(a,b)

    def test_failed_file_probe_does_not_replace_existing_catalog_with_empty_data(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as root:
            archive=LocalArchive(root,(-55,-12,-54.99,-11.99),'EPSG:4326')
            archive.remember({'id':'existing','collection':'x'})
            with patch('usgs_catalogo_qgis.archive.os.path.isfile',return_value=False):
                archive.remember({'id':'new','collection':'x'})
            self.assertEqual(len(archive.read()['scenes']),2)

    def test_windows_catalog_read_retries_but_does_not_hide_persistent_error(self):
        from unittest.mock import patch
        from usgs_catalogo_qgis.storage import atomic_json
        with tempfile.TemporaryDirectory() as root:
            archive=LocalArchive(root,(-55,-12,-54.99,-11.99),'EPSG:4326')
            atomic_json(archive.index_path,{'version':1,'scenes':{}})
            original=open;attempts=[]
            def busy(*args,**kwargs):
                attempts.append(1)
                if len(attempts)<3:raise PermissionError('ocupado')
                return original(*args,**kwargs)
            with patch('usgs_catalogo_qgis.archive.open',side_effect=busy),patch('usgs_catalogo_qgis.archive.os.name','nt'),patch('usgs_catalogo_qgis.archive.time.sleep'):
                self.assertEqual(archive.read()['scenes'],{})
            self.assertEqual(len(attempts),3)
            with patch('usgs_catalogo_qgis.archive.open',side_effect=PermissionError('ocupado')),patch('usgs_catalogo_qgis.archive.os.name','nt'),patch('usgs_catalogo_qgis.archive.time.sleep'):
                with self.assertRaises(CatalogError):archive.read()

    def test_windows_atomic_write_retries_and_keeps_old_data_on_failure(self):
        import json
        from unittest.mock import patch
        from usgs_catalogo_qgis.storage import atomic_json
        error=PermissionError('Arquivo ocupado');error.winerror=32
        with tempfile.TemporaryDirectory() as root:
            path=os.path.join(root,'queue.json');atomic_json(path,{'old':True})
            real_replace=os.replace
            attempts=[]
            def replace(source,target):
                attempts.append(target)
                if len(attempts)<3:raise error
                return real_replace(source,target)
            with patch('usgs_catalogo_qgis.storage.os.replace',side_effect=replace),patch('usgs_catalogo_qgis.storage.time.sleep'):
                atomic_json(path,{'new':True})
            self.assertEqual(len(attempts),3)
            with patch('usgs_catalogo_qgis.storage.os.replace',side_effect=error),patch('usgs_catalogo_qgis.storage.time.sleep'):
                with self.assertRaises(PermissionError):atomic_json(path,{'lost':True})
            with open(path,encoding='utf-8') as stream:self.assertEqual(json.load(stream),{'new':True})
            self.assertFalse(list(Path(root).glob('*.part')))

    def test_hash_changed_and_missing_files_are_detected_without_deleting_user_files(self):
        with tempfile.TemporaryDirectory() as root:
            path=os.path.join(root,'test.tif');raster(path)
            index=AssetIndex(root);index.register(path,'aoi','scene','band')
            self.assertEqual(index.audit()[0]['status'],'ok')
            old=os.stat(path)
            with open(path,'r+b') as f:f.seek(-1,2);f.write(b'X')
            os.utime(path,ns=(old.st_atime_ns,old.st_mtime_ns))
            self.assertEqual(index.audit()[0]['status'],'invalid')
            from usgs_catalogo_qgis.stac import validate_cached_raster
            from osgeo import gdal
            with self.assertRaises(CatalogError):validate_cached_raster(path,gdal)
            self.assertTrue(os.path.isfile(path))
            os.remove(path)
            self.assertEqual(index.audit()[0]['status'],'invalid')

    def test_archive_metadata_updates_are_not_lost_between_tasks(self):
        with tempfile.TemporaryDirectory() as root:
            def remember(number):
                LocalArchive(root,(-55,-12,-54.99,-11.99),'EPSG:4326').remember({'id':str(number),'collection':'x'})
            with ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(remember,range(20)))
            data=LocalArchive(root,(-55,-12,-54.99,-11.99),'EPSG:4326').read()
            self.assertEqual(len(data['scenes']),20)
            self.assertFalse(list(Path(root).rglob('*.part')))

    def test_sqlite_reindex_preserves_files_and_upserts_without_duplicates(self):
        with tempfile.TemporaryDirectory() as root:
            path=Path(root)/'areas/aoi/cenas/scene/band.tif';path.parent.mkdir(parents=True);raster(str(path))
            index=AssetIndex(root)
            self.assertEqual(index.reindex()['indexed'],1)
            self.assertEqual(index.reindex()['indexed'],1)
            self.assertEqual(len(index.rows()),1)
            with self.assertRaises(CatalogError):index.relative('/etc/passwd')
            self.assertEqual(index.rows()[0]['sha256'],sha256(path))
            with self.assertRaises(CatalogError):receipt(str(path),lambda:True,deep=True)

    def test_gdal_cancelled_task_and_dos1_rules(self):
        from usgs_catalogo_qgis.radiometry import dos1_file
        from osgeo import gdal
        with tempfile.TemporaryDirectory() as root:
            source=os.path.join(root,'source.tif');target=os.path.join(root,'dos1.tif');raster(source)
            item={'collection':'landsat-c2-l1','catalog:units':'toa_reflectance',
                  'properties':{'view:sun_elevation':40},'assets':{'red':{'raster:bands':[{'scale':.001}]}}}
            dos1_file(source,target,item,'red')
            ds=gdal.Open(target)
            self.assertAlmostEqual(float(ds.GetRasterBand(1).ReadAsArray()[0,0]),.01,places=5)
            self.assertEqual(ds.GetMetadata()['ATMOSPHERIC_CORRECTION'],'DOS1');ds=None
            with self.assertRaises(CatalogError):dos1_file(source,target,item,'red',lambda:True)
            self.assertFalse(os.path.exists(target+'.part.tif'))
            with self.assertRaises(CatalogError):dos1_file(source,target,{'collection':'sentinel-2-l2a'},'red')

    def test_mapbiomas_multiyear_local_fallback_preserves_classes_and_crs(self):
        from osgeo import gdal,osr
        import numpy as np
        from usgs_catalogo_qgis.extended_sources import ingest_mapbiomas
        with tempfile.TemporaryDirectory() as root:
            source=os.path.join(root,'mapbiomas_export.tif')
            ds=gdal.GetDriverByName('GTiff').Create(source,64,64,2,gdal.GDT_Byte)
            sr=osr.SpatialReference();sr.ImportFromEPSG(4326)
            ds.SetProjection(sr.ExportToWkt());ds.SetGeoTransform((-55.1,.003,0,-11.9,0,-.003))
            for number,(year,code) in enumerate([(2000,15),(2001,3)],1):
                ds.GetRasterBand(number).SetDescription('classification_'+str(year))
                ds.GetRasterBand(number).WriteArray(np.full((64,64),code,dtype='uint8'))
            ds=None
            archive=LocalArchive(os.path.join(root,'archive'),(-55,-12,-54.99,-11.99),'EPSG:32721')
            events=[];value=ingest_mapbiomas([source],archive,on_ready=events.append)
            self.assertFalse(value['errors']);self.assertEqual(len(events),2)
            self.assertEqual(len(archive.search(['mapbiomas-local'],'2000-01-01','2001-12-31')),2)
            for event,code in zip(events,[15,3]):
                result=gdal.Open(event['path'])
                self.assertEqual(set(np.unique(result.ReadAsArray()))-{0},{code})
                self.assertIn('UTM zone 21S',result.GetProjection());result=None
            self.assertEqual(len(AssetIndex(archive.root).rows()),2)
            self.assertFalse(list(Path(root).rglob('*.part*')))


class ManagedTaskTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from qgis.core import QgsApplication
        cls.app=QgsApplication.instance() or QgsApplication([],False)
        cls.app.initQgis()

    def execute(self,worker,cancel=False):
        from qgis.PyQt.QtCore import QEventLoop,QTimer,QThread
        loop=QEventLoop();events=[];threads=[]
        worker.result.connect(lambda value:(events.append(('result',value)),threads.append(QThread.currentThread()==self.app.thread())))
        worker.failed.connect(lambda value:events.append(('failed',value)))
        worker.done.connect(lambda:(events.append(('done',None)),loop.quit()))
        worker.start()
        if cancel:QTimer.singleShot(10,worker.cancel)
        QTimer.singleShot(5000,loop.quit);loop.exec()
        self.assertTrue(events and events[-1][0]=='done',events)
        self.assertTrue(all(threads))
        return events

    def test_success_error_and_cooperative_cancel_have_one_terminal_callback(self):
        from usgs_catalogo_qgis.tasks import TaskWorker
        import time
        class Success(TaskWorker):
            def work(self):self.result.emit('ready')
        self.assertEqual([e[0] for e in self.execute(Success())],['result','done'])
        class Failure(TaskWorker):
            def work(self):raise ValueError('explicit failure')
        self.assertEqual([e[0] for e in self.execute(Failure())],['failed','done'])
        class Cancel(TaskWorker):
            def work(self):
                while not self.stopping:time.sleep(.005)
        self.assertEqual([e[0] for e in self.execute(Cancel(),True)],['done'])
