# Catálogo Multiespectral por Área de Interesse — 5.2.2

Plugin QGIS com cinco abas: **Bandas e análise**, **Comparação temporal** e **Carta-imagem**, **Situação fundiária** e **Analisar PRODES**.
Busca de cenas públicas, acervo offline, composições RGB, NDWI/MNDWI/NDMI/NDTI/NDVI/NBR,
dados históricos JRC Global Surface Water, comparação de datas e layouts editáveis.
Situação ambiental/fundiária e análise PRODES restauradas. Classificação supervisionada permanece oculta.

Consulte [Guia de uso](usgs_catalogo_qgis/GUIA_5.2.2.md) e [Validação](usgs_catalogo_qgis/VALIDACAO_5.2.2.md).
QGIS 3.40–3.99; testado no Windows com QGIS 3.44.7. GDAL e NumPy incluídos no QGIS.
Distribuição não experimental (experimental=False); publicação oficial requer revisão separada.
Índices e limiares são exploratórios e não substituem medições de qualidade/quantidade de água.

Autor: Kayky Pessoa de Araujo. Licença: GPL-2.0-or-later; consulte LICENSE e NOTICE.
Documentos de versões anteriores são históricos; siga o guia 5.2 para a interface atual.
