from .spectral import INDEX_PRODUCTS
# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 Kayky Pessoa de Araujo
"""QGIS UI for anonymous Landsat and Sentinel image retrieval."""
import os
import logging
import json
import math
from datetime import date

from .tasks import TaskWorker
from qgis.PyQt.QtCore import QDate, QSize, Qt, QStandardPaths, pyqtSignal
from qgis.PyQt.QtGui import QColor, QIcon, QPixmap
from qgis.PyQt.QtWidgets import (QCheckBox, QComboBox, QDateEdit, QDialog,
    QFormLayout, QGroupBox, QHBoxLayout, QHeaderView, QLabel, QMessageBox,
    QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
    QFileDialog, QSlider, QLineEdit, QTabWidget, QScrollArea, QGridLayout)
from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform,
                       QgsProject, QgsRasterLayer, QgsVectorLayer, QgsWkbTypes,
                       QgsMultiBandColorRenderer, QgsContrastEnhancement,
                       QgsColorRampShader, QgsRasterShader,
                       QgsSingleBandPseudoColorRenderer, QgsSettings, QgsGeometry,
                       QgsCubicRasterResampler, QgsBilinearRasterResampler)
try:
    from qgis.PyQt.QtGui import QAction
except ImportError:
    from qgis.PyQt.QtWidgets import QAction

from qgis.gui import QgsMapCanvas, QgsMapToolPan, QgsRubberBand
from .commands import parse_command, describe_plan, collect_scenes, download_batch
from .archive import LocalArchive
from .archive_location import resolve_archive, writable_directory
from .stac import (COLLECTIONS, CatalogError, available_bands,
                   band_label, ndvi_keys,
                   preview_url, prodes_label, PRESETS, preset_keys, index_keys, slc_gap_scene)

from .public_sources import MultiCatalog as PublicCatalog, merge_scenes

class Job(TaskWorker):
    result = pyqtSignal(object)
    failed = pyqtSignal(str)
    status = pyqtSignal(str)
    prepared = pyqtSignal(object)

    def __init__(self, action, **kwargs):
        super().__init__()
        self.action, self.args, self.stopping = action, kwargs, False

    def cancel(self):
        self.stopping = True

    def work(self):
        client = PublicCatalog(cancelled=lambda: self.stopping)
        try:
            if self.action == "command_batch":
                data = download_batch(client, self.args["archive"], self.args["plan"], self.status.emit, self.args["hide_slc"], on_ready=self.prepared.emit)
            elif self.action == "command_search":
                data = (collect_scenes(client, self.args["archive"], self.args["plan"], self.status.emit, self.args["hide_slc"]), None)
            elif self.action == 'quality':
                data = client.assess_scene_quality(self.args['item'], self.args['folder'], self.args['rect'], self.args['crs'], self.status.emit, self.args['geometry'], self.args['offline'])
            elif self.action == "search":
                self.status.emit("Consultando imagens públicas…")
                data = client.search(**self.args)
            elif self.action == "local":
                data = (self.args["archive"].search(self.args["collections"],
                        self.args["start"], self.args["end"]), None)
            elif self.action == "sync":
                data = self.args["archive"].sync(client, self.args["collections"],
                        self.args["start"], self.args["end"], self.status.emit)
            else:
                archive = self.args["archive"]
                item = self.args["item"]
                archive.remember(item)
                data = client.download_scene(item,
                    archive.scene_folder(item), archive.rect, archive.target_crs,
                    self.status.emit, self.args["rgb_keys"],
                    self.args.get("product", "rgb"), self.args.get("offline", False),
                    self.args.get("force_download", False))
                archive.remember(item, data[1])
            if not self.stopping:
                self.result.emit(data)
        except Exception as exc:
            if not self.stopping:
                self.failed.emit(str(exc))


class ThumbnailJob(TaskWorker):
    def __init__(self, url):
        super().__init__(description='Catálogo · miniatura')
        self.url=url

    def work(self):
        from .public_http import request
        self.result.emit(request(self.url,cancelled=lambda:self.stopping,timeout=20,max_bytes=4*1024*1024))



class PreviewDialog(QDialog):
    """Preview real georeferenced pixels, with a cloned property outline."""
    def __init__(self, raster, property_layer, description, iface, offline, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Prévia georreferenciada — confira a área antes de importar")
        screen = self.screen()
        available = screen.availableGeometry() if screen else None
        self.resize(min(1280, available.width() - 60) if available else 1280,
                    min(800, available.height() - 80) if available else 800)
        self.raster = raster
        layout = QVBoxLayout(self)
        text = QLabel(description + "\nContorno azul: limite do imóvel. Use a roda do mouse para zoom e arraste para mover.")
        text.setWordWrap(True)
        layout.addWidget(text)
        self.canvas = QgsMapCanvas(self)
        self.canvas.setCanvasColor(QColor("#17242e"))
        self.canvas.enableAntiAliasing(True)
        self.canvas.setDestinationCrs(raster.crs())
        self.canvas.setLayers([raster])
        self.pan = QgsMapToolPan(self.canvas)
        self.canvas.setMapTool(self.pan)
        layout.addWidget(self.canvas, 1)
        self.outlines = []
        transform = QgsCoordinateTransform(property_layer.crs(), raster.crs(), QgsProject.instance())
        for feature in property_layer.getFeatures():
            if not feature.hasGeometry():
                continue
            geometry = QgsGeometry(feature.geometry())
            geometry.transform(transform)
            outline = QgsRubberBand(self.canvas, QgsWkbTypes.GeometryType.PolygonGeometry)
            outline.setToGeometry(geometry, None)
            outline.setStrokeColor(QColor("#48b7ff"))
            outline.setFillColor(QColor(0, 0, 0, 0))
            outline.setWidth(3)
            self.outlines.append(outline)
        toolbar = QHBoxLayout()
        limits = QCheckBox("Mostrar limite"); limits.setChecked(True)
        limits.toggled.connect(lambda visible: [outline.setVisible(visible) for outline in self.outlines])
        toolbar.addWidget(limits)
        frame = QPushButton("Enquadrar área")
        frame.clicked.connect(self.frame_area)
        toolbar.addWidget(frame)
        toolbar.addWidget(QLabel("Comparar com:"))
        self.reference = QComboBox()
        self.reference.addItem("Sem referência", None)
        self.references = {}
        for layer in QgsProject.instance().mapLayers().values():
            if not isinstance(layer, QgsRasterLayer) or not layer.isValid():
                continue
            # Offline mode never offers a reference requiring a remote provider.
            if offline and (layer.providerType() != "gdal" or not os.path.isfile(layer.source()) or
                    os.path.splitext(layer.source())[1].lower() not in (".tif", ".tiff", ".jp2", ".png", ".jpg")):
                continue
            self.references[layer.id()] = layer
            self.reference.addItem(layer.name(), layer.id())
        toolbar.addWidget(self.reference, 1)
        toolbar.addWidget(QLabel("Opacidade da cena:"))
        self.opacity = QSlider(Qt.Orientation.Horizontal)
        self.opacity.setRange(0, 100); self.opacity.setValue(100)
        self.opacity.setMaximumWidth(160)
        toolbar.addWidget(self.opacity)
        self.reference.currentIndexChanged.connect(self.update_layers)
        self.opacity.valueChanged.connect(self.update_layers)
        layout.addLayout(toolbar)
        row = QHBoxLayout()
        back = QPushButton("Voltar para escolher outra cena")
        back.clicked.connect(self.reject)
        use = QPushButton("Importar esta composição")
        use.setMinimumHeight(44)
        use.setMinimumWidth(240)
        use.clicked.connect(self.accept)
        row.addWidget(back); row.addStretch(); row.addWidget(use)
        layout.addLayout(row)
        self.frame_area()

    def frame_area(self):
        self.canvas.setExtent(self.raster.extent())
        self.canvas.refresh()

    def update_layers(self):
        reference = self.references.get(self.reference.currentData())
        self.raster.renderer().setOpacity(self.opacity.value() / 100.0)
        self.canvas.setLayers([self.raster, reference] if reference else [self.raster])
        self.canvas.refresh()

    def done(self, result):
        # Opacity is a comparison aid; imported imagery keeps the normal style.
        self.raster.renderer().setOpacity(1.0)
        self.canvas.stopRendering()
        self.canvas.setLayers([])
        super().done(result)


class CatalogDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("Catálogo Multiespectral 5.2.2 | Bandas · PRODES · Situação fundiária")
        self.resize(1180, 850)
        screen = self.screen()
        if screen:
            available = screen.availableGeometry()
            self.resize(min(1180, available.width() - 40),
                        min(850, available.height() - 60))
        self.job, self.next_link, self.active_scene, self.search_params = None, None, None, None
        self.scenes = []
        self.archive = None
        self.search_layer_id = None
        self.band_scene_id = None
        self.preview_queue = []
        self.preview_active = 0
        self.preview_generation = 0
        self.preview_cache = {}
        self.preview_replies = set()
        outer = QVBoxLayout(self)
        self.tabs = QTabWidget(self)
        outer.addWidget(self.tabs)
        imagery_page = QWidget(self.tabs)
        self.imagery_page = imagery_page
        self.tabs.addTab(imagery_page, "Imagens")
        page_layout = QVBoxLayout(imagery_page)
        self.imagery_scroll = QScrollArea(imagery_page)
        self.imagery_scroll.setWidgetResizable(True)
        imagery_content = QWidget()
        layout = QVBoxLayout(imagery_content)
        self.imagery_scroll.setWidget(imagery_content)
        page_layout.addWidget(self.imagery_scroll, 1)
        intro = QLabel("Selecione o imóvel. Landsat/USGS e NASA HLS via Microsoft, Sentinel-2 via Microsoft/AWS e apoio do INPE/Brazil Data Cube. Menos de 20% de nuvens; sem conta.")
        intro.setWordWrap(True); layout.addWidget(intro)
        band_shortcut = QPushButton('Composições e índices prontos → Bandas e análise')
        band_shortcut.clicked.connect(lambda: self.tabs.setCurrentWidget(self.analysis_scroll))
        layout.addWidget(band_shortcut)
        command_box = self.command_box = QGroupBox("Comandos de tarefa — sem necessidade de IA local ou Codex")
        command_layout = QVBoxLayout(command_box)
        self.command_text = QLineEdit()
        self.command_text.setPlaceholderText("Baixe e importe no QGIS uma imagem por ano de 2000 a 2008, cor natural, 0% de nuvens")
        command_layout.addWidget(self.command_text)
        command_row = QHBoxLayout()
        self.enqueue_button = QPushButton('Adicionar comando à fila')
        self.enqueue_button.clicked.connect(self.enqueue_command)
        command_layout.addWidget(self.enqueue_button)
        self.plan_button = QPushButton("Ver plano (não executa)")
        self.execute_command_button = QPushButton("Executar plano mostrado")
        self.run_command_button = QPushButton("Executar comando")
        self.execute_command_button.setEnabled(False)
        command_row.addWidget(self.run_command_button); command_row.addWidget(self.plan_button); command_row.addWidget(self.execute_command_button)
        command_layout.addLayout(command_row)
        self.command_plan_label = QLabel("Informe destino: importar no QGIS ou salvar no acervo. Padrão: Landsat, uma cena por ano, composição da lista atual; filtros não são relaxados.")
        self.command_plan_label.setWordWrap(True); command_layout.addWidget(self.command_plan_label)
        layout.addWidget(command_box)
        self.command_plan = None
        self.run_command_button.clicked.connect(self.run_command)
        self.command_text.returnPressed.connect(self.run_command)
        self.plan_button.clicked.connect(self.plan_command)
        self.execute_command_button.clicked.connect(self.execute_command)
        self.command_text.textChanged.connect(self.clear_command_plan)
        box = QGroupBox("Pesquisar imagens"); form = QFormLayout(box)
        self.layer_box = QComboBox(); self.refresh = QPushButton("Atualizar camadas")
        row = QWidget(); h = QHBoxLayout(row); h.setContentsMargins(0, 0, 0, 0)
        h.addWidget(self.layer_box, 1); h.addWidget(self.refresh)
        form.addRow("Limite do imóvel:", row)
        self.offline = QCheckBox("Modo offline — usar apenas o acervo local")
        form.addRow("Fonte:", self.offline)
        preferred = QgsSettings().value("catalogo_multiespectral/acervo", "", type=str)
        locations = [QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DocumentsLocation),
                     os.path.expanduser("~"),
                     QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppLocalDataLocation)]
        self.archive_path, archive_warning = resolve_archive(preferred, [
            os.path.join(location, "Catalogo_Multiespectral_Acervo") for location in locations if location])
        self.archive_label = QLabel(self.archive_path)
        self.archive_label.setWordWrap(True)
        self.choose_archive = QPushButton("Escolher pasta")
        row = QWidget(); h = QHBoxLayout(row); h.setContentsMargins(0, 0, 0, 0)
        h.addWidget(self.archive_label, 1); h.addWidget(self.choose_archive)
        form.addRow("Acervo permanente:", row)
        self.archive_notice = QLabel(archive_warning)
        self.archive_notice.setWordWrap(True)
        self.archive_notice.setVisible(bool(archive_warning))
        form.addRow(self.archive_notice)
        self.landsat = QCheckBox(COLLECTIONS["landsat-c2-l2"]); self.landsat.setChecked(True)
        self.sentinel = QCheckBox(COLLECTIONS["sentinel-2-l2a"]); self.sentinel.setChecked(True)
        self.nasa_hls = QCheckBox('NASA HLS · L30 e S30 · 30 m'); self.nasa_hls.setChecked(True)
        self.nasa_hls.setToolTip('Produto NASA harmonizado de superfície: Landsat e Sentinel-2 a 30 m. Acervo Microsoft anunciado desde 2020; a disponibilidade depende da área/data. Sem login. Não é ASTER e não aumenta a resolução do Sentinel-2 original.')
        row = QWidget(); h = QHBoxLayout(row); h.setContentsMargins(0, 0, 0, 0)
        h.addWidget(self.landsat); h.addWidget(self.sentinel); h.addStretch()
        form.addRow("Satélites:", row)
        form.addRow('Acervo NASA:', self.nasa_hls)
        self.hide_slc = QCheckBox("Ocultar Landsat 7 com lacunas do sensor (SLC-off)")
        self.hide_slc.setChecked(True)
        self.hide_slc.setToolTip("Cenas posteriores a maio de 2003 têm lacunas reais. Desmarque para incluí-las e refaça a busca.")
        form.addRow("Integridade da cena:", self.hide_slc)
        self.year = QComboBox()
        self.year.addItem("Período personalizado", None)
        self.year.addItem("Todo o histórico (1982–hoje)", -1)
        for year in range(date.today().year, 1981, -1):
            self.year.addItem(str(year), year)
        self.year.setCurrentIndex(2)
        form.addRow("Ir para o ano:", self.year)
        self.start = QDateEdit(); self.start.setCalendarPopup(True)
        self.start.setDisplayFormat("dd/MM/yyyy"); self.start.setDate(QDate(date.today().year - 1, 1, 1))
        self.end = QDateEdit(); self.end.setCalendarPopup(True)
        self.end.setDisplayFormat("dd/MM/yyyy"); self.end.setDate(QDate.currentDate())
        row = QWidget(); h = QHBoxLayout(row); h.setContentsMargins(0, 0, 0, 0)
        h.addWidget(QLabel("De")); h.addWidget(self.start)
        h.addWidget(QLabel("até")); h.addWidget(self.end); h.addStretch()
        form.addRow("Aquisição:", row); layout.addWidget(box)
        self.year.currentIndexChanged.connect(self.year_changed)
        self.search = QPushButton("Buscar imagens com nuvens < 20%")
        self.more = QPushButton("Próximas cenas"); self.more.setEnabled(False)
        self.sync_button = QPushButton("Acervo completo — todas as cenas e bandas (demorado)")
        row = QHBoxLayout(); row.addWidget(self.search); row.addWidget(self.more)
        row.addWidget(self.sync_button); row.addStretch()
        layout.addLayout(row)
        self.table = QTableWidget(0, 7)
        self.table.setMinimumHeight(160)
        self.table.setHorizontalHeaderLabels(["Miniatura", "Ano", "Data", "Satélite", "Nuvens", "Cena", "Acervo local"])
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setIconSize(QSize(152, 110))
        self.table.setColumnWidth(0, 165)
        self.table.setColumnWidth(1, 65)
        self.table.setColumnWidth(2, 105)
        self.table.setColumnWidth(3, 115)
        self.table.setColumnWidth(4, 80)
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        self.table.setColumnWidth(6, 135)
        self.preview_large = QLabel("Selecione uma cena para ver a prévia ampliada")
        self.preview_large.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_large.setWordWrap(True)
        self.preview_large.setMinimumWidth(300)
        self.preview_large.setMaximumWidth(340)
        self.preview_large.setStyleSheet("background:#1b2732;color:white;border-radius:6px;padding:8px;")
        content = QHBoxLayout(); content.addWidget(self.table, 1); content.addWidget(self.preview_large)
        layout.addLayout(content, 1)
        self.analysis_scroll = QScrollArea(self.tabs)
        self.analysis_scroll.setWidgetResizable(True)
        analysis_page = QWidget()
        analysis_layout = QVBoxLayout(analysis_page)
        self.analysis_scroll.setWidget(analysis_page)
        analysis_intro = QLabel('Selecione uma cena em Imagens. O Band Set é ordenado por comprimento de onda; o produto e a correção são identificados automaticamente.')
        analysis_intro.setWordWrap(True); analysis_layout.addWidget(analysis_intro)
        self.band_set_info = QLabel('Selecione uma cena para conhecer as bandas e o tratamento radiométrico.')
        self.band_set_info.setWordWrap(True); analysis_layout.addWidget(self.band_set_info)
        dos1_info = QGroupBox('Tratamento radiométrico automático · zero configuração')
        dos1_layout = QVBoxLayout(dos1_info)
        dos1_text = QLabel('Landsat L2, Sentinel-2 L2A e NASA HLS já são produtos de superfície e não recebem DOS1 novamente. O HLS preserva a grade de 30 m, a escala radiométrica oficial e a máscara de qualidade. DOS1 fica restrito à regra de coleção L1 aprovada e calibrada; nenhuma correção é presumida.')
        dos1_text.setWordWrap(True); dos1_layout.addWidget(dos1_text); analysis_layout.addWidget(dos1_info)
        band_box = QGroupBox("Composição RGB — escolha as bandas")
        band_layout = QVBoxLayout(band_box)
        preset_row = QHBoxLayout()
        preset_row.addWidget(QLabel("Opção de bandas:"))
        self.preset = QComboBox()
        self.preset.setMinimumContentsLength(28)
        preset_row.addWidget(self.preset, 1)
        band_layout.addLayout(preset_row)
        band_row = QHBoxLayout()
        band_layout.addLayout(band_row)
        self.rgb_boxes = []
        for label in ("Vermelho (R)", "Verde (G)", "Azul (B)"):
            band_row.addWidget(QLabel(label))
            combo = QComboBox(); combo.setMinimumWidth(128)
            self.rgb_boxes.append(combo); band_row.addWidget(combo)
        self.false_color = QPushButton("PRODES — INPE")
        self.false_color.setToolTip("SWIR1 / NIR / vermelho. TM/ETM+ 5–4–3; OLI/HLS L30 6–5–4; Sentinel-2 11–8–4; HLS S30 11–8A–4. Composição de apoio à interpretação; não classifica desmatamento automaticamente.")
        self.natural_color = QPushButton("Cor natural")
        band_row.addWidget(self.false_color); band_row.addWidget(self.natural_color)
        analysis_layout.addWidget(band_box)
        self.preset.currentIndexChanged.connect(self.apply_preset)
        self.false_color.clicked.connect(lambda: self.preset.setCurrentIndex(self.preset.findData("prodes")))
        self.natural_color.clicked.connect(lambda: self.preset.setCurrentIndex(self.preset.findData("natural")))
        self.smooth_rgb = QCheckBox("Suavizar pixels na visualização RGB")
        self.smooth_rgb.setChecked(False)
        self.smooth_rgb.setToolTip("Suavização apenas na tela e nos mapas. Desmarque para inspecionar os pixels originais. Não aumenta o detalhe do satélite nem altera o NDVI.")
        analysis_layout.addWidget(self.smooth_rgb)
        self.repair = QCheckBox("Baixar novamente as bandas desta cena (recuperar acervo)")
        self.repair.setToolTip("Ignora as bandas em cache e baixa novos recortes. Requer internet; não preenche lacunas reais do sensor.")
        analysis_layout.addWidget(self.repair)
        quick = QGroupBox('Atalhos de composição · selecionar e importar')
        grid = QGridLayout(quick)
        for number, (key, title) in enumerate((('natural','Cor natural'), ('prodes','PRODES · INPE'),
                ('infrared','Vegetação'), ('bare','Solo exposto'), ('burn','Cicatriz'), ('ndvi','NDVI'), ('nbr','NBR'))):
            button = QPushButton(title)
            button.clicked.connect(lambda checked=False, preset=key: self.choose_analysis_preset(preset))
            grid.addWidget(button, number // 3, number % 3)
        analysis_layout.addWidget(quick)
        self.bandset_button = QPushButton('Baixar Band Set completo e adicionar uma camada multibanda')
        self.bandset_button.setMinimumHeight(44)
        self.bandset_button.clicked.connect(self.import_bandset)
        analysis_layout.addWidget(self.bandset_button)
        quality_button = QPushButton('Conferir nuvens, sombras e cobertura no imóvel')
        quality_button.clicked.connect(self.inspect_selected_quality)
        analysis_layout.addWidget(quality_button)
        analysis_layout.addStretch()
        self.tabs.addTab(self.analysis_scroll, 'Bandas e análise')
        self.import_button = QPushButton("Prévia e importar RGB (Alt+I)")
        self.import_button.setMinimumHeight(48)
        self.import_button.setMinimumWidth(280)
        self.import_button.setShortcut("Alt+I")
        self.import_button.setAutoDefault(False)
        self.import_button.setToolTip("Selecione uma cena e clique aqui ou pressione Alt+I para abrir a prévia e confirmar a importação.")
        self.import_button.setStyleSheet(
            "QPushButton {background:#1765a0;color:white;font-weight:bold;"
            "padding:8px 16px;border:2px solid #1765a0;border-radius:5px;}"
            "QPushButton:hover {background:#124f7e;}"
            "QPushButton:pressed {background:#0d3b5f;}"
            "QPushButton:focus {border:2px solid #ffbf47;}"
            "QPushButton:disabled {background:#dce3e8;color:#52616c;border-color:#b8c4ce;}")
        self.import_button.setEnabled(False)
        self.ndvi_button = QPushButton("Calcular NDVI da cena")
        self.ndvi_button.setEnabled(False)
        self.cancel_button = QPushButton("Cancelar tarefa"); self.cancel_button.setEnabled(False)
        self.ndvi_button.setMinimumHeight(44)
        self.cancel_button.setMinimumHeight(44)
        row = QHBoxLayout(); row.addWidget(self.import_button, 2)
        row.addWidget(self.ndvi_button); row.addWidget(self.cancel_button)
        page_layout.addLayout(row)
        self.info = QLabel("A prévia abre antes da importação. Bandas baixadas ficam no acervo para reutilização offline.")
        self.info.setWordWrap(True); page_layout.addWidget(self.info)
        self.refresh.clicked.connect(self.refresh_layers)
        self.search.clicked.connect(self.search_first)
        self.choose_archive.clicked.connect(self.select_archive_folder)
        self.sync_button.clicked.connect(self.sync_archive)
        self.offline.toggled.connect(self.source_changed)
        self.more.clicked.connect(self.search_more)
        self.import_button.clicked.connect(self.import_scene)
        self.ndvi_button.clicked.connect(self.import_ndvi)
        self.cancel_button.clicked.connect(self.cancel_job)
        self.table.itemSelectionChanged.connect(self.selection_changed)
        self.year_changed()
        self.refresh_layers()
        from .prodes_ui import ProdesDialog
        self.prodes_scroll = QScrollArea(self.tabs)
        self.prodes_scroll.setWidgetResizable(True)
        self.prodes_dialog = ProdesDialog(self.iface, self.prodes_scroll, embedded=True)
        self.prodes_scroll.setWidget(self.prodes_dialog)
        self.tabs.insertTab(1, self.prodes_scroll, 'PRODES')
        from .archive_ui import ArchiveTab
        self.archive_tab = ArchiveTab(self)
        self.tabs.addTab(self.archive_tab, 'Acervo offline')
        from .environmental_ui import EnvironmentalTab
        self.environmental_scroll = QScrollArea(self.tabs)
        self.environmental_scroll.setWidgetResizable(True)
        self.environmental_tab = EnvironmentalTab(self.iface, self.environmental_scroll)
        self.environmental_scroll.setWidget(self.environmental_tab)
        self.tabs.addTab(self.environmental_scroll, "Situação ambiental e fundiária")
        from .analysis_ui import QueueTab,ClassificationTab,TemporalTab
        from .cartography_ui import CartographyTab
        self.queue_tab = QueueTab(self)
        self.classification_tab = ClassificationTab(self)
        self.temporal_tab = TemporalTab(self)
        self.cartography_tab = CartographyTab(self)
        for title,widget in [('Classificação',self.classification_tab),('Comparação temporal',self.temporal_tab),('Cartas-imagem',self.cartography_tab)]:
            scroll=QScrollArea(self.tabs);scroll.setWidgetResizable(True);scroll.setWidget(widget);self.tabs.addTab(scroll,title)
        self.tabs.addTab(self.queue_tab,'Fila de tarefas')
        from .setup_ui import SetupTab
        self.setup_tab = SetupTab(self)
        setup_scroll = QScrollArea(self.tabs)
        setup_scroll.setWidgetResizable(True); setup_scroll.setWidget(self.setup_tab)
        self.tabs.insertTab(0, setup_scroll, 'Início')
        self.tabs.setCurrentIndex(0)

    def enqueue_command(self):
        try:
            from .parcel import snapshot
            plan=parse_command(self.command_text.text(),default_preset=self.preset.currentData() or 'prodes')
            if plan['action']!='download':raise CatalogError('A fila aceita comandos de download; investigação PRODES continua na aba própria.')
            parcel=snapshot(QgsProject.instance().mapLayer(self.layer_box.currentData()))
            plan['geometry_wkt']=parcel.geometry_wkt
            self.queue_tab.enqueue('download',{'plan':plan,'rect':list(parcel.rect),'crs':parcel.target_crs})
        except Exception as exc:self.command_error(str(exc))

    def inspect_selected_quality(self):
        try:
            from .parcel import snapshot
            row=self.table.currentRow()
            if row<0 or not self.archive:raise CatalogError('Selecione uma cena em Imagens.')
            parcel=snapshot(QgsProject.instance().mapLayer(self.layer_box.currentData()))
            if tuple(self.archive.rect)!=parcel.rect:raise CatalogError('O limite mudou. Refaça a busca antes de conferir QA.')
            item=self.scenes[row]
            self.run_job('quality',self.got_quality,item=item,folder=self.archive.scene_folder(item),rect=self.archive.rect,crs=self.archive.target_crs,geometry=parcel.geometry_wkt,offline=self.offline.isChecked())
        except Exception as exc:self.command_error(str(exc))

    def got_quality(self,quality):
        self.info.setText('QA dentro do imóvel: {:.1f}% de pixels válidos; {:.1f}% claros; {:.1f}% de nuvens. A máscara não comprova ausência de todos os problemas visuais.'.format(100*quality['valid_fraction'],100*quality['clear_fraction'],quality['cloud_percent']))

    def run_command(self):
        if self.job:return
        self.plan_command()
        if self.command_plan:self.execute_command()

    def clear_command_plan(self):
        self.command_plan = None
        self.execute_command_button.setEnabled(False)
        self.command_plan_label.setText("Use Executar comando para agir ou Ver plano para conferir.")

    def plan_command(self):
        try:
            self.command_plan = parse_command(self.command_text.text(), default_preset=self.preset.currentData() or "prodes")
            self.command_plan_label.setStyleSheet("")
            self.command_plan_label.setText(describe_plan(self.command_plan))
            self.execute_command_button.setEnabled(True)
        except Exception as exc:
            self.clear_command_plan()
            self.command_plan_label.setStyleSheet("color:#a32626")
            self.command_plan_label.setText(str(exc))
            self.info.setText(str(exc))

    def execute_command(self):
        if self.job or not self.command_plan:
            return
        plan = dict(self.command_plan)
        if plan['action'] == 'investigate':
            self.show_prodes()
            central = self.prodes_dialog
            if central.job or central.maps_in_progress:
                QMessageBox.warning(self, "Comando", "Uma investigação já está em execução.")
                return
            central.refresh_layers()
            index = central.property_box.findData(self.layer_box.currentData())
            if index >= 0: central.property_box.setCurrentIndex(index)
            central.agent_profile.setCurrentIndex(central.agent_profile.findData(plan['profile']))
            central.agent_enabled.setChecked(True)
            central.agent_offline.setChecked(plan['offline'])
            if plan.get('year'):
                central.all_years.setChecked(False)
                central.year.setValue(plan['year'])
            central.scene_cloud_limit.setValue(plan.get('cloud_max',20))
            central.scene_cloud_strict.setChecked(plan.get('cloud_strict',True))
            central.auto_export.setChecked(True)
            central.start_pipeline()
            return
        try:
            self.year.setCurrentIndex(0)
            self.start.setDate(QDate.fromString(plan['start'], 'yyyy-MM-dd'))
            self.end.setDate(QDate.fromString(plan['end'], 'yyyy-MM-dd'))
            self.landsat.setChecked('landsat-c2-l2' in plan['collections'])
            self.sentinel.setChecked(any(collection in plan['collections'] for collection in ('sentinel-2-l2a','sentinel-2-l2a-aws')))
            self.nasa_hls.setChecked(any(collection in plan['collections'] for collection in ('hls2-l30', 'hls2-s30')))
            self.offline.setChecked(plan['offline'])
            layer = QgsProject.instance().mapLayer(self.layer_box.currentData())
            features = list(layer.getSelectedFeatures()) if layer and layer.selectedFeatureCount() else (list(layer.getFeatures()) if layer else [])
            if len(features)!=1:raise CatalogError('Selecione uma única feição de imóvel para o comando, ou use uma camada contendo apenas esse imóvel.')
            geometry = QgsGeometry(features[0].geometry())
            if geometry.isEmpty() or not geometry.isGeosValid():raise CatalogError('Corrija a geometria do limite antes de executar o comando.')
            geometry.transform(QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem('EPSG:4326'), QgsProject.instance()))
            self.search_params = self.current_search()
            box=geometry.boundingBox()
            self.archive = LocalArchive(self.archive_path,(box.xMinimum(),box.yMinimum(),box.xMaximum(),box.yMaximum()),layer.crs().authid() or layer.crs().toWkt(),allow_legacy=plan['offline'])
            self.search_params['rect']=self.archive.rect
            self.command_import_context={'layer_id':layer.id(),'geometry':geometry.asWkt(),'preset':plan['preset'],'auto_import':plan.get('auto_import',False),'archive':self.archive,'feature_id':features[0].id(),'original_geometry':features[0].geometry().asWkt()}
            self.command_import_results=[]
            self.reset_results()
            self.pending_command_preset = plan['preset']
            self.run_job('command_batch' if plan['action']=='download' else 'command_search',
                self.got_command_batch if plan['action']=='download' else self.got_scenes,
                archive=self.archive, plan=dict(plan, geometry_wkt=geometry.asWkt()), hide_slc=self.hide_slc.isChecked())
        except Exception as exc:
            QMessageBox.warning(self, "Comando", str(exc))

    def got_command_batch(self, response):
        self.got_scenes((response['scenes'], None))
        results = response['receipt']['results']
        failures = sum(row['status']=='failed' for row in results)
        imported=sum(row.get('status')=='imported' for row in getattr(self,'command_import_results',[]))
        import_failures=sum(row.get('status')=='failed' for row in getattr(self,'command_import_results',[]))
        warnings=sum(row.get('quality',{}).get('valid_fraction',1) is not None and row.get('quality',{}).get('valid_fraction',1)<.98 for row in getattr(self,'command_import_results',[]))
        message = "Lote concluído: {} arquivos preparados; {} falhas de download; {} camadas importadas; {} falhas de importação; {} avisos de pixels. Manifesto: {}".format(len(results)-failures, failures, imported, import_failures, warnings, response['manifest'])
        if response['missing_years']: message += " · Anos sem imagem preparada (filtro, QA ou falha): " + ', '.join(map(str,response['missing_years']))
        if response['receipt'].get('source_warnings'):message += ' · Fontes incompletas: '+ '; '.join(response['receipt']['source_warnings'])
        message += ' · Candidatas rejeitadas/falhas: '+str(len(response['receipt'].get('attempts',[])))
        self.info.setText(message)
        self.command_plan_label.setText(message)
        if not results or failures or import_failures or response['missing_years']:
            QMessageBox.information(self, "Resultado do comando", message)


    def import_command_image(self, event):
        context=getattr(self,'command_import_context',{})
        if not context.get('auto_import'):return
        from .raster_quality import inspect_raster
        item=event['item'];record=event['result'];project=QgsProject.instance()
        outcome={'scene_id':record['scene_id'],'date':record['date'],'path':record['path']}
        try:
            anchor=project.mapLayer(context['layer_id'])
            if not anchor:raise CatalogError('O limite foi removido do projeto durante o download; camada não importada.')
            feature=anchor.getFeature(context['feature_id'])
            if not feature.isValid() or feature.geometry().asWkt()!=context['original_geometry']:raise CatalogError('O limite foi editado durante a tarefa. Arquivo salvo, mas não importado para evitar referência a outra geometria.')
            product=context['preset'] if context['preset'] in INDEX_PRODUCTS else 'rgb'
            signature='{}|{}|{}|{}'.format(context['archive'].area_id,record['scene_id'],product,','.join(record['bands']))
            title='{} · {} · {}'.format(context['preset'].upper(),record['date'],record['scene_id'])
            layer=QgsRasterLayer(record['path'],title,'gdal')
            if not layer.isValid() or layer.bandCount()!=(1 if product!='rgb' else 3):raise CatalogError('Raster inválido ou quantidade de bandas incorreta.')
            try:
                quality=inspect_raster(record['path'],context['geometry'])
            except Exception as exc:
                quality={'status':'inspection_failed','error':str(exc)}
            if quality.get('valid_fraction')==0:raise CatalogError('Raster sem pixels com dados na amostra do imóvel; não importado.')
            if quality.get('status') in ('missing_pixels','inspection_failed','insufficient_sample'):
                layer.setName(title+' [conferir qualidade]')
            layer.setCustomProperty('catalogo_multiespectral_qualidade',json.dumps(quality))
            layer.setCustomProperty('catalogo_multiespectral_fontes',json.dumps(item.get('catalog:sources',[])))
            if product=='rgb':self.configure_rgb(layer,False,item,record['bands'])
            else:self.configure_ndvi(layer)
            for existing in list(project.mapLayers().values()):
                if existing.customProperty('catalogo_multiespectral_assinatura','')==signature:project.removeMapLayer(existing.id())
            for key,value in [('assinatura',signature),('cena',record['scene_id']),('data',record['date']),('bandas',','.join(record['bands']))]:
                layer.setCustomProperty('catalogo_multiespectral_'+key,value)
            if product=='rgb':
                from .prodes_auto import scene_metadata
                try:layer.setCustomProperty('catalogo_multiespectral_espectral',json.dumps(scene_metadata(item,record['bands'],context['archive'].scene_folder(item))))
                except Exception as exc:
                    logging.getLogger(__name__).warning('Metadados espectrais não registrados: %s', exc)
                    outcome.setdefault('warnings', []).append('Metadados espectrais não registrados: '+str(exc))
            root=project.layerTreeRoot()
            group_name='Comando · '+context['preset'].upper()+' · '+context['archive'].area_id[:8]
            group=root.findGroup(group_name) or root.insertGroup(0,group_name)
            project.addMapLayer(layer,False);group.addLayer(layer)
            outcome.update(status='imported',layer_id=layer.id(),quality=quality)
            try:
                canvas=self.iface.mapCanvas()
                transform=QgsCoordinateTransform(QgsCoordinateReferenceSystem('EPSG:4326'),canvas.mapSettings().destinationCrs(),project)
                canvas.setExtent(transform.transformBoundingBox(QgsGeometry.fromWkt(context['geometry']).boundingBox()))
                canvas.refresh()
            except Exception as exc:
                logging.getLogger(__name__).warning('Camada importada; enquadramento do mapa não atualizado: %s', exc)
                outcome.setdefault('warnings', []).append('Enquadramento do mapa não atualizado: '+str(exc))
            self.info.setText('Importada no QGIS: '+record['date']+' · '+record['scene_id'])
        except Exception as exc:
            outcome.update(status='failed',error=str(exc))
        self.command_import_results.append(outcome)
        path=event['manifest']+'.importacao.json'
        try:
            with open(path+'.part','w',encoding='utf8') as stream:json.dump(self.command_import_results,stream,ensure_ascii=False,indent=2)
            os.replace(path+'.part',path)
        except OSError as exc:self.info.setText('Não foi possível registrar a importação: '+str(exc))

    def show_prodes(self):
        self.tabs.setCurrentWidget(self.prodes_scroll)
        self.prodes_dialog.refresh_layers()
        self.show()
        self.raise_()
        self.activateWindow()

    def choose_analysis_preset(self, preset):
        if self.job:
            return
        index = self.preset.findData(preset)
        if index < 0:
            self.info.setText('Selecione em Imagens uma cena com as bandas necessárias.')
            return
        self.preset.setCurrentIndex(index)
        self.tabs.setCurrentWidget(self.imagery_page)
        self.import_scene()

    def import_bandset(self):
        if self.job:
            return
        row = self.table.currentRow()
        if not 0 <= row < len(self.scenes):
            self.band_set_info.setText('Selecione uma cena em Imagens antes de baixar o Band Set.')
            return
        from .radiometry import band_set
        item = self.scenes[row]
        keys = band_set(item)
        if not keys:
            return
        self.bandset_context = (item, keys)
        self.run_job('download', self.got_bandset, archive=self.archive, item=item,
                     rgb_keys=keys, product='bandset', offline=self.offline.isChecked(),
                     force_download=self.repair.isChecked())

    def got_bandset(self, response):
        item, keys = self.bandset_context
        layer = QgsRasterLayer(response[2], item['id'] + ' · Band Set espectral', 'gdal')
        if not layer.isValid():
            self.command_error('Não foi possível abrir o Band Set concluído.')
            return
        from .stac import natural_rgb_keys
        rgb = natural_rgb_keys(item)
        if rgb:
            self.configure_rgb(layer,False,item,rgb,tuple(keys.index(key)+1 for key in rgb))
        for number, key in enumerate(keys, 1):
            layer.setCustomProperty("catalogo_banda_" + str(number), key)
        layer.setCustomProperty('catalogo_multiespectral_band_set', json.dumps(keys))
        from .prodes_auto import scene_metadata
        layer.setCustomProperty('catalogo_multiespectral_espectral',json.dumps(scene_metadata(item,keys,self.archive.scene_folder(item))))
        layer.setCustomProperty('catalogo_multiespectral_data',str(item.get('properties',{}).get('datetime',''))[:10])
        layer.setCustomProperty('catalogo_multiespectral_cena',item.get('id',''))
        signature=self.archive.area_id+'|'+item.get('collection','')+'|'+item['id']+'|bandset'
        project=QgsProject.instance()
        for existing in list(project.mapLayers().values()):
            if existing.customProperty('catalogo_multiespectral_assinatura','')==signature:
                project.removeMapLayer(existing.id())
        layer.setCustomProperty('catalogo_multiespectral_assinatura',signature)
        project.addMapLayer(layer)
        self.info.setText('Band Set importado em ordem espectral. Bandas originais preservadas no acervo.')
        self.band_set_info.setText(self.info.text())

    def year_changed(self):
        year = self.year.currentData()
        if year == -1:
            self.start.setDate(QDate(1982, 1, 1))
            self.end.setDate(QDate.currentDate())
        elif year:
            self.start.setDate(QDate(year, 1, 1))
            self.end.setDate(QDate.currentDate() if year == date.today().year else QDate(year, 12, 31))

    def reset_results(self):
        self.preview_generation += 1
        self.preview_queue.clear()
        for job in list(self.preview_replies):
            job.cancel()
        self.scenes = []
        self.next_link = None
        self.band_scene_id = None
        self.table.setRowCount(0)
        self.preview_large.clear()
        self.more.setEnabled(False)
        self.update_import_button()

    def source_changed(self):
        self.preview_generation += 1
        self.preview_queue.clear()
        for reply in list(self.preview_replies):
            reply.cancel()
        self.reset_results()
        self.sync_button.setEnabled(not self.offline.isChecked() and self.job is None)
        self.repair.setEnabled(not self.offline.isChecked())
        if self.offline.isChecked():
            self.repair.setChecked(False)
        self.search.setText("Buscar no acervo local" if self.offline.isChecked() else "Buscar imagens com nuvens < 20%")

    def select_archive_folder(self):
        if self.workers():
            self.info.setText('Aguarde ou cancele as tarefas antes de trocar a pasta do acervo.')
            return
        folder = QFileDialog.getExistingDirectory(self, "Pasta do acervo local", self.archive_path)
        if folder:
            try:
                folder = writable_directory(folder)
            except CatalogError as exc:
                self.archive_notice.setText(str(exc))
                self.archive_notice.show()
                return
            self.archive_path = folder
            QgsSettings().setValue("catalogo_multiespectral/acervo", folder)
            self.archive_label.setText(folder)
            self.archive_notice.clear()
            self.archive_notice.hide()
            self.archive = None
            self.reset_results()
            self.archive_tab.folder.setText(folder)
            self.archive_tab.rows = []
            self.archive_tab.table.setRowCount(0)
            self.queue_tab.refresh()

    def current_search(self):
        if self.start.date() > self.end.date():
            raise CatalogError("A data inicial precisa ser anterior à data final.")
        rect = self.area()
        layer = QgsProject.instance().mapLayer(self.layer_box.currentData())
        crs = layer.crs().authid() or layer.crs().toWkt()
        self.archive = LocalArchive(self.archive_path, rect, crs, allow_legacy=self.offline.isChecked())
        self.search_layer_id = layer.id()
        return {"collections": self.collections(), "rect": rect,
                "start": self.start.date().toString("yyyy-MM-dd"),
                "end": self.end.date().toString("yyyy-MM-dd")}

    def sync_archive(self):
        if self.job or self.offline.isChecked():
            return
        try:
            params = self.current_search()
        except Exception as exc:
            QMessageBox.warning(self, "Acervo local", str(exc)); return
        self.search_params = params
        self.reset_results()
        self.run_job("sync", self.got_sync, archive=self.archive,
                     collections=params["collections"], start=params["start"], end=params["end"])

    def got_sync(self, result):
        self.got_scenes((result["items"], None))
        self.info.setText("Acervo atualizado: {} cenas completas; {} com falhas. Pasta: {}".format(
            result["completed"], len(result["errors"]), self.archive_path))
        if result["errors"]:
            QMessageBox.warning(self, "Atualização parcial do acervo",
                "Os arquivos concluídos foram mantidos. Atualize novamente para tentar as bandas faltantes.\n\n" +
                "\n".join(result["errors"][:8]))

    def selection_changed(self):
        row = self.table.currentRow()
        if row < 0 or row >= len(self.scenes):
            self.preview_large.setText("Selecione uma cena para ver a prévia ampliada")
            self.band_scene_id = None
            self.update_import_button()
            return
        scene = self.scenes[row]
        self.false_color.setText(prodes_label(scene))
        from .radiometry import band_set, correction_policy
        self.band_set_info.setText('Band Set: ' + ' → '.join(band_set(scene)) + '\n' + correction_policy(scene)['reason'])
        if self.band_scene_id != scene.get("id"):
            self.band_scene_id = scene.get("id")
            for combo in self.rgb_boxes:
                combo.clear()
                for key, asset in available_bands(scene):
                    combo.addItem(band_label(key, asset), key)
            self.preset.blockSignals(True)
            self.preset.clear()
            for identifier, label, keys in PRESETS:
                selected = preset_keys(scene, identifier)
                if selected:
                    bands = dict(available_bands(scene))
                    names = [str((bands[key].get("eo:bands") or [{}])[0].get("name", key)) for key in selected]
                    self.preset.addItem(label + " — " + " / ".join(names), identifier)
            for product in INDEX_PRODUCTS:
                if index_keys(scene, product):
                    from .spectral import INDEX_DEFINITIONS
                    self.preset.addItem(INDEX_DEFINITIONS[product][0], product)
                    self.preset.setItemData(self.preset.count()-1,INDEX_DEFINITIONS[product][3],Qt.ItemDataRole.ToolTipRole)
            self.preset.addItem("Personalizada — escolher R, G e B", "custom")
            self.preset.blockSignals(False)
            self.apply_preset()
        self.update_import_button()
        url = preview_url(scene, 560)
        local = os.path.join(self.archive.scene_folder(scene), "miniatura_560.png") if self.archive else ""
        if local and os.path.isfile(local):
            self.show_large(QPixmap(local))
            return
        if self.offline.isChecked():
            self.preview_large.setText("{}\nClique em ‘Ver prévia no mapa’ para conferir a cena com o limite do imóvel.".format(
                self.archive.status(scene)))
            return
        self.preview_large.setText("Carregando prévia…")
        if url in self.preview_cache:
            self.show_large(self.preview_cache[url])
        elif url:
            self.preview_queue.insert(0, (row, url, self.preview_generation, True))
            self.pump_previews()

    def apply_preset(self):
        row = self.table.currentRow()
        if not 0 <= row < len(self.scenes):
            return
        product = self.preset.currentData()
        if product not in (*INDEX_PRODUCTS, "custom"):
            self.set_rgb(preset_keys(self.scenes[row], product))
        is_index = product in INDEX_PRODUCTS
        for combo in self.rgb_boxes:
            combo.setEnabled(not is_index)
        self.import_button.setText("Prévia e importar " + (product.upper() if is_index else "RGB") + " (Alt+I)")
        self.import_button.setShortcut("Alt+I")
        self.update_import_button()

    def set_rgb(self, keys):
        if len(keys) != 3:
            return
        for combo, key in zip(self.rgb_boxes, keys):
            index = combo.findData(key)
            if index >= 0:
                combo.setCurrentIndex(index)

    def show_large(self, pixmap):
        if not pixmap.isNull():
            self.preview_large.setPixmap(pixmap.scaled(320, 320,
                Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))

    def pump_previews(self):
        if self.offline.isChecked():
            self.preview_queue.clear()
            return
        while self.preview_active < 4 and self.preview_queue:
            row, url, generation, large = self.preview_queue.pop(0)
            if generation != self.preview_generation:
                continue
            if url in self.preview_cache:
                self.apply_preview(row, url, generation, large, self.preview_cache[url])
                continue
            job = ThumbnailJob(url)
            self.preview_replies.add(job)
            self.preview_active += 1
            job.result.connect(lambda data, idx=row, u=url, gen=generation, big=large:
                self.preview_finished(data, idx, u, gen, big))
            job.failed.connect(lambda message, idx=row, gen=generation: self.preview_error(idx,gen))
            job.done.connect(lambda worker=job: self.preview_done(worker))
            job.start()

    def preview_error(self,row,generation):
        if generation==self.preview_generation and row<self.table.rowCount():
            item=self.table.item(row,0)
            if item:item.setText('Miniatura indisponível · use a prévia no mapa')

    def preview_done(self,job):
        self.preview_active -= 1
        self.preview_replies.discard(job)
        self.pump_previews()

    def preview_finished(self, data, row, url, generation, large):
        pixmap = QPixmap()
        pixmap.loadFromData(data)
        if not pixmap.isNull():
            self.preview_cache[url] = pixmap
            if generation == self.preview_generation and self.archive and row < len(self.scenes):
                folder = self.archive.scene_folder(self.scenes[row])
                try:
                    os.makedirs(folder, exist_ok=True)
                    pixmap.save(os.path.join(folder, 'miniatura_{}.png'.format(560 if large else 180)))
                except OSError:
                    logging.getLogger(__name__).warning('Não foi possível salvar a miniatura no acervo.')
            self.apply_preview(row, url, generation, large, pixmap)
        else:
            self.preview_error(row,generation)

    def apply_preview(self, row, url, generation, large, pixmap):
        if generation != self.preview_generation:
            return
        if large:
            if row == self.table.currentRow():
                self.show_large(pixmap)
        elif row < self.table.rowCount():
            item = self.table.item(row, 0)
            if item:
                item.setText("")
                item.setIcon(QIcon(pixmap.scaled(152, 110,
                    Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)))

    def refresh_layers(self):
        current = self.layer_box.currentData(); self.layer_box.clear()
        layers = [layer for layer in QgsProject.instance().mapLayers().values()
                  if isinstance(layer, QgsVectorLayer) and layer.isValid() and not layer.customProperty("catalogo_layout_aux",False) and
                  layer.geometryType() == QgsWkbTypes.GeometryType.PolygonGeometry]
        for layer in sorted(layers, key=lambda layer: layer.name().lower()):
            self.layer_box.addItem(layer.name(), layer.id())
        index = self.layer_box.findData(current) if current else -1
        if index < 0:
            selected = [layer for layer in layers if layer.selectedFeatureCount()]
            if len(selected) == 1: index = self.layer_box.findData(selected[0].id())
        if index >= 0: self.layer_box.setCurrentIndex(index)

    def area(self):
        layer = QgsProject.instance().mapLayer(self.layer_box.currentData())
        if not layer or not layer.isValid() or layer.featureCount() == 0:
            raise CatalogError("Selecione uma camada poligonal do imóvel com feições.")
        if not layer.crs().isValid():
            raise CatalogError("Defina o SRC da camada do imóvel antes da busca.")
        features = list(layer.getSelectedFeatures()) if layer.selectedFeatureCount() else list(layer.getFeatures())
        if len(features) != 1:
            raise CatalogError('Selecione uma única feição de imóvel, ou use uma camada contendo somente esse imóvel.')
        geometry = QgsGeometry(features[0].geometry())
        if geometry.isEmpty() or not geometry.isGeosValid():
            raise CatalogError('Corrija a geometria do limite do imóvel antes de consultar.')
        geometry.transform(QgsCoordinateTransform(layer.crs(),
            QgsCoordinateReferenceSystem('EPSG:4326'), QgsProject.instance()))
        extent = geometry.boundingBox()
        return (extent.xMinimum(), extent.yMinimum(), extent.xMaximum(), extent.yMaximum())

    def collections(self):
        chosen = []
        if self.landsat.isChecked(): chosen.append("landsat-c2-l2")
        if self.sentinel.isChecked(): chosen.extend(("sentinel-2-l2a", 'sentinel-2-l2a-aws'))
        if self.nasa_hls.isChecked(): chosen.extend(('hls2-l30', 'hls2-s30'))
        if not chosen: raise CatalogError("Selecione Landsat, Sentinel-2 ou NASA HLS.")
        return chosen

    def run_job(self, action, callback, **kwargs):
        if self.job: return
        self.job = Job(action, **kwargs)
        self.job.status.connect(self.info.setText)
        if action=="command_batch":self.job.prepared.connect(self.import_command_image)
        self.job.result.connect(callback)
        self.job.failed.connect(self.command_error)
        self.job.done.connect(self.finished_job)
        self.set_busy(True); self.job.start()

    def command_error(self, message):
        self.info.setText('Tarefa interrompida: '+message)
        self.command_plan_label.setText('Tarefa interrompida: '+message)
        QMessageBox.warning(self, 'Imagens públicas', message)

    def finished_job(self):
        stopped=self.job.stopping
        self.job = None; self.set_busy(False)
        if stopped:
            self.info.setText('Tarefa cancelada. Arquivos concluídos e {} camadas já importadas foram preservados.'.format(sum(v.get('status')=='imported' for v in getattr(self,'command_import_results',[]))))
        if getattr(self, 'pending_command_preset', None) and self.scenes:
            self.table.selectRow(0)
            index = self.preset.findData(self.pending_command_preset)
            if index >= 0: self.preset.setCurrentIndex(index)
        self.pending_command_preset = None

    def set_busy(self, busy):
        for widget in (self.command_text, self.plan_button, self.execute_command_button, self.run_command_button,
                       self.layer_box, self.refresh, self.landsat, self.sentinel, self.nasa_hls,
                       self.start, self.end, self.year, self.search, self.more,
                       self.import_button, self.ndvi_button, self.bandset_button,
                       self.offline, self.choose_archive, self.sync_button,
                       self.false_color, self.natural_color, self.smooth_rgb, self.preset, self.hide_slc, self.repair,
                       *self.rgb_boxes, self.table):
            widget.setEnabled(not busy)
        self.execute_command_button.setEnabled(not busy and self.command_plan is not None)
        self.cancel_button.setEnabled(busy)
        if not busy:
            self.more.setEnabled(bool(self.next_link))
            self.apply_preset()
            self.sync_button.setEnabled(not self.offline.isChecked())
            self.repair.setEnabled(not self.offline.isChecked())

    def update_import_button(self):
        row = self.table.currentRow()
        ready = 0 <= row < len(self.scenes) and self.job is None
        self.import_button.setEnabled(ready and
            all(combo.currentData() for combo in self.rgb_boxes))
        self.ndvi_button.setEnabled(ready and bool(ndvi_keys(self.scenes[row])) if ready else False)

    def cancel_job(self):
        if self.job:
            self.job.cancel(); self.info.setText("Cancelando…")

    def search_first(self):
        try:
            params = self.current_search()
        except Exception as exc:
            QMessageBox.warning(self, "Imagens públicas", str(exc)); return
        self.search_params = params
        self.reset_results()
        if self.offline.isChecked():
            self.run_job("local", self.got_scenes, archive=self.archive,
                         collections=params["collections"], start=params["start"], end=params["end"])
        else:
            self.run_job("search", self.got_scenes, **params)

    def search_more(self):
        if self.next_link and self.search_params and not self.offline.isChecked():
            self.run_job("search", self.got_scenes, next_link=self.next_link,
                         **self.search_params)

    def got_scenes(self, response):
        scenes, self.next_link = response
        if self.archive and not self.offline.isChecked():
            self.archive.remember_many(scenes)
        seen = {(item.get("collection"), item.get("id")) for item in self.scenes}
        for scene in scenes:
            if self.hide_slc.isChecked() and slc_gap_scene(scene):
                continue
            identity = (scene.get("collection"), scene.get("id"))
            if identity in seen:
                existing=next(item for item in self.scenes if (item.get('collection'),item.get('id'))==identity)
                existing.update(merge_scenes([existing,scene])[0])
                row=self.scenes.index(existing)
                self.table.setItem(row,5,QTableWidgetItem(str(existing.get('id',''))+' · '+ '/'.join(existing.get('catalog:sources',[]))))
                continue
            seen.add(identity)
            props = scene.get("properties", {})
            acquired = str(props.get("datetime", ""))[:10]
            cloud = props.get("eo:cloud_cover")
            row = self.table.rowCount(); self.table.insertRow(row)
            fields = [acquired[:4], acquired,
                      (scene.get('catalog:product') or str(props.get("platform") or scene.get("collection", ""))) + (" ⚠ SLC-off" if slc_gap_scene(scene) else ""),
                      "{:.1f}%".format(float(cloud)), str(scene.get("id", "")) + " · " + "/".join(scene.get("catalog:sources", []))]
            self.table.setRowHeight(row, 118)
            self.table.setItem(row, 0, QTableWidgetItem("Ver no mapa" if self.offline.isChecked() else "Carregando…"))
            for col, value in enumerate(fields, 1):
                self.table.setItem(row, col, QTableWidgetItem(value))
            self.scenes.append(scene)
            self.table.setItem(row, 6, QTableWidgetItem(self.archive.status(scene)))
            url = preview_url(scene, 180)
            local = os.path.join(self.archive.scene_folder(scene), "miniatura_180.png")
            if os.path.isfile(local):
                self.apply_preview(row, url, self.preview_generation, False, QPixmap(local))
            elif url and not self.offline.isChecked():
                self.preview_queue.append((row, url, self.preview_generation, False))
        self.pump_previews()
        self.more.setEnabled(bool(self.next_link))
        self.info.setText("{} cenas com menos de 20% de nuvens listadas. {}".format(
            len(self.scenes), "Há mais resultados." if self.next_link else "Fim da busca."))
        source_warnings=getattr(scenes,'warnings',[])
        if source_warnings:self.info.setText(self.info.text()+' · Fontes incompletas: '+ '; '.join(source_warnings))
        if self.archive and self.archive.uses_legacy_extent and self.offline.isChecked():
            self.info.setText("Acervo anterior: a suavização está disponível; para obter o novo recorte horizontal, desmarque offline e baixe/atualize a área uma vez.")
        if not self.scenes and self.offline.isChecked():
            self.info.setText("Não há cenas locais para esta área e período. Desmarque offline e baixe/atualize o acervo.")

    def import_scene(self):
        self.import_product(self.preset.currentData() if self.preset.currentData() in INDEX_PRODUCTS else "rgb")

    def import_ndvi(self):
        self.import_product("ndvi")

    def import_product(self, product):
        row = self.table.currentRow()
        if row < 0 or row >= len(self.scenes): return
        self.active_scene = self.scenes[row]
        selected_rgb = tuple(combo.currentData() for combo in self.rgb_boxes)
        if product in INDEX_PRODUCTS:
            selected_rgb = index_keys(self.active_scene, product)
            if not selected_rgb:
                QMessageBox.warning(self, "Catálogo Multiespectral", "Esta cena não oferece as bandas necessárias ao índice selecionado.")
                return
        property_layer = QgsProject.instance().mapLayer(self.layer_box.currentData())
        if property_layer is None:
            QMessageBox.warning(self, "Catálogo Multiespectral", "A camada do imóvel foi removida.")
            return
        crs = property_layer.crs()
        try:
            archive = LocalArchive(self.archive_path, self.area(), crs.authid() or crs.toWkt(),
                                   allow_legacy=self.offline.isChecked())
            if not self.archive or archive.area_id != self.archive.area_id or property_layer.id() != self.search_layer_id:
                raise CatalogError("O imóvel mudou desde a busca. Busque novamente antes de abrir a prévia.")
        except Exception as exc:
            QMessageBox.warning(self, "Catálogo Multiespectral", str(exc)); return
        self.active_archive = archive
        self.active_layer_id = property_layer.id()
        self.active_product = product
        self.active_bands = selected_rgb
        self.run_job("download", self.got_rasters, item=self.active_scene,
            archive=archive, rgb_keys=selected_rgb, product=product,
            offline=self.offline.isChecked(), force_download=self.repair.isChecked())

    def got_rasters(self, result):
        files, errors, composite = result
        acquired = (self.active_scene or {}).get("properties", {}).get("datetime", "")[:10]
        scene_id = (self.active_scene or {}).get("id", "cena")
        signature = "{}|{}|{}|{}".format(self.active_archive.area_id, scene_id,
                                          self.active_product, ",".join(self.active_bands))
        label = (self.active_product.upper() if self.active_product in INDEX_PRODUCTS else
                 "RGB {}".format("/".join(self.active_bands)))
        layer = QgsRasterLayer(composite, "{} | {} | {}".format(label, acquired, scene_id), "gdal")
        expected_bands = 1 if self.active_product in INDEX_PRODUCTS else 3
        if not layer.isValid() or layer.bandCount() != expected_bands:
            QMessageBox.warning(self, "Catálogo Multiespectral", "O QGIS não conseguiu abrir o raster {}.".format(label))
            return
        if self.active_product in INDEX_PRODUCTS:
            self.configure_index(layer,self.active_product)
        else:
            self.configure_rgb(layer, self.smooth_rgb.isChecked(), self.active_scene, self.active_bands)
        project = QgsProject.instance()
        property_layer = project.mapLayer(self.active_layer_id)
        if property_layer is None:
            QMessageBox.warning(self, "Prévia", "A camada do imóvel foi removida. Faça uma nova busca.")
            return
        props = self.active_scene.get("properties", {})
        description = "{} | {} | {} | Nuvens: {:.1f}% | {}".format(
            acquired, props.get("platform", ""), label, float(props.get("eo:cloud_cover", 0)), scene_id)
        if slc_gap_scene(self.active_scene):
            description += " | ATENÇÃO: lacunas reais do sensor Landsat 7 (SLC-off)"
        try:
            from .raster_quality import inspect_raster
            features = list(property_layer.getFeatures())
            geometry = QgsGeometry.unaryUnion([f.geometry() for f in features])
            geometry.transform(QgsCoordinateTransform(property_layer.crs(), QgsCoordinateReferenceSystem('EPSG:4326'), project))
            quality = inspect_raster(composite, geometry.asWkt())
            layer.setCustomProperty('catalogo_multiespectral_qualidade', json.dumps(quality))
            if quality.get('valid_fraction') is not None:
                description += ' | Pixels com dados no imóvel (amostra): {:.1f}%'.format(100*quality['valid_fraction'])
                if quality['valid_fraction'] < .98:
                    QMessageBox.warning(self, 'Pixels sem dados', 'A inspeção encontrou pixels sem dados em uma ou mais bandas dentro do imóvel. Confira a prévia e escolha outra cena se a lacuna atingir sua área de classificação. Não haverá preenchimento artificial.')
            else: description += ' | Amostra insuficiente para verificar pixels sem dados'
        except Exception as exc:
            description += ' | Inspeção de pixels indisponível: ' + str(exc)
        if errors:
            description += ' | Avisos de aquisição: ' + '; '.join(errors[:2])
        try:
            preview = PreviewDialog(layer, property_layer, description, self.iface,
                                    self.offline.isChecked(), self)
        except Exception as exc:
            QMessageBox.warning(self, "Prévia", "Não foi possível desenhar o limite: " + str(exc))
            return
        accepted = preview.exec() == QDialog.DialogCode.Accepted
        preview.deleteLater()
        for row, item in enumerate(self.scenes):
            self.table.setItem(row, 6, QTableWidgetItem(self.archive.status(item)))
        if not accepted:
            self.info.setText("Prévia fechada. A cena ficou no acervo; selecione outra para comparar.")
            return
        for existing in list(project.mapLayers().values()):
            if existing.customProperty("catalogo_multiespectral_assinatura", "") == signature:
                project.removeMapLayer(existing.id())
        layer.setCustomProperty("catalogo_multiespectral_assinatura", signature)
        layer.setCustomProperty("catalogo_multiespectral_cena", scene_id)
        layer.setCustomProperty("catalogo_multiespectral_fontes", json.dumps(item.get("catalog:sources", [])))
        layer.setCustomProperty("catalogo_multiespectral_data", acquired)
        layer.setCustomProperty("catalogo_multiespectral_bandas", ",".join(self.active_bands))
        if self.active_product == "rgb":
            from .prodes_auto import scene_metadata
            try:
                spectral = scene_metadata(self.active_scene, list(self.active_bands),
                    self.active_archive.scene_folder(self.active_scene))
                layer.setCustomProperty("catalogo_multiespectral_espectral", json.dumps(spectral))
            except Exception:
                logging.getLogger(__name__).warning("Calibração automática indisponível nesta cena; RGB preservado.")
        project.addMapLayer(layer, False)
        root = project.layerTreeRoot()
        property_node = root.findLayer(self.active_layer_id)
        parent = property_node.parent() if property_node else root
        insertion = parent.children().index(property_node) + 1 if property_node else 0
        parent.insertLayer(insertion, layer)
        try:
            canvas = self.iface.mapCanvas()
            transform = QgsCoordinateTransform(layer.crs(), project.crs(), project)
            canvas.setExtent(transform.transformBoundingBox(layer.extent()))
            canvas.refresh()
        except Exception:
            self.iface.mapCanvas().refresh()
        self.info.setText("{} importado para {}. Arquivos preservados no acervo local.".format(label, acquired))

    @staticmethod
    def configure_index(layer,product):
        from .spectral import style_index
        style_index(layer,product)

    @staticmethod
    def configure_ndvi(layer):
        colors = [(-1.0, "#312c51", "−1,00"),
                  (-0.2, "#8d6e99", "−0,20"),
                  (0.0, "#d7b8ac", "0,00"),
                  (0.2, "#e9dba0", "0,20"),
                  (0.4, "#afd26b", "0,40"),
                  (0.6, "#4d9d42", "0,60"),
                  (1.0, "#155b35", "1,00")]
        ramp = QgsColorRampShader(-1, 1)
        ramp.setColorRampType(QgsColorRampShader.Type.Interpolated)
        ramp.setColorRampItemList([QgsColorRampShader.ColorRampItem(value,
            QColor(color), label) for value, color, label in colors])
        shader = QgsRasterShader(-1, 1)
        shader.setRasterShaderFunction(ramp)
        layer.setRenderer(QgsSingleBandPseudoColorRenderer(layer.dataProvider(), 1, shader))
        layer.triggerRepaint()

    @staticmethod
    def configure_rgb(layer, smooth=False, item=None, keys=None, band_numbers=(1,2,3)):
        provider = layer.dataProvider()
        renderer = QgsMultiBandColorRenderer(provider, *band_numbers)
        # Persist display limits; reopening the same composition avoids rescans.
        source = layer.source()
        stats_file = source + ".contraste.json"
        signature, limits = None, {}
        try:
            folder = os.path.dirname(source)
            signature = sorted((name, os.stat(os.path.join(folder, name)).st_mtime_ns,
                                os.stat(os.path.join(folder, name)).st_size)
                               for name in os.listdir(folder)
                               if name.endswith((".tif", ".vrt")))
            signature = [list(value) for value in signature]
            with open(stats_file, encoding="utf-8") as stream:
                cached = json.load(stream)
            if cached.get("signature") == signature:
                limits = cached.get("limits", {})
        except (OSError, ValueError, TypeError):
            limits = {}  # Missing/invalid cached display limits are recalculated.
        natural = None
        if item is not None:
            from .catalog_quality import natural_limits
            natural = natural_limits(item, keys)
        if natural is not None:
            limits = {}
            for channel,band in enumerate(band_numbers,1):
                scale,offset=provider.bandScale(band),provider.bandOffset(band)
                limits[str(channel)]=[value*scale+offset for value in natural[str(channel)]]
            signature = None  # Do not reuse or overwrite independent-channel stretch.
            layer.setCustomProperty('catalogo_multiespectral_contraste', 'Cor natural: reflectância comum 0–0,30; sem alterar DN')
        setters=(renderer.setRedContrastEnhancement,renderer.setGreenContrastEnhancement,renderer.setBlueContrastEnhancement)
        for channel,(band,setter) in enumerate(zip(band_numbers,setters),1):
            try:
                if str(channel) in limits:
                    low, high = limits[str(channel)]
                else:
                    low, high = provider.cumulativeCut(band, 0.02, 0.98, layer.extent(), 262144)
                if high <= low:
                    stats = provider.bandStatistics(band)
                    low, high = stats.minimumValue, stats.maximumValue
                if high <= low and item is not None and keys and channel <= len(keys):
                    from .stac import reflectance_coefficients
                    scale,offset=reflectance_coefficients(item,keys[channel-1])
                    limits_raw=[(value-offset)/scale for value in (0,.4)]
                    low,high=[value*provider.bandScale(band)+provider.bandOffset(band) for value in limits_raw]
                if math.isfinite(low) and math.isfinite(high) and high > low:
                    limits[str(channel)] = [low, high]
                    enhancement = QgsContrastEnhancement(provider.dataType(band))
                    enhancement.setContrastEnhancementAlgorithm(
                        QgsContrastEnhancement.ContrastEnhancementAlgorithm.StretchToMinimumMaximum)
                    enhancement.setMinimumValue(low)
                    enhancement.setMaximumValue(high)
                    setter(enhancement)
            except Exception:
                logging.getLogger(__name__).warning("Não foi possível calcular o contraste da banda %s.", band)
        layer.setRenderer(renderer)
        resampling = layer.resampleFilter()
        if resampling:
            resampling.setZoomedInResampler(QgsCubicRasterResampler() if smooth else None)
            resampling.setZoomedOutResampler(QgsBilinearRasterResampler() if smooth else None)
            resampling.setMaxOversampling(2.0)
        layer.triggerRepaint()
        if signature is not None and len(limits) == 3:
            try:
                with open(stats_file + ".part", "w", encoding="utf-8") as stream:
                    json.dump({"signature": signature, "limits": limits}, stream, allow_nan=False)
                os.replace(stats_file + ".part", stats_file)
            except (OSError, ValueError):
                logging.getLogger(__name__).warning("Não foi possível salvar os limites de contraste.")

    def workers(self):
        return [worker for worker in (self.job, self.prodes_dialog.job,
                self.environmental_tab.job, self.archive_tab.job, self.queue_tab.job) if worker]

    def closeEvent(self, event):
        workers = self.workers()
        if self.prodes_dialog.maps_in_progress:
            self.prodes_dialog.cancel()
            event.ignore()
            return
        if workers:
            for worker in workers:
                worker.cancel()
                worker.done.connect(self.close)
            event.ignore()
            return
        self.preview_generation += 1
        self.preview_queue.clear()
        for job in list(self.preview_replies):
            job.detach()
        self.preview_replies.clear()
        self.preview_active = 0
        self.prodes_dialog.canvas.stopRendering()
        self.prodes_dialog.canvas.setLayers([])
        super().closeEvent(event)


class USGSCatalogPlugin:
    def __init__(self, iface):
        self.iface, self.action, self.dialog = iface, None, None
        self.prodes_action = None

    def initGui(self):
        self.action = QAction(QIcon(os.path.join(os.path.dirname(__file__), "icon.png")),
                              "Catálogo Multiespectral — bandas, água e cartas", self.iface.mainWindow())
        self.action.triggered.connect(self.show_dialog)
        self.iface.addPluginToRasterMenu("Catálogo Multiespectral", self.action)
        self.iface.addToolBarIcon(self.action)
        self.prodes_action = QAction("Analisar PRODES", self.iface.mainWindow())
        self.prodes_action.triggered.connect(self.show_prodes)
        self.iface.addPluginToRasterMenu("Catálogo Multiespectral", self.prodes_action)

    def show_prodes(self):
        if self.dialog is None:
            from .simple_ui import SimpleCatalogDialog
            self.dialog = SimpleCatalogDialog(self.iface, self.iface.mainWindow())
        self.dialog.show_prodes()

    def show_dialog(self):
        if self.dialog is None:
            from .simple_ui import SimpleCatalogDialog
            self.dialog = SimpleCatalogDialog(self.iface, self.iface.mainWindow())
        self.dialog.show(); self.dialog.raise_(); self.dialog.activateWindow()

    def unload(self):
        self.iface.removePluginRasterMenu("Catálogo Multiespectral", self.action)
        self.iface.removeToolBarIcon(self.action)
        if self.prodes_action:
            self.iface.removePluginRasterMenu("Catálogo Multiespectral", self.prodes_action)
        if self.dialog:
            for worker in self.dialog.workers():
                worker.detach()
            self.dialog.job = None
            self.dialog.prodes_dialog.job = None
            self.dialog.prodes_dialog.map_stopping = True
            self.dialog.prodes_dialog.maps_in_progress = False
            self.dialog.prodes_dialog.canvas.stopRendering()
            self.dialog.prodes_dialog.canvas.setLayers([])
            self.dialog.environmental_tab.job = None
            self.dialog.environmental_tab.timer.stop()
            self.dialog.archive_tab.job = None
            self.dialog.queue_tab.job = None
            self.dialog.close()
            self.dialog.deleteLater()
            self.dialog = None
