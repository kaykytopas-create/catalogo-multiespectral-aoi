# SPDX-License-Identifier: GPL-2.0-or-later
import copy
import os
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
from osgeo import gdal, osr
from usgs_catalogo_qgis.hls import normalize_hls, fmask_flags
from usgs_catalogo_qgis.stac import (PublicCatalog, preset_keys, index_keys,
    reflectance_coefficients, available_bands, write_index)
from usgs_catalogo_qgis.radiometry import band_set, correction_policy
from usgs_catalogo_qgis.prodes_auto import qa_valid, scene_metadata, metadata_for_layer
from usgs_catalogo_qgis.prodes import ProdesError
from usgs_catalogo_qgis.catalog_quality import inspect_qa
from usgs_catalogo_qgis.commands import parse_command


def raw_hls(collection='hls2-s30'):
    keys = (['B01','B02','B03','B04','B05','B06','B07','B09','B10','B11']
            if collection == 'hls2-l30' else
            ['B01','B02','B03','B04','B05','B06','B07','B08','B8A','B09','B10','B11','B12'])
    wavelengths = {'B01': .44,'B02': .49,'B03': .56,'B04': .66,'B05': .70,
                   'B06': .74,'B07': .78,'B08': .84,'B8A': .86,'B11': 1.61,'B12': 2.2}
    if collection == 'hls2-l30': wavelengths.update(B05=.86,B06=1.61,B07=2.2)
    return {'id': 'HLS.test', 'collection': collection,
            'properties': {'datetime':'2024-07-01T13:00:00Z','eo:cloud_cover':2,
                           'platform':'landsat-9' if collection=='hls2-l30' else 'sentinel-2b'},
            'assets': {key: {'href':'https://hls2euwest.blob.core.windows.net/hls2/'+key+'.tif',
                'eo:bands':[{'name':key,'center_wavelength':wavelengths.get(key, 9)}]}
                for key in keys+['Fmask','SZA']}}


def raster(path, values, nodata=-9999):
    array = np.asarray(values)
    dataset = gdal.GetDriverByName('GTiff').Create(path,array.shape[1],array.shape[0],1,gdal.GDT_Int16)
    sr=osr.SpatialReference();sr.ImportFromEPSG(32722)
    dataset.SetProjection(sr.ExportToWkt());dataset.SetGeoTransform((500000,30,0,9600000,0,-30))
    dataset.GetRasterBand(1).SetNoDataValue(nodata);dataset.GetRasterBand(1).WriteArray(array)
    dataset=None


class HlsTests(unittest.TestCase):
    def test_s30_uses_spectral_matched_narrow_nir_and_excludes_auxiliary_layers(self):
        raw=raw_hls();original=copy.deepcopy(raw);item=normalize_hls(raw)
        self.assertEqual(raw,original)
        self.assertTrue(item['assets']['nir08']['href'].endswith('B8A.tif'))
        self.assertEqual(preset_keys(item,'natural'),('red','green','blue'))
        self.assertEqual(preset_keys(item,'prodes'),('swir16','nir08','red'))
        self.assertEqual(index_keys(item,'ndvi'),('nir08','red'))
        self.assertEqual(index_keys(item,'nbr'),('nir08','swir22'))
        self.assertNotIn('Fmask',dict(available_bands(item)))
        self.assertNotIn('B10',band_set(item));self.assertNotIn('SZA',band_set(item))
        order=band_set(item)
        self.assertLess(order.index('red'),order.index('nir08'))
        self.assertLess(order.index('nir08'),order.index('swir16'))

    def test_l30_keeps_hls_separate_from_usgs_and_does_not_reapply_atmospheric_correction(self):
        item=normalize_hls(raw_hls('hls2-l30'))
        self.assertEqual(item['collection'],'hls2-l30')
        self.assertEqual(reflectance_coefficients(item,'red'),(.0001,0))
        self.assertTrue(item['assets']['nir08']['href'].endswith('B05.tif'))
        self.assertEqual(correction_policy(item)['action'],'skip')
        self.assertNotIn('B10',dict(available_bands(item)))
        self.assertEqual(band_set(item)[:3],['coastal','blue','green'])

    def test_missing_nasa_metadata_never_uses_legacy_landsat_calibration(self):
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(ProdesError):
                metadata_for_layer(os.path.join(folder,'RGB.vrt'),'HLS.L30.test',['swir16','nir08','red'])
            value=metadata_for_layer(os.path.join(folder,'RGB.vrt'),'LT05_legacy',['swir16','nir08','red'])
            self.assertEqual(value['collection'],'landsat-c2-l2')

    def test_fmask_clear_zero_water_cloud_shadow_snow_aerosol_and_fill(self):
        values=np.array([0,32,2,4,8,16,192,255],dtype='uint8')
        valid,cloud,clear=fmask_flags(values)
        self.assertEqual(valid.tolist(),[True]*7+[False])
        self.assertEqual(clear.tolist(),[True,True,False,False,False,False,False,False])
        self.assertTrue(cloud[2]);self.assertFalse(cloud[0])
        np.testing.assert_array_equal(qa_valid(values,'hls'),clear)

    def test_quality_uses_fmask_instead_of_landsat_bits(self):
        with tempfile.TemporaryDirectory() as folder:
            path=os.path.join(folder,'Fmask.tif');raster(path,[[0,32],[2,255]],255)
            quality=inspect_qa(path,'hls',None)
            self.assertEqual(quality['valid_fraction'],.75)
            self.assertEqual(quality['clear_fraction'],.5)
            self.assertEqual(quality['cloud_percent'],25)

    def test_hls_vrt_and_index_keep_zero_reflectance_and_exclude_fill(self):
        item=normalize_hls(raw_hls('hls2-l30'))
        with tempfile.TemporaryDirectory() as folder:
            paths={}
            for key,values in [('red',[[0,1000,-9999]]),('nir08',[[4000,3000,4000]]),('swir16',[[2000,2000,-9999]])]:
                paths[key]=os.path.join(folder,key+'.tif');raster(paths[key],values)
            def cached(_item,_folder,_rect,_crs,_progress,keys,*args,**kwargs):
                return {key:paths[key] for key in keys if key in paths},[]
            client=PublicCatalog();client.cache_bands=cached
            _,_,path=client.download_scene(item,folder,[-50,-5,-49,-4],'EPSG:32722',lambda _:None,('swir16','nir08','red'))
            dataset=gdal.Open(path)
            self.assertEqual(dataset.GetRasterBand(3).GetNoDataValue(),-9999)
            self.assertEqual(int(dataset.GetRasterBand(3).ReadAsArray()[0,0]),0)
            dataset=None
            out=os.path.join(folder,'ndvi.tif');write_index(item,paths,out,gdal)
            dataset=gdal.Open(out);values=dataset.ReadAsArray()
            self.assertAlmostEqual(float(values[0,0]),1)
            self.assertAlmostEqual(float(values[0,1]),.5)
            self.assertEqual(float(values[0,2]),-9999)

    def test_assess_quality_requests_fmask_and_uses_hls_decoder(self):
        client=PublicCatalog();item=normalize_hls(raw_hls())
        with patch.object(client,'cache_bands',return_value=({'Fmask':'fixture'},[])) as cache,patch('usgs_catalogo_qgis.catalog_quality.inspect_qa',return_value={'ok':True}) as inspect:
            self.assertTrue(client.assess_scene_quality(item,'folder',[-50,-5,-49,-4],'EPSG:32722',lambda _:None,'POLYGON EMPTY')['ok'])
            self.assertEqual(cache.call_args.args[5],['Fmask'])
            self.assertEqual(inspect.call_args.args[1],'hls')

    def test_prodes_metadata_preserves_calibration_and_nasa_provenance(self):
        item=normalize_hls(raw_hls())
        with tempfile.TemporaryDirectory() as folder:
            metadata=scene_metadata(item,['swir16','nir08','red'],folder)
        self.assertEqual(metadata['qa_kind'],'hls')
        self.assertEqual(metadata['native_resolution'],30)
        self.assertEqual(metadata['source_nodata'],-9999)
        self.assertEqual(metadata['coefficients'],[[.0001,0]]*3)
        self.assertIn('NASA',metadata['sources'][0])

    def test_command_can_explicitly_choose_nasa_without_authentication(self):
        for text,expected in [('Baixe NASA HLS cor natural de 2020 a 2024',['hls2-l30','hls2-s30']),
                ('Baixe NASA HLS Landsat de 2020 a 2024',['hls2-l30']),
                ('Baixe NASA HLS Sentinel de 2020 a 2024',['hls2-s30'])]:
            self.assertEqual(parse_command(text)['collections'],expected)

    def test_stac_search_normalizes_hls_and_retains_pagination(self):
        client=PublicCatalog();link={'href':'https://planetarycomputer.microsoft.com/api/stac/v1/search?token=next','rel':'next'}
        client.json_request=lambda *args:{'type':'FeatureCollection','features':[raw_hls()],'links':[link]}
        scenes,next_link=client.search(['hls2-s30'],[-50,-5,-49,-4],'2024-01-01','2024-12-31')
        self.assertEqual(next_link,link);self.assertEqual(index_keys(scenes[0],'ndvi'),('nir08','red'))
