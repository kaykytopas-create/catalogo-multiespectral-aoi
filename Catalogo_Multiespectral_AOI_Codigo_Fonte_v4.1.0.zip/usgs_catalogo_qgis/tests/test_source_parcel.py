# SPDX-License-Identifier: GPL-2.0-or-later
import tempfile
import unittest
from unittest.mock import patch
from qgis.core import QgsApplication,QgsProject,QgsVectorLayer,QgsFeature,QgsGeometry
from qgis.PyQt.QtCore import QEventLoop,QTimer
from qgis.PyQt.QtWidgets import QComboBox
from usgs_catalogo_qgis.parcel import snapshot,ParcelPicker
from usgs_catalogo_qgis.stac import CatalogError
from usgs_catalogo_qgis.plugin import CatalogDialog

WKT='POLYGON((-55 -12,-54.99 -12,-54.99 -11.99,-55 -11.99,-55 -12))'


class SourceParcelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QgsApplication.instance() or QgsApplication([],False)
        cls.app.initQgis()

    def setUp(self):
        self.layers=[]

    def tearDown(self):
        for layer in self.layers:QgsProject.instance().removeMapLayer(layer.id())

    def layer(self,name,draw=False):
        layer=QgsVectorLayer('Polygon?crs=EPSG:4326',name,'memory')
        QgsProject.instance().addMapLayer(layer);self.layers.append(layer)
        if draw:
            layer.startEditing()
            feature=QgsFeature(layer.fields());feature.setGeometry(QgsGeometry.fromWkt(WKT))
            self.assertTrue(layer.addFeature(feature))
        return layer

    def test_single_unsaved_polygon_needs_no_selected_feature(self):
        layer=self.layer('Rascunho não salvo',True)
        self.assertEqual(layer.selectedFeatureCount(),0)
        value=snapshot(layer)
        self.assertEqual(len(value.feature_ids),1)
        self.assertLess(value.feature_ids[0],0)
        self.assertEqual(value.rect,(-55.0,-12.0,-54.99,-11.99))
        self.assertTrue(value.matches_current())
        self.assertEqual(value.outline_layer().featureCount(),1)

    def test_picker_detects_actual_selected_layer_instead_of_hidden_wrong_layer(self):
        empty=self.layer('A · camada vazia');parcel=self.layer('B · imóvel desenhado',True)
        parcel.selectByIds([next(parcel.getFeatures()).id()])
        previous=QComboBox();previous.addItem(empty.name(),empty.id())
        picker=ParcelPicker(preferred_box=previous)
        self.assertEqual(picker.resolve().layer_id,parcel.id())
        picker.combo.setCurrentIndex(picker.combo.findData(empty.id()))
        with self.assertRaisesRegex(CatalogError,'camada vazia'):picker.resolve()

    def test_multiple_polygons_require_explicit_parts_and_honor_selection(self):
        layer=self.layer('Dois imóveis',True)
        first=next(layer.getFeatures()).id()
        feature=QgsFeature(layer.fields());feature.setGeometry(QgsGeometry.fromWkt('POLYGON((-54 -12,-53.99 -12,-53.99 -11.99,-54 -11.99,-54 -12))'))
        layer.addFeature(feature)
        with self.assertRaisesRegex(CatalogError,'vários polígonos'):snapshot(layer)
        layer.selectByIds([first])
        value=snapshot(layer)
        self.assertEqual(value.feature_ids,(first,));self.assertLess(value.rect[2],-54)
        feature=layer.getFeature(first);layer.changeGeometry(first,QgsGeometry.fromWkt('POLYGON((-55 -12,-54.98 -12,-54.98 -11.98,-55 -11.98,-55 -12))'))
        self.assertFalse(value.matches_current())

    def wait_job(self,tab):
        self.assertIsNotNone(tab.job)
        loop=QEventLoop();tab.job.done.connect(loop.quit);QTimer.singleShot(5000,loop.quit);loop.exec()
        self.assertIsNone(tab.job)

    def test_main_nasa_query_uses_visible_parcel_and_unsaved_selected_geometry(self):
        self.layer('A · vazio');parcel=self.layer('B · limite',True)
        parcel.selectByIds([next(parcel.getFeatures()).id()])
        with tempfile.TemporaryDirectory() as root:
            dialog=CatalogDialog(None);dialog.archive_path=root
            self.assertEqual(dialog.layer_box.currentData(),parcel.id())
            dialog.landsat.setChecked(False);dialog.sentinel.setChecked(False)
            errors=[]
            from usgs_catalogo_qgis.tests.test_hls import raw_hls
            from usgs_catalogo_qgis.hls import normalize_hls
            item=normalize_hls(raw_hls())
            with patch('usgs_catalogo_qgis.plugin.QMessageBox.warning',side_effect=lambda *args:errors.append(args[-1])),patch('usgs_catalogo_qgis.public_sources.MultiCatalog.search',return_value=([item],None)) as search:
                dialog.search_first();self.wait_job(dialog)
                self.assertEqual(search.call_args.kwargs['rect'],(-55.0,-12.0,-54.99,-11.99))
                self.assertFalse(errors);self.assertEqual(dialog.scenes[0]['id'],'HLS.test')
                self.assertEqual(search.call_args.kwargs['collections'],['hls2-l30','hls2-s30'])
            dialog.close()

    def test_empty_offline_archive_does_not_claim_source_has_no_images(self):
        parcel=self.layer('Imóvel único',True)
        with tempfile.TemporaryDirectory() as root:
            dialog=CatalogDialog(None);dialog.archive_path=root
            dialog.layer_box.setCurrentIndex(dialog.layer_box.findData(parcel.id()))
            dialog.offline.setChecked(True)
            with patch('usgs_catalogo_qgis.public_sources.MultiCatalog.search',side_effect=AssertionError('offline network')):
                dialog.search_first();self.wait_job(dialog)
            self.assertFalse(dialog.scenes)
            self.assertIn('cenas locais',dialog.info.text())
            self.assertIn('Desmarque',dialog.info.text())
            dialog.close()


class SourceDisplayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QgsApplication.instance() or QgsApplication([],False)
        cls.app.initQgis()

    def image(self,path,values,nodata=-28672):
        from osgeo import gdal,osr
        import numpy as np
        data=gdal.GetDriverByName('GTiff').Create(path,4,4,len(values),gdal.GDT_Float32)
        sr=osr.SpatialReference();sr.ImportFromEPSG(4326)
        data.SetProjection(sr.ExportToWkt());data.SetGeoTransform((-55,.001,0,-12,0,-.001))
        for number,value in enumerate(values,1):
            data.GetRasterBand(number).SetNoDataValue(nodata)
            data.GetRasterBand(number).WriteArray(np.full((4,4),value,dtype='float32'))
        data=None

    def modis(self):
        return {'id':'MODIS-test','collection':'modis-09A1-061','catalog:kind':'reflectance',
                'assets':{key:{'href':'https://test.blob.core.windows.net/data/'+key+'.tif',
                         'eo:bands':[{'name':key}],'raster:bands':[{'scale':.0001,'offset':0}]} for key in ('red','green','blue','nir08','swir16','swir22')}}

    def test_constant_modis_channels_get_nonzero_safe_contrast(self):
        import os
        from qgis.core import QgsRasterLayer
        from usgs_catalogo_qgis.source_styles import display_profile,apply_profile
        with tempfile.TemporaryDirectory() as root:
            path=os.path.join(root,'rgb.tif');self.image(path,[1200,2400,1600])
            profile=display_profile(path,self.modis(),'burn')
            self.assertEqual(profile['mode'],'rgb');self.assertTrue(profile['uniform'])
            self.assertTrue(all(high>low for low,high in profile['limits']))
            layer=QgsRasterLayer(path,'MODIS');apply_profile(layer,profile)
            self.assertGreater(layer.renderer().redContrastEnhancement().maximumValue(),0)
            self.assertEqual(layer.renderer().greenBand(),2)

    def test_empty_or_zero_modis_is_rejected_instead_of_importing_black(self):
        import os
        from usgs_catalogo_qgis.source_styles import display_profile
        with tempfile.TemporaryDirectory() as root:
            path=os.path.join(root,'empty.tif');self.image(path,[-28672,-28672,-28672])
            with self.assertRaisesRegex(CatalogError,'sem pixels válidos'):display_profile(path,self.modis(),'burn')
            self.image(path,[0,0,0])
            with self.assertRaisesRegex(CatalogError,'apenas zeros'):display_profile(path,self.modis(),'burn')

    def test_goes_thermal_color_ramp_and_style_reopen(self):
        import os
        from qgis.core import QgsRasterLayer
        from usgs_catalogo_qgis.source_styles import display_profile,apply_profile
        with tempfile.TemporaryDirectory() as root:
            path=os.path.join(root,'temperature.tif');self.image(path,[290],-9999)
            profile=display_profile(path,{'catalog:kind':'thermal'},'original')
            layer=QgsRasterLayer(path,'GOES');apply_profile(layer,profile)
            self.assertEqual(layer.renderer().type(),'singlebandpseudocolor')
            _,saved=layer.saveNamedStyle(path+'.qml');self.assertTrue(saved)
            reopened=QgsRasterLayer(path,'GOES offline');reopened.loadNamedStyle(path+'.qml')
            self.assertEqual(reopened.renderer().type(),'singlebandpseudocolor')
            labels=[item.label for item in reopened.renderer().shader().rasterShaderFunction().colorRampItemList()]
            self.assertTrue(all(' K ' in label for label in labels))


    def test_modis_embedded_scale_is_respected_and_render_is_not_black(self):
        import os
        from osgeo import gdal
        from qgis.core import QgsRasterLayer,QgsMapSettings,QgsMapRendererParallelJob
        from qgis.PyQt.QtCore import QSize
        from usgs_catalogo_qgis.source_styles import display_profile,apply_profile
        with tempfile.TemporaryDirectory() as root:
            path=os.path.join(root,'scaled_rgb.tif');self.image(path,[1200,2400,1600])
            dataset=gdal.Open(path,gdal.GA_Update)
            for number in range(1,4):dataset.GetRasterBand(number).SetScale(.0001)
            dataset=None
            profile=display_profile(path,self.modis(),'burn')
            layer=QgsRasterLayer(path,'MODIS');apply_profile(layer,profile)
            self.assertAlmostEqual(layer.renderer().redContrastEnhancement().maximumValue(),.4)
            settings=QgsMapSettings();settings.setDestinationCrs(layer.crs());settings.setLayers([layer])
            settings.setExtent(layer.extent());settings.setOutputSize(QSize(40,40))
            render=QgsMapRendererParallelJob(settings);render.start();render.waitForFinished()
            color=render.renderedImage().pixelColor(20,20)
            self.assertGreater(color.red()+color.green()+color.blue(),100)
            layer=None
