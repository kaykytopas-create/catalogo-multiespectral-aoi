# Catálogo Multiespectral por Área de Interesse · 4.1.0

Plugin para buscar, visualizar e importar imagens Landsat, Sentinel-2 e NASA HLS pelo limite do imóvel, com comandos de tarefa, investigação PRODES e acervo offline. Desenvolvido por **Kayky Pessoa de Araujo**, com assistência do OpenAI Codex. GPL-2.0-or-later.

**QGIS 3.40–3.x**, com GDAL e NumPy fornecidos pelo QGIS. Os acervos ativos de imagens usam acesso público sem cadastro, senha ou chave obrigatória. O pacote declara `experimental=False`. A aprovação no repositório QGIS e a revisão técnica de interpretações ambientais são processos distintos.

## Novidades

- NASA **HLS L30 e S30 v2** na aba Imagens, com calibração, máscaras e bandas próprias, sem login pelo espelho Microsoft.
- Sentinel-2 **Collection 1 L2A via AWS Open Data/Earth Search** como acesso público independente, além da Microsoft.
- Cinco abas: Imagens; PRODES; Bandas e análise; Acervo offline; Situação ambiental e fundiária.
- MODIS, GOES, MapBiomas e a consulta externa ASTER foram retirados das novas consultas. Arquivos já baixados continuam no acervo.
- HLS usa escala 0,0001 e NoData -9999: zero de reflectância não é ausência de dados. Fmask tem decodificação própria. Band Set não mistura bandas térmicas, máscaras ou ângulos com reflectância.
- As representações Microsoft e AWS mantêm suas próprias identidades, calibrações e arquivos; suas bandas não são misturadas como espelhos idênticos.

## Começar

1. Instale o ZIP em Complementos → Gerenciar e instalar complementos → Instalar a partir do ZIP.
2. Carregue o limite do imóvel e escolha a camada no campo visível de Imagens. Em uma camada com vários imóveis, selecione uma única feição.
3. Mantenha as fontes pré-selecionadas, escolha o ano/período e pesquise. O filtro padrão mantém cenas com menos de 20 por cento de nuvens.
4. Selecione uma cena. Prévia e importar, ou Alt+I, abre o mapa com o limite antes de adicionar o raster. Os arquivos preparados permanecem no acervo mesmo se a prévia for fechada sem importar.
5. Em Bandas e análise, escolha cor natural, PRODES, vegetação, solo exposto, cicatriz, NDVI, NBR ou Band Set completo.

Comando de exemplo: **Baixe e importe NASA HLS cor natural, uma imagem por ano de 2020 a 2025 com até 5% de nuvens**. Para guardar sem importar: **Baixe NASA HLS cor natural de 2020 a 2025 e salve no acervo offline**. Um comando Sentinel-2 consulta Microsoft e AWS; um comando explicitamente Landsat preserva essa escolha. Sem fonte explícita, o comando mantém o padrão Landsat.

## Acervos ativos

| Produto | Acesso | Resolução e particularidade |
|---|---|---|
| USGS Landsat C2 nível 2 | Microsoft + INPE/Brazil Data Cube | Bandas refletivas de 30 m; histórico conforme sensor |
| Copernicus Sentinel-2 L2A | Microsoft | Visível/NIR de 10 m; SWIR de 20 m |
| Copernicus Sentinel-2 C1 L2A | AWS Open Data/Earth Search v1 | COGs públicos; visível/NIR de 10 m e SWIR de 20 m |
| NASA HLS L30 v2 | Microsoft | Landsat harmonizado a 30 m |
| NASA HLS S30 v2 | Microsoft | Sentinel-2 harmonizado a 30 m; NIR estreito B8A |

O espelho HLS Microsoft anuncia cobertura desde **2020**, embora o projeto NASA tenha uma série mais longa. A disponibilidade real depende da área e data. HLS é um processamento de Landsat/Sentinel, não outro satélite, nem uma forma de aumentar o detalhe do Sentinel-2 original. Nenhuma fonte garante imagens sem nuvens para todos os anos.

O portal MapBiomas informava suspensão temporária de download de mapas em **20/11/2026**. Isso não significa que os mapas foram apagados ou deixaram de existir no GEE. O conector foi retirado deste fluxo a pedido do autor. ASTER continua exigindo acesso externo para os arquivos; não é apresentado como importação sem login. A integração NASA ativa agora é HLS.

## Qualidade e análise

Os recortes mantêm pixels originais e uma margem ao redor do imóvel. Composições e índices respeitam as bandas e a calibração do produto. Landsat L2, Sentinel-2 L2A e HLS já são de superfície e não recebem DOS1 novamente. A regra DOS1 é restrita a reflectância TOA L1 explicitamente calibrada; as fontes ativas são de superfície.

HLS Fmask diferencia nuvem, vizinhança de nuvem, sombra, neve, preenchimento e aerossol. A triagem é conservadora; QA não prova ausência de todos os problemas visuais. Consulte também as limitações oficiais, especialmente Fmask em HLS L30 anterior a abril de 2022. Ausências e falhas não são convertidas em pixels inventados ou filtros relaxados.

NDVI e NBR não removem nuvens. Suavização afeta apenas a tela. Reduzir opacidade revela uma camada de referência, possivelmente de outra data; não recupera terreno oculto. Nenhuma simulação de conteúdo sob nuvens foi incluída.

PRODES mantém aba própria para TerraBrasilis, recorte, imagens temporais e relatório para revisão. A aquisição automática aceita Landsat e NASA HLS, com metadados e qualidade próprios. Proveniência identifica coleção, satélite e acesso utilizado. As saídas não certificam regularidade ambiental, domínio, inexistência de processos ou acurácia temática predeterminada. Uma camada chamada CONSOLIDADA não comprova sozinha enquadramento legal.

## Acervo e execução

Consulta, download, índices, investigação e auditoria usam QgsTask. O acervo padrão fica em Documentos. Ele contém metadados e recortes efetivamente preparados, não uma cópia de todos os catálogos públicos. Reabrir offline reutiliza arquivos e estilos disponíveis sem baixar novamente. A auditoria verifica SHA-256 e lê blocos raster. Não mova isoladamente as bandas de um VRT. Arquivos anteriores das fontes retiradas continuam legíveis em Acervo offline.

Veja [GUIA_4.1.md](GUIA_4.1.md), [VALIDACAO_4.1.md](VALIDACAO_4.1.md), [CHANGELOG.md](CHANGELOG.md) e [PUBLICACAO.md](PUBLICACAO.md).

## Créditos

USGS, NASA LP DAAC/IMPACT/HLS, ESA/Copernicus, INPE/Brazil Data Cube/TerraBrasilis, Microsoft, Element 84/Earth Search e AWS Open Data. Consulta ambiental: SICAR/SFB, IBAMA, ICMBio, SEMAS/PA, ITERPA e CNJ/DataJud, conforme disponibilidade. Projeto independente, sem endosso institucional.

- [NASA HLS: acesso e ferramentas](https://hls.gsfc.nasa.gov/data-access-and-tools/)
- [HLS no Planetary Computer](https://planetarycomputer.microsoft.com/dataset/group/hls2)
- [Documentação Earth Search](https://github.com/Element84/earth-search)
- [Situação dos downloads MapBiomas](https://brasil.mapbiomas.org/downloads/)
- [Código e suporte](https://github.com/kaykytopas-create/catalogo-multiespectral-aoi)
