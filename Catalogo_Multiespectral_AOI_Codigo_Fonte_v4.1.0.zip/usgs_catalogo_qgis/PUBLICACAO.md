# Publicação · 4.1.0

Atualização do mesmo plugin, com `experimental=False`, versão 4.1.0, GPL-2.0-or-later, autor Kayky Pessoa de Araujo e QGIS 3.40–3.99. Não declara QGIS 4. A condição de distribuição estável do software não homologa interpretações ambientais/jurídicas.

1. Instale o ZIP de instalação no QGIS e confira um imóvel real, prévia, RGB/NDVI e acervo offline no seu ambiente de produção. A validação automatizada foi feita no Linux; a instalação Windows do usuário não foi executada aqui.
2. Atualize o repositório existente com o código-fonte correspondente: https://github.com/kaykytopas-create/catalogo-multiespectral-aoi . O pacote inclui documentação, licença, changelog e fluxo de validação automatizada.
3. Envie o ZIP de instalação como nova versão na entrada existente no repositório QGIS. Não envie o ZIP de código-fonte como instalador.
4. Confira descrição em inglês, contatos, compatibilidade e resultado do verificador oficial. A tag sugerida é v4.1.0.

A descrição agora informa apenas as fontes ativas de imagem: Landsat/USGS, Sentinel-2 Microsoft/AWS e NASA HLS, sem conta obrigatória. HLS do espelho Microsoft anuncia cobertura desde 2020, sujeita a disponibilidade local. MODIS, GOES, MapBiomas e ASTER externo não são anunciados como downloads ativos.

O empacotador valida campos, interpolação ConfigParser, versões, licença, estrutura, tamanho e integridade ZIP. Mantém uma única pasta usgs_catalogo_qgis, sem caches, imagens de teste, projetos, bases de clientes ou credenciais. A CI fornecida pode ser executada no GitHub; a execução local não significa que essa CI foi rodada remotamente.

Nenhum upload ao GitHub ou ao repositório QGIS foi realizado nesta atualização. A aprovação e a disponibilidade no catálogo QGIS dependem da revisão do repositório oficial. Veja VALIDACAO_4.1.md para os testes e seus limites.
