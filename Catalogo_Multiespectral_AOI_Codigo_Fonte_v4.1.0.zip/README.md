# Catálogo Multiespectral AOI · 4.1.0

Plugin QGIS para imagens Landsat/USGS, Sentinel-2 e NASA HLS por limite do imóvel, sem login obrigatório. Inclui acesso público independente de Sentinel-2 via AWS/Earth Search, prévia georreferenciada, bandas e índices prontos, apoio PRODES e acervo offline verificado.

Consulte [o guia do plugin](usgs_catalogo_qgis/README.md), [a validação](usgs_catalogo_qgis/VALIDACAO_4.1.md) e [a publicação](usgs_catalogo_qgis/PUBLICACAO.md).

Instale no QGIS o ZIP de instalação, com a pasta usgs_catalogo_qgis. Este pacote é o código-fonte para o repositório. QGIS 3.40–3.99; distribuição estável nos metadados (`experimental=False`). A aprovação no repositório oficial depende da revisão QGIS.
